# Rust Coding Conventions

> **Project:** Lightning Network Node Management System  
> **Framework:** Axum + Diesel + LDK  
> **Version:** 1.0  
> **Date:** 2025-01-18

---

## Table of Contents

1. [Naming Conventions](#1-naming-conventions)
2. [Code Organization](#2-code-organization)
3. [Error Handling](#3-error-handling)
4. [Documentation](#4-documentation)
5. [Type System](#5-type-system)
6. [Async Programming](#6-async-programming)
7. [API Design](#7-api-design)
8. [Database & Repository](#8-database--repository)
9. [Logging & Tracing](#9-logging--tracing)
10. [Testing](#10-testing)
11. [Security](#11-security)
12. [Performance](#12-performance)
13. [Code Style](#13-code-style)

---

## 1. Naming Conventions

### 1.1 General Rules

| Item | Convention | Example |
|------|------------|---------|
| Crate names | `snake_case` | `node_backend` |
| Module names | `snake_case` | `ip_pool_service` |
| Types (struct, enum, trait) | `PascalCase` | `PaymentService`, `AppError` |
| Functions | `snake_case` | `get_user_by_id` |
| Methods | `snake_case` | `validate_token` |
| Variables | `snake_case` | `user_count` |
| Constants | `SCREAMING_SNAKE_CASE` | `MAX_CONNECTIONS` |
| Static variables | `SCREAMING_SNAKE_CASE` | `DEFAULT_TIMEOUT` |
| Type parameters | `PascalCase` (single letter or descriptive) | `T`, `E`, `Item` |
| Lifetimes | Short lowercase | `'a`, `'ctx` |

### 1.2 Specific Naming Patterns

```rust
// ✅ Services: noun + "Service"
pub struct PaymentService;
pub struct IpPoolService;

// ✅ Repositories: noun + "Repository"
pub struct UserRepository;
pub struct PaymentRepository;

// ✅ Traits: adjective or noun (no prefix/suffix)
pub trait Queryable;
pub trait PaymentProcessor;

// ✅ Trait implementations: noun + "Trait" suffix only when needed
pub trait IpPoolServiceTrait;  // When you need both trait and struct

// ✅ Errors: domain + "Error"
pub enum AppError;
pub enum ServiceError;
pub enum RepositoryError;
pub enum IpPoolServiceError;

// ✅ Request/Response types: action + "Request"/"Response"
pub struct CreateUserRequest;
pub struct CreateUserResponse;
pub struct UpdatePaymentRequest;

// ✅ Handlers: action + "handler" or domain + "handlers" (module)
pub async fn create_user_handler();
pub async fn list_payments_handler();
mod user_handlers;

// ✅ Middleware: descriptive name + "middleware"
pub async fn auth_middleware();
pub async fn rate_limit_middleware();

// ✅ Builders: type + "Builder"
pub struct ConfigBuilder;
pub struct QueryBuilder;
```

### 1.3 Prefixes and Suffixes

```rust
// ✅ Boolean variables/functions: use is_, has_, can_, should_
let is_active = true;
let has_permission = check_permission();
fn is_valid(&self) -> bool;
fn can_proceed(&self) -> bool;

// ✅ Getters: no "get_" prefix for simple accessors
impl User {
    pub fn name(&self) -> &str { &self.name }      // ✅ Simple getter
    pub fn full_name(&self) -> String { ... }      // ✅ Computed value
}

// ✅ Use "get_" when operation is non-trivial
impl Repository {
    pub async fn get_user_by_id(&self, id: &str) -> Result<User, Error>;  // ✅ DB lookup
    pub async fn get_all_users(&self) -> Result<Vec<User>, Error>;        // ✅ Complex operation
}

// ✅ Setters: use "set_" prefix or builder pattern
impl Config {
    pub fn set_timeout(&mut self, timeout: Duration);
    pub fn with_timeout(mut self, timeout: Duration) -> Self;  // Builder pattern
}

// ✅ Conversion methods
impl From<CreateUserRequest> for User { ... }     // ✅ From trait
fn into_response(self) -> Response;               // ✅ into_* for consuming
fn to_string(&self) -> String;                    // ✅ to_* for borrowing
fn as_str(&self) -> &str;                         // ✅ as_* for cheap reference
```

### 1.4 Module File Naming

```
src/
├── services/
│   ├── mod.rs                    # Module declarations
│   ├── payment_service.rs        # PaymentService
│   └── user_service.rs           # UserService
├── repositories/
│   ├── mod.rs
│   └── user_repository.rs        # UserRepository
├── models/
│   ├── mod.rs
│   ├── user.rs                   # User, NewUser, UpdateUser
│   └── payment.rs                # Payment, PaymentStatus
└── handlers/
    ├── mod.rs
    └── user_handlers.rs          # create_user, get_user, list_users
```

---

## 2. Code Organization

### 2.1 File Structure

```rust
//! Module-level documentation
//!
//! Detailed description of what this module does.
//! Include examples if helpful.

// ===== IMPORTS (in this order) =====
// 1. Standard library
use std::sync::Arc;
use std::collections::HashMap;

// 2. External crates
use axum::{extract::State, Json};
use diesel::prelude::*;
use serde::{Deserialize, Serialize};
use tracing::{debug, error, info, warn};

// 3. Internal modules (crate)
use crate::error::AppError;
use crate::models::User;

// 4. Super/sibling modules
use super::repository::UserRepository;

// ===== CONSTANTS =====
const MAX_RETRIES: u32 = 3;
const DEFAULT_PAGE_SIZE: i64 = 20;

// ===== TYPE ALIASES =====
pub type Result<T> = std::result::Result<T, ServiceError>;

// ===== TRAITS =====
#[async_trait]
pub trait UserServiceTrait: Send + Sync {
    async fn create_user(&self, req: CreateUserRequest) -> Result<User>;
    async fn get_user(&self, id: &str) -> Result<Option<User>>;
}

// ===== STRUCTS =====
pub struct UserService {
    repository: Arc<dyn UserRepositoryTrait>,
    event_bus: Arc<EventBus>,
}

// ===== STRUCT IMPLEMENTATIONS =====
impl UserService {
    pub fn new(repository: Arc<dyn UserRepositoryTrait>, event_bus: Arc<EventBus>) -> Self {
        Self { repository, event_bus }
    }
}

// ===== TRAIT IMPLEMENTATIONS =====
#[async_trait]
impl UserServiceTrait for UserService {
    async fn create_user(&self, req: CreateUserRequest) -> Result<User> {
        // Implementation
    }
    
    async fn get_user(&self, id: &str) -> Result<Option<User>> {
        // Implementation
    }
}

// ===== PRIVATE FUNCTIONS =====
fn validate_email(email: &str) -> bool {
    // Implementation
}

// ===== TESTS =====
#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_validate_email() {
        assert!(validate_email("test@example.com"));
    }
}
```

### 2.2 Import Organization

```rust
// ✅ DO: Group and organize imports
use std::sync::Arc;
use std::time::Duration;

use axum::{
    extract::{Path, Query, State},
    http::StatusCode,
    response::{IntoResponse, Json},
    routing::{get, post},
    Router,
};
use diesel::prelude::*;
use serde::{Deserialize, Serialize};
use tracing::{debug, error, info, instrument, warn};

use crate::{
    error::{AppError, AppResult},
    models::{User, UserStatus},
    services::UserService,
};

// ❌ DON'T: Unorganized imports
use crate::error::AppError;
use std::sync::Arc;
use axum::extract::State;
use crate::models::User;
use axum::Json;
use std::time::Duration;
```

### 2.3 Module Visibility

```rust
// ✅ Be explicit about visibility
pub struct PublicApi;           // Public to other crates
pub(crate) struct InternalApi;  // Public within crate only
pub(super) struct ParentApi;    // Public to parent module
struct PrivateImpl;             // Private (default)

// ✅ Re-export public items in mod.rs
// src/services/mod.rs
mod payment_service;
mod user_service;

pub use payment_service::{PaymentService, PaymentServiceTrait};
pub use user_service::{UserService, UserServiceTrait};
```

---

## 3. Error Handling

### 3.1 Error Type Hierarchy

```rust
// ===== APPLICATION-LEVEL ERROR =====
/// Top-level error type for HTTP responses
#[derive(Debug)]
pub enum AppError {
    // Client errors (4xx)
    BadRequest(String),
    Unauthorized(String),
    Forbidden(String),
    NotFound(String),
    Validation(String),
    Conflict(String),
    PaymentRequired { message: String, invoice: String },
    
    // Server errors (5xx)
    Internal(String),
    External(String),
    DatabaseConnection(String),
    
    // Wrapped errors
    Anyhow(anyhow::Error),
}

// ===== SERVICE-LEVEL ERROR =====
/// Domain-specific errors for business logic
#[derive(Debug, Clone)]
pub enum ServiceError {
    NotFound(String),
    ValidationError(String),
    Conflict(String),
    Unauthorized(String),
    InternalError(String),
}

// ===== REPOSITORY-LEVEL ERROR =====
/// Data access errors
#[derive(Debug, Clone)]
pub enum RepositoryError {
    NotFound(String),
    Conflict(String),
    ConnectionError(String),
    QueryError(String),
    ValidationError(String),
}
```

### 3.2 Error Conversion Chain

```rust
// Repository → Service → App (Handler)
// Each layer converts errors to its own type

// ✅ Implement From for error conversions
impl From<RepositoryError> for ServiceError {
    fn from(err: RepositoryError) -> Self {
        match err {
            RepositoryError::NotFound(msg) => ServiceError::NotFound(msg),
            RepositoryError::Conflict(msg) => ServiceError::Conflict(msg),
            RepositoryError::ValidationError(msg) => ServiceError::ValidationError(msg),
            _ => ServiceError::InternalError(err.to_string()),
        }
    }
}

impl From<ServiceError> for AppError {
    fn from(err: ServiceError) -> Self {
        match err {
            ServiceError::NotFound(msg) => AppError::NotFound(msg),
            ServiceError::ValidationError(msg) => AppError::Validation(msg),
            ServiceError::Conflict(msg) => AppError::Conflict(msg),
            ServiceError::Unauthorized(msg) => AppError::Unauthorized(msg),
            ServiceError::InternalError(msg) => AppError::Internal(msg),
        }
    }
}
```

### 3.3 Error Handling Patterns

```rust
// ✅ DO: Use ? operator with proper error types
pub async fn get_user(&self, id: &str) -> Result<User, ServiceError> {
    let user = self.repository
        .find_by_id(id)
        .await?  // RepositoryError -> ServiceError via From
        .ok_or_else(|| ServiceError::NotFound(format!("User {} not found", id)))?;
    
    Ok(user)
}

// ✅ DO: Use early returns for validation
pub async fn create_user(&self, req: CreateUserRequest) -> Result<User, ServiceError> {
    // Validate early
    if req.email.is_empty() {
        return Err(ServiceError::ValidationError("Email is required".to_string()));
    }
    
    if !is_valid_email(&req.email) {
        return Err(ServiceError::ValidationError("Invalid email format".to_string()));
    }
    
    // Check for conflicts
    if self.repository.exists_by_email(&req.email).await? {
        return Err(ServiceError::Conflict("Email already in use".to_string()));
    }
    
    // Proceed with creation
    let user = self.repository.create(req.into()).await?;
    Ok(user)
}

// ✅ DO: Add context to errors
use anyhow::Context;

pub async fn process_payment(&self, id: &str) -> Result<Payment, AppError> {
    let payment = self.repository
        .find_by_id(id)
        .await
        .context(format!("Failed to find payment {}", id))?;
    
    Ok(payment)
}

// ❌ DON'T: Use unwrap() in production code
let user = users.first().unwrap();  // Can panic!

// ✅ DO: Handle None/Err gracefully
let user = users.first()
    .ok_or_else(|| ServiceError::NotFound("No users found".to_string()))?;

// ❌ DON'T: Use expect() without clear message
let conn = pool.get().expect("failed");

// ✅ DO: Use expect() with descriptive message (only in init code)
let conn = pool.get().expect("Database pool should be initialized");
```

### 3.4 HTTP Error Responses

```rust
impl IntoResponse for AppError {
    fn into_response(self) -> Response {
        let (status, error_json) = match &self {
            // Client errors
            AppError::BadRequest(msg) => {
                warn!(message = %msg, "Bad request");
                (StatusCode::BAD_REQUEST, json!({ "error": msg }))
            }
            AppError::Unauthorized(msg) => {
                warn!(message = %msg, "Unauthorized");
                (StatusCode::UNAUTHORIZED, json!({ "error": msg }))
            }
            AppError::NotFound(msg) => {
                warn!(message = %msg, "Not found");
                (StatusCode::NOT_FOUND, json!({ "error": msg }))
            }
            
            // Server errors - don't leak internal details
            AppError::Internal(msg) => {
                error!(message = %msg, "Internal error");
                (
                    StatusCode::INTERNAL_SERVER_ERROR,
                    json!({ "error": "Internal server error" })  // Don't expose msg
                )
            }
            
            // ...
        };
        
        (status, Json(error_json)).into_response()
    }
}
```

---

## 4. Documentation

### 4.1 Module Documentation

```rust
//! IP Pool Service - Business Logic Layer
//!
//! This module handles IP pool management operations including:
//! - Creating, updating, and deleting IP entries
//! - Health check scheduling and monitoring
//! - Event publishing for WebSocket updates
//!
//! # Architecture
//!
//! ```text
//! Handler → Service → Repository → Database
//!              ↓
//!          EventBus
//! ```
//!
//! # Example
//!
//! ```rust,ignore
//! let service = IpPoolService::new(repo, event_bus);
//! let entry = service.create_entry(request).await?;
//! ```
//!
//! # Constitution Compliance
//!
//! - Uses EventBus for side effects (WebSocket broadcasts)
//! - NO direct AppState dependencies
//! - Services publish domain events, handlers subscribe

use async_trait::async_trait;
// ...
```

### 4.2 Function/Method Documentation

```rust
/// Creates a new IP pool entry.
///
/// This method validates the request, checks for conflicts, and persists
/// the entry to the database. On success, it publishes an event to notify
/// connected clients.
///
/// # Arguments
///
/// * `node_id` - The node identifier that owns this entry
/// * `request` - The creation request containing IP, port, and metadata
///
/// # Returns
///
/// * `Ok(NodeIpPoolEntry)` - The created entry with generated ID
/// * `Err(ServiceError::ValidationError)` - If validation fails
/// * `Err(ServiceError::Conflict)` - If entry already exists
///
/// # Example
///
/// ```rust,ignore
/// let request = CreateIpRequest {
///     ip_address: "192.168.1.1".parse()?,
///     port: 9735,
///     port_type: PortType::Lightning,
/// };
/// let entry = service.create_entry("node-123", request).await?;
/// ```
///
/// # Events
///
/// Publishes `IpPoolEvent::EntryCreated` on success.
pub async fn create_entry(
    &self,
    node_id: &str,
    request: CreateIpRequest,
) -> Result<NodeIpPoolEntry, ServiceError> {
    // Implementation
}
```

### 4.3 Struct Documentation

```rust
/// Metadata about an IP pool update operation.
///
/// This struct is returned after updating an entry and contains
/// information about what changed during the update.
#[derive(Debug, Clone)]
pub struct IpUpdateMetadata {
    /// The updated entry with new values
    pub entry: NodeIpPoolEntry,
    
    /// List of field names that were modified
    ///
    /// Example: `["ip_address", "port", "is_active"]`
    pub changed_fields: Vec<String>,
    
    /// Whether the public-facing status changed
    ///
    /// This is significant because it affects gossip propagation.
    pub public_facing_changed: bool,
}
```

### 4.4 When to Document

```rust
// ✅ DO: Document public APIs
/// Returns the user's full name.
pub fn full_name(&self) -> String {
    format!("{} {}", self.first_name, self.last_name)
}

// ✅ DO: Document non-obvious behavior
/// Returns the next retry delay using exponential backoff.
///
/// The delay doubles with each attempt up to a maximum of 60 seconds.
/// Formula: min(2^attempt * 1000ms, 60000ms)
pub fn next_retry_delay(&self, attempt: u32) -> Duration {
    let ms = (2_u64.pow(attempt) * 1000).min(60_000);
    Duration::from_millis(ms)
}

// ❌ DON'T: Document obvious getters
/// Gets the ID.
pub fn id(&self) -> &str {
    &self.id
}

// ✅ DO: Use doc comments for public items
/// User's email address.
pub email: String,

// ✅ DO: Use regular comments for implementation details
// Calculate hash using SHA-256 for consistency with LDK
let hash = sha256(&preimage);
```

---

## 5. Type System

### 5.1 Newtype Pattern

```rust
// ✅ DO: Use newtypes for domain concepts
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct UserId(String);

impl UserId {
    pub fn new(id: impl Into<String>) -> Self {
        Self(id.into())
    }
    
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl From<String> for UserId {
    fn from(s: String) -> Self {
        Self(s)
    }
}

// ✅ DO: Use newtypes for validation
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Email(String);

impl Email {
    pub fn new(email: impl Into<String>) -> Result<Self, ValidationError> {
        let email = email.into();
        if is_valid_email(&email) {
            Ok(Self(email))
        } else {
            Err(ValidationError::InvalidEmail)
        }
    }
}
```

### 5.2 Builder Pattern

```rust
/// Configuration builder with sensible defaults.
#[derive(Default)]
pub struct ConfigBuilder {
    host: Option<String>,
    port: Option<u16>,
    timeout: Option<Duration>,
}

impl ConfigBuilder {
    pub fn new() -> Self {
        Self::default()
    }
    
    pub fn host(mut self, host: impl Into<String>) -> Self {
        self.host = Some(host.into());
        self
    }
    
    pub fn port(mut self, port: u16) -> Self {
        self.port = Some(port);
        self
    }
    
    pub fn timeout(mut self, timeout: Duration) -> Self {
        self.timeout = Some(timeout);
        self
    }
    
    pub fn build(self) -> Result<Config, ConfigError> {
        Ok(Config {
            host: self.host.ok_or(ConfigError::MissingHost)?,
            port: self.port.unwrap_or(8080),
            timeout: self.timeout.unwrap_or(Duration::from_secs(30)),
        })
    }
}

// Usage
let config = ConfigBuilder::new()
    .host("localhost")
    .port(3000)
    .timeout(Duration::from_secs(60))
    .build()?;
```

### 5.3 Enums for States

```rust
// ✅ DO: Use enums for finite states
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PaymentStatus {
    Pending,
    Processing,
    Completed,
    Failed,
    Cancelled,
}

// ✅ DO: Implement Display for user-facing output
impl std::fmt::Display for PaymentStatus {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Pending => write!(f, "pending"),
            Self::Processing => write!(f, "processing"),
            Self::Completed => write!(f, "completed"),
            Self::Failed => write!(f, "failed"),
            Self::Cancelled => write!(f, "cancelled"),
        }
    }
}

// ✅ DO: Use FromStr for parsing
impl std::str::FromStr for PaymentStatus {
    type Err = ParseError;
    
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s.to_lowercase().as_str() {
            "pending" => Ok(Self::Pending),
            "processing" => Ok(Self::Processing),
            "completed" => Ok(Self::Completed),
            "failed" => Ok(Self::Failed),
            "cancelled" => Ok(Self::Cancelled),
            _ => Err(ParseError::InvalidStatus(s.to_string())),
        }
    }
}
```

### 5.4 Optional and Result

```rust
// ✅ DO: Use Option for optional values
pub struct User {
    pub id: String,
    pub name: String,
    pub email: Option<String>,      // May not have email
    pub avatar_url: Option<String>, // May not have avatar
}

// ✅ DO: Use Result for fallible operations
pub async fn find_user(&self, id: &str) -> Result<Option<User>, RepositoryError> {
    // Return Ok(None) if user doesn't exist
    // Return Err(_) if database error
}

// ✅ DO: Prefer combinators over match
let name = user.nickname
    .as_ref()
    .map(|n| n.to_uppercase())
    .unwrap_or_else(|| user.name.clone());

// ✅ DO: Chain Results with ?
let user = self.repository.find_by_id(id).await?
    .ok_or_else(|| ServiceError::NotFound(format!("User {} not found", id)))?;
```

---

## 6. Async Programming

### 6.1 Async Function Signatures

```rust
// ✅ DO: Use async/await for I/O operations
pub async fn fetch_user(&self, id: &str) -> Result<User, ServiceError> {
    let user = self.repository.find_by_id(id).await?;
    Ok(user)
}

// ✅ DO: Use Arc for shared async state
pub struct AppState {
    pub db_pool: Arc<DbPool>,
    pub config: Arc<Config>,
    pub event_bus: Arc<EventBus>,
}

// ✅ DO: Use async_trait for async trait methods
#[async_trait]
pub trait UserServiceTrait: Send + Sync {
    async fn create_user(&self, req: CreateUserRequest) -> Result<User, ServiceError>;
    async fn get_user(&self, id: &str) -> Result<Option<User>, ServiceError>;
}
```

### 6.2 Spawning Tasks

```rust
// ✅ DO: Use tokio::spawn for background tasks
tokio::spawn(async move {
    if let Err(e) = background_cleanup().await {
        error!(error = %e, "Background cleanup failed");
    }
});

// ✅ DO: Use spawn_blocking for CPU-intensive work
let hash = tokio::task::spawn_blocking(move || {
    compute_expensive_hash(&data)
}).await?;

// ✅ DO: Handle task panics
let result = tokio::spawn(async move {
    risky_operation().await
}).await;

match result {
    Ok(Ok(value)) => println!("Success: {:?}", value),
    Ok(Err(e)) => error!("Operation failed: {}", e),
    Err(e) => error!("Task panicked: {}", e),
}
```

### 6.3 Timeouts and Cancellation

```rust
use tokio::time::{timeout, Duration};

// ✅ DO: Add timeouts to external calls
let result = timeout(Duration::from_secs(30), external_api_call())
    .await
    .map_err(|_| ServiceError::Timeout("External API timed out".to_string()))?;

// ✅ DO: Use select for cancellation
tokio::select! {
    result = long_running_task() => {
        handle_result(result);
    }
    _ = shutdown_signal.recv() => {
        info!("Received shutdown signal, cancelling task");
    }
}
```

---

## 7. API Design

### 7.1 Handler Structure

```rust
/// Creates a new user account.
#[instrument(
    skip(state),
    fields(request_id = %Uuid::new_v4())
)]
pub async fn create_user_handler(
    State(state): State<Arc<AppState>>,
    ValidatedJson(request): ValidatedJson<CreateUserRequest>,
) -> Result<Json<ApiResponse<User>>, AppError> {
    debug!(target: "node_backend::users", "Creating new user");
    
    // Delegate to service
    let user = state.user_service
        .create_user(request)
        .await
        .map_err(AppError::from)?;
    
    info!(
        target: "node_backend::users",
        user_id = %user.id,
        "User created successfully"
    );
    
    Ok(Json(ApiResponse::success(user, "User created successfully")))
}
```

### 7.2 Request/Response Types

```rust
// ✅ DO: Use separate types for requests and responses
#[derive(Debug, Deserialize, Validate)]
pub struct CreateUserRequest {
    #[validate(length(min = 1, max = 100))]
    pub name: String,
    
    #[validate(email)]
    pub email: String,
    
    #[validate(length(min = 8))]
    pub password: String,
}

#[derive(Debug, Serialize)]
pub struct UserResponse {
    pub id: String,
    pub name: String,
    pub email: String,
    pub created_at: DateTime<Utc>,
    // Note: No password field!
}

// ✅ DO: Use From for conversions
impl From<User> for UserResponse {
    fn from(user: User) -> Self {
        Self {
            id: user.id,
            name: user.name,
            email: user.email,
            created_at: user.created_at,
        }
    }
}
```

### 7.3 Validated Extractors

```rust
// ✅ DO: Use ValidatedJson for automatic validation
pub async fn create_user(
    ValidatedJson(request): ValidatedJson<CreateUserRequest>,
) -> Result<Json<User>, AppError> {
    // request is already validated
}

// ✅ DO: Use ValidatedQuery for query parameters
pub async fn list_users(
    ValidatedQuery(params): ValidatedQuery<ListUsersParams>,
) -> Result<Json<Vec<User>>, AppError> {
    // params are validated
}

// ✅ DO: Define validation rules with validator crate
#[derive(Debug, Deserialize, Validate)]
pub struct ListUsersParams {
    #[validate(range(min = 1, max = 100))]
    pub limit: Option<i64>,
    
    #[validate(range(min = 0))]
    pub offset: Option<i64>,
    
    #[validate(length(max = 50))]
    pub search: Option<String>,
}
```

### 7.4 API Response Structure

```rust
/// Standard API response wrapper.
#[derive(Debug, Serialize)]
pub struct ApiResponse<T> {
    pub success: bool,
    pub data: Option<T>,
    pub message: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub error: Option<String>,
}

impl<T: Serialize> ApiResponse<T> {
    pub fn success(data: T, message: impl Into<String>) -> Self {
        Self {
            success: true,
            data: Some(data),
            message: Some(message.into()),
            error: None,
        }
    }
    
    pub fn error(error: impl Into<String>) -> ApiResponse<()> {
        ApiResponse {
            success: false,
            data: None,
            message: None,
            error: Some(error.into()),
        }
    }
}
```

---

## 8. Database & Repository

### 8.1 Repository Pattern

```rust
/// Repository trait for user data access.
#[async_trait]
pub trait UserRepositoryTrait: Send + Sync {
    async fn find_by_id(&self, id: &str) -> Result<Option<User>, RepositoryError>;
    async fn find_by_email(&self, email: &str) -> Result<Option<User>, RepositoryError>;
    async fn create(&self, user: NewUser) -> Result<User, RepositoryError>;
    async fn update(&self, id: &str, update: UpdateUser) -> Result<User, RepositoryError>;
    async fn delete(&self, id: &str) -> Result<(), RepositoryError>;
    async fn list(&self, params: ListParams) -> Result<Vec<User>, RepositoryError>;
}

/// Diesel implementation of UserRepository.
pub struct UserRepository {
    pool: Arc<DbPool>,
}

impl UserRepository {
    pub fn new(pool: Arc<DbPool>) -> Self {
        Self { pool }
    }
}

#[async_trait]
impl UserRepositoryTrait for UserRepository {
    async fn find_by_id(&self, id: &str) -> Result<Option<User>, RepositoryError> {
        let pool = Arc::clone(&self.pool);
        let id = id.to_string();
        
        tokio::task::spawn_blocking(move || {
            let mut conn = pool.get()
                .map_err(|e| RepositoryError::ConnectionError(e.to_string()))?;
            
            users::table
                .filter(users::id.eq(&id))
                .first::<User>(&mut conn)
                .optional()
                .map_err(|e| RepositoryError::QueryError(e.to_string()))
        })
        .await
        .map_err(|e| RepositoryError::QueryError(e.to_string()))?
    }
}
```

### 8.2 Query Safety

```rust
// ✅ DO: Use Diesel's query builder (safe from SQL injection)
users::table
    .filter(users::email.eq(&email))
    .filter(users::status.eq(UserStatus::Active))
    .first::<User>(&mut conn)

// ✅ DO: Use bind parameters for raw queries
diesel::sql_query("SELECT * FROM users WHERE id = ?")
    .bind::<diesel::sql_types::Text, _>(&user_id)
    .get_result::<User>(&mut conn)

// ❌ DON'T: Use format! in SQL queries
let query = format!("SELECT * FROM users WHERE id = '{}'", user_id);  // SQL INJECTION!

// ❌ DON'T: Use sql() with format!
.filter(sql::<Bool>(&format!("'{}' GLOB pattern", user_input)))  // SQL INJECTION!
```

### 8.3 Transaction Handling

```rust
// ✅ DO: Use transactions for multiple operations
pub async fn transfer_funds(
    &self,
    from_id: &str,
    to_id: &str,
    amount: i64,
) -> Result<(), RepositoryError> {
    let pool = Arc::clone(&self.pool);
    let from_id = from_id.to_string();
    let to_id = to_id.to_string();
    
    tokio::task::spawn_blocking(move || {
        let mut conn = pool.get()
            .map_err(|e| RepositoryError::ConnectionError(e.to_string()))?;
        
        conn.transaction::<_, RepositoryError, _>(|conn| {
            // Debit from account
            diesel::update(accounts::table.filter(accounts::id.eq(&from_id)))
                .set(accounts::balance.eq(accounts::balance - amount))
                .execute(conn)?;
            
            // Credit to account
            diesel::update(accounts::table.filter(accounts::id.eq(&to_id)))
                .set(accounts::balance.eq(accounts::balance + amount))
                .execute(conn)?;
            
            Ok(())
        })
    })
    .await
    .map_err(|e| RepositoryError::QueryError(e.to_string()))?
}
```

---

## 9. Logging & Tracing

### 9.1 Log Levels

```rust
// ✅ DO: Use appropriate log levels
error!(target: "node_backend::payments", error = %e, "Payment processing failed");
warn!(target: "node_backend::auth", "Invalid token received");
info!(target: "node_backend::users", user_id = %id, "User created");
debug!(target: "node_backend::db", query = %sql, "Executing query");
trace!(target: "node_backend::http", headers = ?headers, "Request headers");
```

### 9.2 Structured Logging

```rust
// ✅ DO: Use structured fields
info!(
    target: "node_backend::payments",
    payment_id = %payment.id,
    amount_sats = payment.amount_sats,
    status = %payment.status,
    "Payment processed"
);

// ✅ DO: Use spans for request context
#[instrument(
    skip(state, request),
    fields(
        request_id = %Uuid::new_v4(),
        user_id = %claims.sub
    )
)]
pub async fn create_payment(
    State(state): State<Arc<AppState>>,
    claims: Claims,
    Json(request): Json<CreatePaymentRequest>,
) -> Result<Json<Payment>, AppError> {
    // All logs within this function include request_id and user_id
    debug!("Processing payment request");
    
    let payment = state.payment_service.create(request).await?;
    
    info!(payment_id = %payment.id, "Payment created");
    Ok(Json(payment))
}
```

### 9.3 Target Naming Convention

```rust
// Format: node_backend::<module>::<submodule>
target: "node_backend::auth::middleware"
target: "node_backend::payments::service"
target: "node_backend::l402::repository"
target: "node_backend::websocket::events"

// ✅ DO: Be consistent with targets
debug!(target: "node_backend::auth", "Validating JWT token");
info!(target: "node_backend::auth", user_id = %claims.sub, "Authentication successful");
warn!(target: "node_backend::auth", "Token expired");
error!(target: "node_backend::auth", error = %e, "Authentication failed");
```

### 9.4 Sensitive Data

```rust
// ❌ DON'T: Log sensitive data
info!("User logged in with password: {}", password);  // NEVER!
debug!("API key: {}", api_key);  // NEVER!
info!("Seed phrase: {:?}", seed_phrase);  // NEVER!

// ✅ DO: Redact sensitive fields
info!(
    user_id = %user.id,
    email = %redact_email(&user.email),
    "User authenticated"
);

fn redact_email(email: &str) -> String {
    if let Some(at_pos) = email.find('@') {
        let (local, domain) = email.split_at(at_pos);
        format!("{}***{}", &local[..1.min(local.len())], domain)
    } else {
        "***".to_string()
    }
}
```

---

## 10. Testing

### 10.1 Unit Test Structure

```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    // ===== TEST FIXTURES =====
    fn create_test_user() -> User {
        User {
            id: "test-user-1".to_string(),
            name: "Test User".to_string(),
            email: "test@example.com".to_string(),
            status: UserStatus::Active,
        }
    }
    
    // ===== UNIT TESTS =====
    #[test]
    fn test_user_full_name() {
        let user = User {
            first_name: "John".to_string(),
            last_name: "Doe".to_string(),
            ..Default::default()
        };
        
        assert_eq!(user.full_name(), "John Doe");
    }
    
    #[test]
    fn test_email_validation_valid() {
        assert!(Email::new("test@example.com").is_ok());
        assert!(Email::new("user.name@domain.co.uk").is_ok());
    }
    
    #[test]
    fn test_email_validation_invalid() {
        assert!(Email::new("invalid").is_err());
        assert!(Email::new("@example.com").is_err());
        assert!(Email::new("test@").is_err());
    }
    
    // ===== ASYNC TESTS =====
    #[tokio::test]
    async fn test_create_user_success() {
        let mock_repo = MockUserRepository::new();
        mock_repo.expect_create().returning(|_| Ok(create_test_user()));
        
        let service = UserService::new(Arc::new(mock_repo));
        let request = CreateUserRequest {
            name: "Test".to_string(),
            email: "test@example.com".to_string(),
        };
        
        let result = service.create_user(request).await;
        assert!(result.is_ok());
    }
    
    #[tokio::test]
    async fn test_create_user_duplicate_email() {
        let mock_repo = MockUserRepository::new();
        mock_repo.expect_exists_by_email().returning(|_| Ok(true));
        
        let service = UserService::new(Arc::new(mock_repo));
        let request = CreateUserRequest {
            name: "Test".to_string(),
            email: "existing@example.com".to_string(),
        };
        
        let result = service.create_user(request).await;
        assert!(matches!(result, Err(ServiceError::Conflict(_))));
    }
}
```

### 10.2 Test Naming Convention

```rust
// Pattern: test_<function>_<scenario>_<expected_outcome>
#[test]
fn test_validate_email_with_valid_input_returns_ok() { }

#[test]
fn test_validate_email_with_empty_string_returns_error() { }

#[test]
fn test_create_user_when_email_exists_returns_conflict() { }

#[tokio::test]
async fn test_process_payment_with_insufficient_funds_returns_error() { }
```

### 10.3 Integration Tests

```rust
// tests/integration/user_tests.rs
use node_backend::test_utils::TestApp;

#[tokio::test]
async fn test_user_registration_flow() {
    let app = TestApp::spawn().await;
    
    // Create user
    let response = app
        .post("/api/v2/users")
        .json(&json!({
            "name": "Test User",
            "email": "test@example.com",
            "password": "secure_password_123"
        }))
        .await;
    
    assert_eq!(response.status(), StatusCode::CREATED);
    
    let user: UserResponse = response.json().await;
    assert_eq!(user.name, "Test User");
    assert_eq!(user.email, "test@example.com");
    
    // Login
    let response = app
        .post("/api/v2/auth/login")
        .json(&json!({
            "email": "test@example.com",
            "password": "secure_password_123"
        }))
        .await;
    
    assert_eq!(response.status(), StatusCode::OK);
}
```

---

## 11. Security

### 11.1 Input Validation

```rust
// ✅ DO: Validate all input
#[derive(Debug, Deserialize, Validate)]
pub struct CreatePaymentRequest {
    #[validate(range(min = 1, max = 21_000_000_00000000))]  // Max 21M BTC in sats
    pub amount_sats: i64,
    
    #[validate(length(max = 500))]
    pub description: Option<String>,
    
    #[validate(custom = "validate_invoice")]
    pub invoice: Option<String>,
}

fn validate_invoice(invoice: &str) -> Result<(), ValidationError> {
    if !invoice.starts_with("lnbc") && !invoice.starts_with("lntb") {
        return Err(ValidationError::new("invalid_invoice"));
    }
    Ok(())
}
```

### 11.2 Authentication

```rust
// ✅ DO: Extract claims from validated tokens
pub async fn protected_handler(
    claims: Claims,  // Extracted and validated by middleware
    State(state): State<Arc<AppState>>,
) -> Result<Json<Data>, AppError> {
    // claims.sub contains the authenticated user ID
    let user_id = &claims.sub;
    
    // Use user_id for authorization checks
    let data = state.service.get_user_data(user_id).await?;
    Ok(Json(data))
}

// ✅ DO: Verify ownership/permissions
pub async fn update_resource(
    claims: Claims,
    Path(resource_id): Path<String>,
    State(state): State<Arc<AppState>>,
    Json(request): Json<UpdateRequest>,
) -> Result<Json<Resource>, AppError> {
    let resource = state.service.get_resource(&resource_id).await?
        .ok_or_else(|| AppError::NotFound("Resource not found".to_string()))?;
    
    // Verify ownership
    if resource.owner_id != claims.sub {
        return Err(AppError::Forbidden("Not authorized to update this resource".to_string()));
    }
    
    let updated = state.service.update_resource(&resource_id, request).await?;
    Ok(Json(updated))
}
```

### 11.3 Sensitive Data Handling

```rust
// ✅ DO: Use secrecy crate for sensitive data
use secrecy::{Secret, ExposeSecret};

pub struct Config {
    pub jwt_secret: Secret<String>,
    pub database_url: Secret<String>,
}

impl Config {
    pub fn jwt_secret(&self) -> &str {
        self.jwt_secret.expose_secret()
    }
}

// ✅ DO: Implement Zeroize for sensitive structs
use zeroize::Zeroize;

#[derive(Zeroize)]
#[zeroize(drop)]
pub struct PrivateKey {
    bytes: [u8; 32],
}

// ✅ DO: Clear sensitive data after use
let mut password = password_from_input();
let hash = hash_password(&password);
password.zeroize();  // Clear from memory
```

---

## 12. Performance

### 12.1 Cloning Strategy

```rust
// ❌ DON'T: Clone large data unnecessarily
fn process(data: Vec<User>) {
    let users = data.clone();  // Expensive!
    // ...
}

// ✅ DO: Use references when possible
fn process(data: &[User]) {
    for user in data {
        // Process user
    }
}

// ✅ DO: Use Arc for shared ownership
let shared_data = Arc::new(expensive_data);
let clone1 = Arc::clone(&shared_data);  // Cheap clone
let clone2 = Arc::clone(&shared_data);  // Cheap clone

// ✅ DO: Take ownership when needed
fn consume(data: Vec<User>) {
    // Takes ownership, no clone needed
}
```

### 12.2 String Handling

```rust
// ❌ DON'T: Allocate strings unnecessarily
fn get_name(&self) -> String {
    self.name.clone()  // Allocates new string
}

// ✅ DO: Return references when possible
fn name(&self) -> &str {
    &self.name
}

// ✅ DO: Use Cow for optional allocation
use std::borrow::Cow;

fn process_name(name: &str) -> Cow<str> {
    if name.is_ascii() {
        Cow::Borrowed(name)  // No allocation
    } else {
        Cow::Owned(name.to_uppercase())  // Allocation only when needed
    }
}
```

### 12.3 Collection Pre-allocation

```rust
// ❌ DON'T: Grow collections incrementally
let mut results = Vec::new();
for item in items {
    results.push(process(item));  // May reallocate multiple times
}

// ✅ DO: Pre-allocate when size is known
let mut results = Vec::with_capacity(items.len());
for item in items {
    results.push(process(item));  // No reallocations
}

// ✅ DO: Use collect with size hint
let results: Vec<_> = items.iter()
    .map(process)
    .collect();  // Iterator provides size hint
```

---

## 13. Code Style

### 13.1 Formatting

```rust
// Use rustfmt defaults with these overrides in rustfmt.toml:
// max_width = 100
// tab_spaces = 4
// use_small_heuristics = "Max"

// ✅ DO: Keep lines under 100 characters
let result = some_function(
    argument_one,
    argument_two,
    argument_three,
);

// ✅ DO: Use trailing commas
struct Config {
    host: String,
    port: u16,
    timeout: Duration,  // Trailing comma
}

// ✅ DO: Align match arms
match status {
    Status::Active   => handle_active(),
    Status::Inactive => handle_inactive(),
    Status::Pending  => handle_pending(),
}
```

### 13.2 Control Flow

```rust
// ✅ DO: Use early returns
fn process(input: Option<String>) -> Result<String, Error> {
    let input = match input {
        Some(s) => s,
        None => return Err(Error::MissingInput),
    };
    
    if input.is_empty() {
        return Err(Error::EmptyInput);
    }
    
    // Main logic here
    Ok(input.to_uppercase())
}

// ✅ DO: Use if let for single-pattern matching
if let Some(user) = optional_user {
    process_user(user);
}

// ✅ DO: Use while let for iteration
while let Some(item) = iterator.next() {
    process_item(item);
}

// ✅ DO: Use ? for error propagation
fn fetch_and_process() -> Result<Data, Error> {
    let raw = fetch_data()?;
    let parsed = parse_data(raw)?;
    let processed = process_data(parsed)?;
    Ok(processed)
}
```

### 13.3 Comments

```rust
// ✅ DO: Explain "why", not "what"
// Use SHA-256 instead of SHA-1 for LDK compatibility
let hash = sha256(&data);

// ❌ DON'T: State the obvious
// Increment counter by 1
counter += 1;

// ✅ DO: Use TODO/FIXME/HACK with context
// TODO(#123): Implement rate limiting after MVP
// FIXME: This will panic if connection pool is exhausted
// HACK: Workaround for diesel issue #1234, remove after upgrade

// ✅ DO: Document complex algorithms
// Binary search with custom comparator:
// 1. Start with full range [0, len)
// 2. Calculate midpoint and compare
// 3. Narrow range based on comparison
// 4. Repeat until found or range is empty
```

---

## Quick Reference Card

```
╔═══════════════════════════════════════════════════════════════════╗
║                    RUST CODING CONVENTIONS                         ║
╠═══════════════════════════════════════════════════════════════════╣
║                                                                    ║
║  NAMING                                                            ║
║  ├─ Modules/Functions/Variables: snake_case                        ║
║  ├─ Types/Traits/Enums: PascalCase                                 ║
║  ├─ Constants: SCREAMING_SNAKE_CASE                                ║
║  ├─ Services: NounService (PaymentService)                         ║
║  ├─ Repositories: NounRepository (UserRepository)                  ║
║  └─ Errors: DomainError (ServiceError, RepositoryError)            ║
║                                                                    ║
║  ERROR HANDLING                                                    ║
║  ├─ Use Result<T, E> for fallible operations                       ║
║  ├─ Implement From<SourceError> for TargetError                    ║
║  ├─ Use ? operator for propagation                                 ║
║  ├─ Use early returns for validation                               ║
║  └─ NEVER use unwrap() in production                               ║
║                                                                    ║
║  ASYNC                                                             ║
║  ├─ Use async/await for I/O operations                             ║
║  ├─ Use Arc<T> for shared async state                              ║
║  ├─ Use #[async_trait] for async traits                            ║
║  └─ Use spawn_blocking for CPU-intensive work                      ║
║                                                                    ║
║  LOGGING                                                           ║
║  ├─ Target: node_backend::<module>::<submodule>                    ║
║  ├─ error! → System failures, unrecoverable                        ║
║  ├─ warn!  → Unexpected but handled                                ║
║  ├─ info!  → Business events                                       ║
║  ├─ debug! → Development details                                   ║
║  └─ NEVER log sensitive data (passwords, keys, tokens)             ║
║                                                                    ║
║  DATABASE                                                          ║
║  ├─ Use repository pattern with traits                             ║
║  ├─ Use Diesel query builder (prevents SQL injection)              ║
║  ├─ Use transactions for multiple operations                       ║
║  └─ NEVER use format!() in SQL queries                             ║
║                                                                    ║
║  TESTING                                                           ║
║  ├─ Name: test_<function>_<scenario>_<expected>                    ║
║  ├─ Use #[tokio::test] for async tests                             ║
║  └─ Mock external dependencies                                     ║
║                                                                    ║
╚═══════════════════════════════════════════════════════════════════╝
```

---

*These conventions are based on official Rust style guidelines, Axum best practices, and project-specific requirements.*

