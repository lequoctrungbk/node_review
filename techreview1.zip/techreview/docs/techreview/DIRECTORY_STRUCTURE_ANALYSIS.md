# Directory Structure Analysis

> **Analysis Date:** 2025-01-18  
> **Project:** Node - Lightning Network Operating System

---

## Current Directory Tree Overview

```
node/
├── .cursor/                    # IDE configuration
├── config/                     # Brand configuration
├── data/                       # Static JSON data
├── docs/                       # Documentation (70+ files)
├── infra/                      # Infrastructure scripts
├── migrations/                 # Database migrations (⚠️ misplaced)
├── node_modules/               # Dependencies
├── packages/
│   ├── backend/                # Rust backend (726 files)
│   └── node-ui/                # React frontend (427 files)
├── scripts/                    # Utility scripts
├── specs/                      # Feature specifications
├── sprints/                    # Sprint documentation
├── tests/                      # Integration tests (⚠️ misplaced)
├── tools/                      # Additional tools
├── AGENTS.md                   # Coding conventions
├── CLAUDE.md                   # AI assistant config
├── Makefile
├── migration-plan.md           # (⚠️ misplaced)
├── notes.md                    # (⚠️ should not be in repo)
├── package.json                # Root package
├── README.md
├── TODO.md                     # (⚠️ misplaced)
└── yarn.lock
```

---

## 🔴 Critical Issues

### Issue 1: Migrations Outside Package Directory

**Current:**
```
node/
├── migrations/                 # ❌ At root level
│   ├── 2025-11-16.../
│   └── 2025-11-17.../
└── packages/
    └── backend/
        └── migrations/         # ✅ Should be here (if exists)
```

**Problem:**
- Migrations belong to backend package
- Diesel expects migrations in crate root
- Causes confusion about ownership

**Recommendation:**
```
packages/backend/
└── migrations/                 # Move here
    ├── 2025-11-16.../
    └── 2025-11-17.../
```

---

### Issue 2: Tests Directory at Root Level

**Current:**
```
node/
├── tests/                      # ❌ At root level
│   ├── conversation_service_tests.rs
│   ├── helpers/
│   ├── rathole_endpoints.http
│   └── unit/
```

**Problem:**
- Rust tests outside the crate
- Integration tests scattered
- `.http` test files mixed with Rust tests

**Recommendation:**
```
packages/backend/
├── src/
├── tests/                      # Integration tests
│   ├── conversation_service_tests.rs
│   └── helpers/
└── http-tests/                 # API test files
    └── rathole_endpoints.http
```

---

### Issue 3: Documentation Sprawl

**Current State:** Documentation in **7+ different locations**

```
node/
├── docs/                       # Main docs (70+ files)
│   ├── adr/
│   ├── api/
│   ├── architecture/
│   ├── features/
│   ├── techreview/
│   └── ... (many more)
├── specs/                      # Feature specs (90+ files)
├── sprints/                    # Sprint docs (50+ files)
├── migration-plan.md           # Root level
├── notes.md                    # Root level
└── TODO.md                     # Root level
```

**Problems:**
1. Hard to find relevant documentation
2. Unclear ownership (specs vs docs?)
3. Stale files at root level
4. Sprint-specific docs become stale

**Recommendation:**
```

node/
│
├── docs/                            # 📚 CENTRALIZED DOCUMENTATION
│   ├── README.md                    # Documentation index
│   ├── architecture/                # ADRs, system design
│   │   ├── decisions/               # Architecture Decision Records
│   │   └── diagrams/                # Mermaid, SVG diagrams
│   ├── api/                         # API documentation
│   │   ├── openapi/                 # OpenAPI specs (consolidated)
│   │   └── guides/
│   ├── deployment/                  # Deployment guides
│   ├── development/                 # Developer guides
│   └── features/                    # Feature documentation
```

---

### Issue 4: Scripts in Multiple Locations

**Current:**
```
node/
├── infra/
│   └── scripts/                # 47 shell scripts
├── scripts/                    # 7 files (mixed types)
│   ├── audit-rebrand.sh
│   ├── generate_review_docx.py
│   ├── mcp-server.js
│   └── test_ip_pool.sh
└── tools/
    └── scripts/                # 2 shell scripts
```

**Problem:**
- Scripts scattered across 3 directories
- Mixed purposes (infra vs dev vs tools)
- Unclear which to use

**Recommendation:**
```
scripts/
├── infra/                      # Infrastructure scripts
│   ├── deploy/
│   ├── docker/
│   └── systemd/
├── dev/                        # Development scripts
│   ├── test_ip_pool.sh
│   └── generate_review_docx.py
└── tools/                      # Utility tools
    ├── mcp-server.js
    └── audit-rebrand.sh
```

---

## 🟠 High Severity Issues

### Issue 5: Backend - Mixed Architecture Patterns

**Current Backend Structure:**
```
packages/backend/src/
├── activity/                   # Domain module ✅
├── ai_agents/                  # Domain module ✅
├── api_store/                  # Domain module ✅
├── auth/                       # Cross-cutting concern
├── bulletin_board/             # Domain module ✅
├── channel/                    # Domain module
├── conversation/               # Domain module ✅
├── conversational_ui/          # Domain module ✅
├── database/                   # Infrastructure ✅
├── dto/                        # Shared DTOs (⚠️ anti-pattern)
├── endpoints/                  # ❌ Breaks layered architecture
├── events/                     # Cross-cutting concern ✅
├── handlers/                   # ❌ Mixed handlers
├── l402/                       # Domain module ✅
├── ldk_recovery/               # Domain module ✅
├── llm/                        # Domain module ✅
├── message_queue/              # Infrastructure ✅
├── models/                     # ❌ Shared models (anti-pattern)
├── network/                    # Domain module ✅
├── node/                       # Domain module ✅
├── payment/                    # Domain module
├── peer/                       # Domain module
├── pi_uart_service/            # Domain module ✅
├── posts/                      # Domain module ✅
├── rathole/                    # Domain module ✅
├── repositories/               # ❌ Centralized repos (anti-pattern)
├── services/                   # ❌ Centralized services (anti-pattern)
├── social_network/             # Domain module ✅
├── terminal/                   # Domain module (partial)
├── transport/                  # Infrastructure ✅
├── updates/                    # Domain module
├── websocket/                  # Infrastructure ✅
├── config.rs
├── db_config.rs
├── error.rs
├── extractors.rs
├── lib.rs
├── main.rs                     # ⚠️ 1845 lines - God file
├── routes.rs
├── schema.rs
├── state.rs
└── utils.rs
```

**Problems:**

1. **Centralized `repositories/` folder (31 files)**
   - Violates domain isolation
   - Repositories should be within domain modules

2. **Centralized `services/` folder (28 files)**
   - Violates domain isolation
   - Services should be within domain modules

3. **Centralized `models/` folder (16 files)**
   - Shared models create coupling
   - Domain models should be internal

4. **`endpoints/` folder breaks architecture**
   - 15 endpoint files at root level
   - Should be within domain modules

5. **`handlers/` folder is mixed**
   - Contains multiple domain handlers
   - Unclear ownership

**Recommended Domain-Driven Structure:**
```
packages/backend/src/
├── domains/
│   ├── activity/
│   │   ├── mod.rs
│   │   ├── handlers.rs
│   │   ├── service.rs
│   │   ├── repository.rs
│   │   └── models.rs
│   ├── ai_agents/
│   ├── api_store/
│   ├── conversation/
│   ├── l402/
│   ├── messaging/
│   ├── network/
│   ├── node/
│   ├── posts/
│   ├── rathole/
│   ├── social_network/
│   └── terminal/
├── shared/
│   ├── auth/
│   ├── database/
│   ├── events/
│   ├── transport/
│   └── websocket/
├── config.rs
├── error.rs
├── lib.rs
├── main.rs
└── routes.rs
```

---

### Issue 6: Frontend - Inconsistent Component Organization

**Current Frontend Structure:**
```
packages/node-ui/src/
├── components/
│   ├── agents/                 # Feature ✅
│   ├── ai-agent/               # ❌ Duplicate of agents?
│   ├── auth/                   # Feature ✅
│   ├── buddies/                # Feature ✅
│   ├── bulletin/               # Feature
│   ├── ConversationalUI/       # ❌ PascalCase folder
│   ├── CopyableTooltip.tsx     # ❌ Component at root
│   ├── dashboard/              # Feature
│   ├── ErrorBoundary.tsx       # ❌ Component at root
│   ├── ErrorMessage.tsx        # ❌ Component at root
│   ├── ip-pool/                # Feature
│   ├── l402/                   # Feature ✅
│   ├── layout/                 # ❌ Single file, should merge
│   ├── layouts/                # ❌ Duplicate of layout?
│   ├── ldk-recovery/           # Feature ✅
│   ├── LoadingSpinner.tsx      # ❌ Component at root
│   ├── messages/               # Feature ✅
│   ├── metrics/                # Feature ✅
│   ├── my-wallet/              # Feature ✅
│   ├── network/                # Feature ✅
│   ├── newsfeed/               # Feature ✅
│   ├── notifications/          # Feature ✅
│   ├── PageHeader.tsx          # ❌ Component at root
│   ├── providers/              # Cross-cutting ✅
│   ├── RollbackConfirmDialog.tsx    # ❌ Root level
│   ├── RollbackHistoryTable.tsx     # ❌ Root level
│   ├── RollbackNotificationBanner.tsx  # ❌ Root level
│   ├── settings/               # Feature ✅
│   ├── social/                 # Feature ✅
│   ├── StatusIndicator.tsx     # ❌ Component at root
│   ├── terminal/               # Feature ✅
│   ├── ui/                     # Base UI components ✅
│   ├── updates/                # Feature ✅
│   └── verification/           # Feature ✅
```

**Problems:**

1. **9 components at root level** - Should be in folders
2. **PascalCase folder** - `ConversationalUI/` inconsistent
3. **Duplicate folders** - `layout/` vs `layouts/`, `agents/` vs `ai-agent/`
4. **Rollback components scattered** - Should be in `rollback/` folder

**Recommendation:**
```
components/
├── features/                   # Feature-specific components
│   ├── agents/
│   ├── auth/
│   ├── conversational-ui/      # Rename, lowercase
│   ├── l402/
│   ├── messages/
│   ├── network/
│   ├── newsfeed/
│   ├── rollback/               # Group rollback components
│   ├── social/
│   ├── terminal/
│   └── wallet/
├── layout/                     # Merge layout + layouts
│   ├── MainLayout.tsx
│   ├── TopMenu.tsx
│   └── ...
├── shared/                     # Shared/reusable components
│   ├── CopyableTooltip.tsx
│   ├── ErrorBoundary.tsx
│   ├── ErrorMessage.tsx
│   ├── LoadingSpinner.tsx
│   ├── PageHeader.tsx
│   └── StatusIndicator.tsx
├── providers/                  # Context providers
└── ui/                         # Base UI components (shadcn)
```

---

### Issue 7: Frontend - API Files Scattered

**Current:**
```
packages/node-ui/src/lib/
├── activityApi.ts
├── aiAgentApi.ts
├── api/                        # ❌ Nested api folder
│   ├── conversational.ts
│   ├── ldk-recovery.ts
│   └── ... (7 files)
├── api.ts                      # ❌ God file (863 lines)
├── apiClient.ts
├── authApi.ts
├── buddiesApi.ts
├── friendAggregationApi.ts
├── ipPoolApi.ts
├── networkApi.ts
├── newsFeedApi.ts
├── ratholeApi.ts
├── socialApi.ts
├── terminalApi.ts
└── verificationApi.ts
```

**Problems:**
1. `api.ts` is 863 lines (God file)
2. Some APIs in `api/` folder, others at root
3. Inconsistent organization

**Recommendation:**
```
lib/
├── api/
│   ├── index.ts                # Re-exports
│   ├── client.ts               # Base client
│   ├── types.ts                # Shared types
│   ├── activity.ts
│   ├── agents.ts
│   ├── auth.ts
│   ├── buddies.ts
│   ├── conversational.ts
│   ├── ip-pool.ts
│   ├── l402.ts
│   ├── ldk-recovery.ts
│   ├── messages.ts
│   ├── network.ts
│   ├── newsfeed.ts
│   ├── node.ts
│   ├── payments.ts
│   ├── rathole.ts
│   ├── social.ts
│   ├── terminal.ts
│   └── verification.ts
└── ... (other utilities)
```

---

## 🟡 Medium Severity Issues

### Issue 8: Hooks Flat Structure

**Current:** 60+ hooks in flat directory
```
packages/node-ui/src/hooks/
├── useActivityLogs.ts
├── useAgentByUserId.ts
├── useAgentCreation.ts
├── useAIAgent.ts
├── useApiStoreTransactions.ts
├── useAuth.ts
├── ... (55+ more files)
```

**Recommendation:**
```
hooks/
├── index.ts                    # Re-exports
├── auth/
│   ├── useAuth.ts
│   └── useJwtToken.ts
├── agents/
│   ├── useAIAgent.ts
│   ├── useAgentByUserId.ts
│   └── useAgentCreation.ts
├── messaging/
│   ├── useMessages.ts
│   ├── useMessageDeliveryStatus.ts
│   └── useWebSocketMessage.ts
├── network/
│   ├── useNetwork.ts
│   ├── useNodeDetails.ts
│   └── useNodeStatus.ts
└── ... (grouped by domain)
```

---

### Issue 9: Types Flat Structure

**Current:** 29 type files in flat directory
```
packages/node-ui/src/types/
├── activity.ts
├── agent.ts
├── ai-agent.ts
├── api-store.ts
├── ... (25+ more files)
```

**Recommendation:** Keep flat but consider grouping if grows larger, or co-locate with features.

---

### Issue 10: Missing Standard Files

**Missing:**
```
packages/backend/
├── .env.example            # ❌ Missing
├── CHANGELOG.md            # ❌ Missing
└── CONTRIBUTING.md         # ❌ Missing

packages/node-ui/
├── .env.example            # ❌ Missing
└── CHANGELOG.md            # ❌ Missing
```

---

## 🟢 Low Severity Issues

### Issue 11: Inconsistent Naming Conventions

| Current | Problem | Recommended |
|---------|---------|-------------|
| `ConversationalUI/` | PascalCase folder | `conversational-ui/` |
| `my-wallet/` | Kebab-case ✅ | Keep |
| `ldk-recovery/` | Kebab-case ✅ | Keep |
| `ai-agent/` | Duplicate? | Merge with `agents/` |
| `newsFeedApi.ts` | camelCase | `newsfeed-api.ts` or `newsfeed.ts` |

---

### Issue 12: Empty/Stub Modules

```
packages/backend/src/
├── newsfeed/
│   └── mod.rs              # Only mod.rs, minimal content
├── channel/
│   ├── handlers.rs
│   └── mod.rs              # Minimal content
```

---

## Summary: Priority Actions

### 🔴 P0 - Critical (This Sprint)

| Issue | Action | Effort |
|-------|--------|--------|
| #1 | Move `migrations/` to `packages/backend/` | 1 hour |
| #2 | Move `tests/` to `packages/backend/` | 1 hour |
| #3 | Clean up root-level docs | 2 hours |

### 🟠 P1 - High (This Month)

| Issue | Action | Effort |
|-------|--------|--------|
| #5 | Refactor backend to DDD structure | 2-3 weeks |
| #6 | Organize frontend components | 1 week |
| #7 | Split `api.ts` into domain files | 3 days |

### 🟡 P2 - Medium (This Quarter)

| Issue | Action | Effort |
|-------|--------|--------|
| #4 | Consolidate scripts directories | 1 day |
| #8 | Group hooks by domain | 2 days |
| #9 | Review types organization | 1 day |

### 🟢 P3 - Low (Backlog)

| Issue | Action | Effort |
|-------|--------|--------|
| #10 | Add missing standard files | 2 hours |
| #11 | Fix naming conventions | 1 day |
| #12 | Clean up empty modules | 2 hours |

---

## Recommended Target Structure

### Root Level
```
node/
├── .cursor/                    # IDE config
├── .github/                    # GitHub workflows
├── docs/                       # All documentation
│   ├── adr/
│   ├── api/
│   ├── architecture/
│   ├── deployment/
│   ├── development/
│   ├── features/
│   ├── planning/
│   └── specs/
├── packages/
│   ├── backend/
│   └── node-ui/
├── scripts/
│   ├── dev/
│   ├── infra/
│   └── tools/
├── AGENTS.md
├── CHANGELOG.md
├── CONTRIBUTING.md
├── Makefile
├── package.json
├── README.md
└── yarn.lock
```

### Backend Package
```
packages/backend/
├── migrations/
├── src/
│   ├── domains/
│   │   ├── activity/
│   │   ├── agents/
│   │   ├── api_store/
│   │   ├── conversation/
│   │   ├── l402/
│   │   ├── messaging/
│   │   ├── network/
│   │   ├── node/
│   │   ├── posts/
│   │   ├── rathole/
│   │   ├── social/
│   │   └── terminal/
│   ├── shared/
│   │   ├── auth/
│   │   ├── database/
│   │   ├── events/
│   │   └── transport/
│   ├── config.rs
│   ├── error.rs
│   ├── lib.rs
│   ├── main.rs
│   └── routes.rs
├── tests/
├── http-tests/
├── .env.example
├── Cargo.toml
└── README.md
```

### Frontend Package
```
packages/node-ui/
├── src/
│   ├── components/
│   │   ├── features/
│   │   ├── layout/
│   │   ├── shared/
│   │   ├── providers/
│   │   └── ui/
│   ├── hooks/
│   │   ├── auth/
│   │   ├── agents/
│   │   ├── messaging/
│   │   └── network/
│   ├── lib/
│   │   ├── api/
│   │   └── utils/
│   ├── pages/
│   ├── router/
│   ├── services/
│   ├── types/
│   ├── App.tsx
│   └── main.tsx
├── .env.example
├── package.json
└── README.md
```

---

## References

- [Technical Debt Analysis](./technical-debt-analysis.md)
- [Domain-Driven Design Guide](../../domain-driven-architecture-guide.md)
- [Project Restructuring README](../../PROJECT_RESTRUCTURING_README.md)

