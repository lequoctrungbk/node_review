# Database Entity Relationship Diagram (ERD)

## Overview

This document provides comprehensive Entity Relationship Diagrams for the SQLite database, organized by functional domain.

**Total Tables**: 60+  
**Total Views**: 4  
**Foreign Key Relationships**: 30+  
**Date Generated**: December 18, 2025

---

## Domain 1: Users & Authentication

```mermaid
erDiagram
    users ||--o{ auth_challenges : "has"
    users ||--o{ refresh_tokens : "has"
    users ||--o{ notifications : "receives"
    users ||--o{ terminal_sessions : "owns"
    users ||--o{ ai_agents : "owns"
    users ||--o{ agent_templates : "creates"
    
    users {
        TEXT id PK
        TEXT public_key UK
        TEXT username
        TEXT created_at
        TEXT last_login
        TEXT device_info
        BOOLEAN is_primary_owner
        TEXT first_name
        TEXT last_name
        TEXT user_role
    }
    
    auth_challenges {
        TEXT id PK
        TEXT user_id FK
        TEXT challenge
        TEXT expires_at
        BOOLEAN used
        TEXT created_at
    }
    
    refresh_tokens {
        TEXT id PK
        TEXT user_id FK
        TEXT token_hash UK
        TEXT device_id
        BIGINT expires_at
        BOOLEAN is_revoked
        TEXT created_at
        TEXT last_used_at
    }
    
    notifications {
        TEXT id PK
        TEXT user_id FK
        TEXT notification_type
        TEXT content
        TEXT reference_id
        TEXT read_at
        TEXT dismissed_at
        TEXT created_at
    }
```

---

## Domain 2: Nodes & Network

```mermaid
erDiagram
    nodes ||--o{ friendships : "participates_as_node1"
    nodes ||--o{ friendships : "participates_as_node2"
    nodes ||--o{ friend_requests : "sends_from"
    nodes ||--o{ friend_requests : "receives_to"
    nodes ||--o{ node_ip_pool_entries : "has"
    nodes ||--o{ conversation_participants : "participates"
    nodes ||--o{ messages : "sends"
    
    nodes {
        TEXT id PK
        TEXT node_id UK
        TEXT friendly_name
        TIMESTAMP last_gossip_update
        INTEGER availability_score
        TIMESTAMP created_at
        TIMESTAMP updated_at
        TEXT version
        TEXT listening_addresses
        INTEGER api_port
        BIGINT timestamp
        TEXT features
        INTEGER rathole_port
        TEXT proxy_service_info
        INTEGER tls_enabled
        INTEGER is_public_reachable
        TEXT proxy_record_id
        TEXT public_accessibility
    }
    
    friendships {
        TEXT id PK
        TEXT node_id_1 FK
        TEXT node_id_2 FK
        TIMESTAMP established_at
        TEXT metadata
        TEXT discovery_method
    }
    
    friend_requests {
        TEXT id PK
        TEXT from_node_id FK
        TEXT to_node_id FK
        TEXT message
        TEXT status
        TIMESTAMP created_at
        TIMESTAMP responded_at
        TEXT direction
        TEXT l402_invoice
        TEXT l402_macaroon
        TIMESTAMP l402_paid_at
    }
    
    node_ip_pool_entries {
        TEXT id PK
        TEXT node_id FK
        TEXT ip_address
        INTEGER port
        TEXT port_type
        TEXT ip_source
        INTEGER priority
        BOOLEAN is_default
        BOOLEAN is_active
        BOOLEAN is_public_facing
        TIMESTAMP last_health_check
        TEXT connection_state
        INTEGER latency_ms
        REAL success_rate
        INTEGER consecutive_failures
    }
```

---

## Domain 3: Conversations & Messaging

```mermaid
erDiagram
    conversations ||--o{ messages : "contains"
    conversations ||--o{ conversation_participants : "has"
    nodes ||--o{ messages : "sends"
    
    conversations {
        TEXT id PK
        TIMESTAMP created_at
        TIMESTAMP updated_at
        INTEGER unread_count
    }
    
    messages {
        TEXT id PK
        TEXT conversation_id FK
        TEXT sender_id FK
        TEXT message
        TIMESTAMP timestamp
        TIMESTAMP read_at
        TEXT status
    }
    
    conversation_participants {
        TEXT conversation_id PK_FK
        TEXT node_id PK_FK
        TIMESTAMP last_read_at
        TIMESTAMP joined_at
    }
    
    message_queue {
        TEXT message_id PK
        TEXT sender_node_id
        TEXT recipient_node_id
        BLOB content
        TEXT status
        INTEGER retry_count
        TIMESTAMP next_retry_at
        TIMESTAMP created_at
        TIMESTAMP delivered_at
        TEXT conversation_id
        TEXT delivery_method
        TEXT l402_invoice_id
    }
```

---

## Domain 4: AI Agents & Executions

```mermaid
erDiagram
    users ||--o{ ai_agents : "owns"
    llm_configurations ||--o{ ai_agents : "configures"
    ai_agents ||--o{ agent_executions : "runs"
    ai_agents ||--o{ agent_execution_steps : "logs"
    ai_agents ||--o{ agent_schedules : "has"
    ai_agents ||--o{ agent_collaborations : "collaborates"
    agent_executions ||--o{ agent_execution_steps : "contains"
    users ||--o{ agent_templates : "creates"
    
    ai_agents {
        TEXT agent_id PK
        TEXT owner_user_id FK
        TEXT name
        TEXT description
        TEXT agent_type
        TEXT config
        TEXT status
        TIMESTAMP created_at
        TIMESTAMP updated_at
        TIMESTAMP last_executed_at
        TIMESTAMP next_execution_at
        INTEGER execution_count
        INTEGER error_count
        TEXT last_error
        INTEGER cost_limit_sats
        INTEGER total_cost_sats
        TEXT agent_user_id
        INTEGER llm_config_id FK
        TEXT preferred_model
    }
    
    agent_executions {
        TEXT execution_id PK
        TEXT agent_id FK
        TEXT execution_type
        TEXT status
        TIMESTAMP started_at
        TIMESTAMP completed_at
        INTEGER duration_ms
        INTEGER cost_sats
        INTEGER revenue_sats
        TEXT output_data
        TEXT error_message
        TEXT resource_usage
        INTEGER total_tokens
        INTEGER total_cost_sats
        TEXT summary
        TEXT description
    }
    
    agent_execution_steps {
        INTEGER id PK
        TEXT execution_id FK
        TEXT agent_id FK
        TEXT step_type
        INTEGER step_index
        INTEGER turn_index
        TEXT tool_name
        TEXT tool_call_id
        TEXT input_data
        TEXT output_data
        TEXT error_message
        TEXT outcome
        TIMESTAMP started_at
        TIMESTAMP completed_at
        INTEGER duration_ms
        INTEGER tokens_used
        REAL memory_mb
        REAL cpu_percent
        TEXT metadata
    }
    
    agent_schedules {
        TEXT schedule_id PK
        TEXT agent_id FK
        TEXT schedule_type
        TEXT schedule_expression
        TEXT timezone
        BOOLEAN is_active
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }
    
    agent_templates {
        TEXT template_id PK
        TEXT creator_user_id FK
        TEXT name
        TEXT description
        TEXT category
        TEXT template_config
        INTEGER price_sats
        INTEGER usage_count
        REAL rating
        INTEGER rating_count
        BOOLEAN is_public
    }
    
    agent_collaborations {
        TEXT collaboration_id PK
        TEXT agent_id FK
        TEXT target_node_id
        TEXT target_agent_id
        TEXT collaboration_type
        TEXT terms
        TEXT status
        TIMESTAMP created_at
        TIMESTAMP last_interaction_at
        INTEGER total_payments_sats
    }
    
    llm_configurations {
        INTEGER id PK
        TEXT user_id
        TEXT name
        TEXT description
        TEXT provider
        TEXT api_key
        TEXT model
        TEXT base_url
        INTEGER max_tokens
        REAL temperature
        TEXT extra_options
        BOOLEAN is_active
        BOOLEAN is_default
        TEXT config_type
        INTEGER total_tokens_used
        INTEGER total_cost_sats
    }
```

---

## Domain 5: Social & Content

```mermaid
erDiagram
    ai_posts ||--o{ post_interactions : "has"
    ai_posts ||--o{ post_verifications : "verified_by"
    ai_posts ||--o{ social_feeds : "appears_in"
    ai_posts ||--o{ ai_metadata_jobs : "generates"
    
    ai_posts {
        TEXT post_id PK
        TEXT author_user_id
        TEXT content
        TEXT ai_metadata
        TEXT visibility
        INTEGER tips_received_msats
        REAL engagement_score
        TIMESTAMP created_at
        TIMESTAMP updated_at
        TEXT post_source
        TIMESTAMP expires_at
        TEXT original_node_id
        TEXT status
        TEXT signature
        TEXT signature_method
    }
    
    post_interactions {
        TEXT id PK
        TEXT post_id FK
        TEXT user_id
        TEXT interaction_type
        TEXT content
        TIMESTAMP created_at
    }
    
    post_verifications {
        INTEGER id PK
        TEXT post_id FK
        TEXT author_user_id
        TEXT signature
        TEXT verification_status
        TIMESTAMP verification_timestamp
        TEXT verification_error
        TEXT verified_by_node_id
        TEXT signature_method
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }
    
    social_feeds {
        TEXT id PK
        TEXT user_id
        TEXT post_id FK
        TEXT source_type
        TEXT source_id
        TIMESTAMP created_at
        BOOLEAN is_read
    }
    
    ai_metadata_jobs {
        TEXT job_id PK
        TEXT post_id FK
        TEXT status
        INTEGER attempts
        INTEGER max_attempts
        TEXT error_message
        TIMESTAMP scheduled_at
        TIMESTAMP started_at
        TIMESTAMP completed_at
    }
```

---

## Domain 6: L402 Payments & Invoices

```mermaid
erDiagram
    l402_endpoint_fees ||--o{ l402_invoices : "charges"
    
    l402_endpoint_fees {
        TEXT id PK
        TEXT endpoint_path UK
        TEXT http_method
        INTEGER fee_sats
        TEXT description
        BOOLEAN is_active
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }
    
    l402_invoices {
        TEXT id PK
        TEXT invoice_id UK
        TEXT payment_hash UK
        TEXT payment_preimage
        TEXT invoice_bolt11
        TEXT endpoint_path FK
        INTEGER amount_sats
        TEXT status
        TEXT macaroon_token
        TIMESTAMP expires_at
        TIMESTAMP paid_at
        TIMESTAMP created_at
    }
    
    l402_outbound_payments {
        TEXT id PK
        TEXT target_node_id
        TEXT endpoint_path
        TEXT http_method
        TEXT payment_hash UK
        TEXT payment_preimage
        TEXT invoice_bolt11
        INTEGER amount_sats
        TEXT status
        TEXT error_message
        INTEGER latency_ms
        TIMESTAMP paid_at
        TIMESTAMP created_at
    }
    
    l402_budget_configs {
        TEXT id PK
        TEXT config_type UK
        INTEGER max_amount_sats
        BOOLEAN is_active
        INTEGER alert_threshold_percent
        TIMESTAMP current_period_start
        INTEGER current_period_spent_sats
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }
    
    l402_analytics_daily {
        TEXT id PK
        DATE date
        TEXT direction
        INTEGER total_requests
        INTEGER successful_payments
        INTEGER failed_payments
        INTEGER total_amount_sats
        REAL avg_amount_sats
        TEXT top_endpoints
        TEXT top_nodes
        TIMESTAMP created_at
    }
```

---

## Domain 7: API Store & LLM Management

```mermaid
erDiagram
    api_store_llm_platforms ||--o{ api_store_llm_models : "provides"
    api_store_codes ||--o{ api_store_llm_platforms : "defines_response_format"
    
    api_store_llm_platforms {
        INTEGER id PK
        TEXT name UK
        TEXT status
        TEXT api_key
        TIMESTAMP created_at
        TIMESTAMP updated_at
        BOOLEAN is_default
        INTEGER code_id FK
    }
    
    api_store_llm_models {
        INTEGER id PK
        INTEGER llm_platform_id FK
        TEXT name
        TEXT status
        REAL input_price_per_million
        REAL output_price_per_million
        TEXT currency
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }
    
    api_store_codes {
        INTEGER id PK
        TEXT code UK
        TEXT description
        TEXT response_path
        TEXT error_path
        TEXT input_tokens_path
        TEXT output_tokens_path
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }
    
    api_store_credits {
        INTEGER id PK
        TEXT user_id UK
        INTEGER balance_sats
        INTEGER total_purchased_sats
        INTEGER total_used_sats
        TIMESTAMP last_topup_at
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }
    
    api_store_credit_transactions {
        INTEGER id PK
        TEXT user_id
        TEXT transaction_type
        INTEGER amount_sats
        INTEGER balance_after_sats
        TEXT description
        TEXT l402_invoice_id
        INTEGER prompt_tokens
        INTEGER completion_tokens
        INTEGER total_tokens
        TEXT llm_service
        TEXT model
        TEXT correlation_id
        TIMESTAMP created_at
    }
    
    api_store_tools {
        INTEGER id PK
        TEXT name UK
        TEXT description
        TEXT prompt
        TEXT params
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }
```

---

## Domain 8: Terminal & Shell

```mermaid
erDiagram
    users ||--o{ terminal_sessions : "owns"
    terminal_sessions ||--o{ terminal_history : "logs"
    terminal_sessions ||--o{ terminal_session_shares : "shared_via"
    users ||--o{ terminal_saved_commands : "saves"
    
    terminal_sessions {
        TEXT id PK
        TEXT user_id FK
        TEXT created_at
        TEXT last_activity
        TEXT status
        INTEGER pid
        TEXT shell
        INTEGER cols
        INTEGER rows
    }
    
    terminal_history {
        TEXT id PK
        TEXT session_id FK
        TEXT user_id FK
        TEXT command
        TEXT timestamp
    }
    
    terminal_session_shares {
        TEXT id PK
        TEXT session_id FK
        TEXT owner_user_id FK
        TEXT shared_with_user_id FK
        TEXT permission
        TEXT created_at
        TEXT expires_at
    }
    
    terminal_saved_commands {
        TEXT id PK
        TEXT user_id FK
        TEXT name
        TEXT description
        TEXT command_template
        TEXT category
        TEXT tags
        INTEGER is_template
        INTEGER use_count
        TEXT created_at
        TEXT last_used_at
    }
```

---

## Domain 9: Conversational UI

```mermaid
erDiagram
    conversational_ui_conversations ||--o{ conversational_ui_messages : "contains"
    saved_components ||--o{ component_conversations : "linked_to"
    conversational_ui_conversations ||--o{ component_conversations : "links"
    
    conversational_ui_conversations {
        TEXT id PK
        TEXT user_id
        TEXT title
        TIMESTAMP created_at
        TIMESTAMP updated_at
        TIMESTAMP last_message_at
        INTEGER message_count
        BOOLEAN is_archived
        TEXT metadata
    }
    
    conversational_ui_messages {
        TEXT id PK
        TEXT conversation_id FK
        TEXT role
        TEXT content
        TIMESTAMP timestamp
        TEXT metadata
    }
    
    saved_components {
        INTEGER id PK
        TEXT user_id
        TEXT name
        TEXT description
        TEXT component_code
        TEXT component_data
        TEXT query
        TEXT tools_used
        TIMESTAMP created_at
        TIMESTAMP updated_at
        TIMESTAMP last_accessed_at
        INTEGER access_count
        BOOLEAN is_favorite
        TEXT tags
    }
    
    component_conversations {
        INTEGER component_id PK_FK
        TEXT conversation_id PK_FK
        TIMESTAMP created_at
    }
```

---

## Domain 10: System Monitoring & Metrics

```mermaid
erDiagram
    system_metrics {
        INTEGER id PK
        DATETIME timestamp
        REAL cpu_usage_percent
        TEXT cpu_history
        BIGINT memory_used_bytes
        BIGINT memory_total_bytes
        REAL memory_usage_percent
        BIGINT disk_used_bytes
        BIGINT disk_total_bytes
        REAL disk_usage_percent
        REAL network_upload_mbps
        REAL network_download_mbps
        TEXT network_upload_history
        TEXT network_download_history
    }
    
    transport_metrics {
        TEXT id PK
        INTEGER timestamp
        TEXT protocol
        TEXT event_type
        INTEGER latency_ms
        INTEGER bytes_transferred
        BOOLEAN success
        TEXT error_code
        BOOLEAN l402_payment_made
        INTEGER payment_amount_msat
        TEXT node_id
        TEXT endpoint
        TIMESTAMP created_at
    }
    
    transport_metrics_hourly {
        TEXT id PK
        INTEGER hour_timestamp
        TEXT protocol
        INTEGER total_requests
        INTEGER successful_requests
        INTEGER failed_requests
        REAL avg_latency_ms
        INTEGER p50_latency_ms
        INTEGER p95_latency_ms
        INTEGER p99_latency_ms
        INTEGER total_bytes_transferred
        INTEGER total_l402_payments
        INTEGER total_payment_amount_msat
        TIMESTAMP created_at
    }
```

---

## Domain 11: Events & Job Queue

```mermaid
erDiagram
    events {
        INTEGER id PK
        TEXT event_type
        TEXT entity_type
        TEXT entity_id
        TEXT state
        TEXT correlation_id
        TEXT payload
        TEXT created_at
    }
    
    event_bus_jobs {
        INTEGER id PK
        TEXT bus_type
        TEXT event_data
        TEXT status
        TEXT error_message
        INTEGER attempts
        INTEGER max_attempts
        TEXT created_at
        TEXT processed_at
    }
```

---

## Domain 12: Network Discovery & Blacklist

```mermaid
erDiagram
    auto_discovery_events {
        INTEGER id PK
        TEXT node_id
        INTEGER gossip_timestamp
        INTEGER processed_at
        TEXT discovery_result
        TEXT failure_reason
        TIMESTAMP created_at
    }
    
    auto_discovery_retry_state {
        INTEGER id PK
        TEXT node_id UK
        INTEGER retry_count
        INTEGER last_attempt_at
        INTEGER next_retry_at
        TEXT retry_state
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }
    
    blacklisted_nodes {
        INTEGER id PK
        TEXT node_id UK
        INTEGER violation_count
        INTEGER first_violation_at
        INTEGER banned_until
        TEXT reason
        TEXT banned_by
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }
```

---

## Domain 13: Backups & Rollbacks

```mermaid
erDiagram
    backups ||--o{ rollback_events : "source_for"
    rollback_events ||--o{ rollback_checkpoints : "has"
    
    backups {
        TEXT backup_id PK
        TIMESTAMP created_at
        TEXT version
        INTEGER size_bytes
        TEXT checksum
        TEXT backup_path
        BOOLEAN includes_database
        BOOLEAN includes_config
        BOOLEAN is_stable
        TIMESTAMP stable_at
        TEXT schema_version
    }
    
    rollback_events {
        TEXT event_id PK
        TIMESTAMP triggered_at
        TIMESTAMP completed_at
        TEXT from_version
        TEXT to_version
        TEXT trigger_type
        TEXT outcome
        TEXT failure_reason
        TEXT health_check_results
        TEXT triggered_by_user_id
        TEXT source_backup_id FK
    }
    
    rollback_checkpoints {
        TEXT checkpoint_id PK
        TEXT rollback_event_id FK
        TIMESTAMP created_at
        TEXT stage
        BOOLEAN completed
        TEXT error_message
    }
    
    update_health_checks {
        TEXT check_id PK
        TEXT version
        TIMESTAMP checked_at
        TEXT service_status
        BOOLEAN api_responsive
        INTEGER error_count
        BOOLEAN crash_detected
        INTEGER stability_score
    }
```

---

## Domain 14: Proxy Services

```mermaid
erDiagram
    proxy_registrations {
        TEXT id PK
        TEXT client_node_id UK
        TEXT client_public_key
        INTEGER assigned_api_port
        INTEGER assigned_lightning_port
        TEXT api_port_token
        TEXT lightning_port_token
        TIMESTAMP expires_at
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }
    
    client_proxy_registrations {
        TEXT id PK
        TEXT target_node_id
        TEXT target_node_address
        TEXT proxy_server_address
        TEXT service_type
        INTEGER assigned_port
        TEXT port_token
        TEXT public_address
        TIMESTAMP expires_at
        TIMESTAMP created_at
        TIMESTAMP updated_at
        BOOLEAN is_active
    }
    
    port_allocations {
        TEXT id PK
        INTEGER port UK
        TEXT allocation_type
        TEXT allocated_to
        TIMESTAMP allocated_at
        TIMESTAMP expires_at
        TEXT notes
    }
```

---

## Domain 15: Settings & Configuration

```mermaid
erDiagram
    settings {
        TEXT key PK
        TEXT value
    }
    
    node_onboarding_state {
        TEXT id PK
        BOOLEAN onboarded
        TEXT onboarded_at
        BOOLEAN hardware_reset_active
        TEXT created_at
        TEXT updated_at
    }
    
    onboarding_challenges {
        TEXT id PK
        TEXT challenge
        TEXT expires_at
        BOOLEAN used
        TEXT created_at
    }
    
    hardware_reset_events {
        TEXT id PK
        TEXT reset_type
        TEXT triggered_at
        TEXT previous_owner_public_key
        TEXT reset_reason
    }
    
    friend_post_fetch_settings {
        TEXT user_id PK
        BOOLEAN enabled
        INTEGER fetch_interval_minutes
        INTEGER max_posts_per_friend
        INTEGER cache_duration_hours
        TIMESTAMP last_fetch_at
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }
```

---

## Master ERD: Core Relationships

This diagram shows the main relationships between core entities:

```mermaid
erDiagram
    users ||--o{ ai_agents : owns
    users ||--o{ terminal_sessions : owns
    users ||--o{ notifications : receives
    users ||--o{ refresh_tokens : has
    
    nodes ||--o{ friendships : participates
    nodes ||--o{ friend_requests : sends_receives
    nodes ||--o{ messages : sends
    nodes ||--o{ node_ip_pool_entries : has_ips
    
    conversations ||--o{ messages : contains
    conversations ||--o{ conversation_participants : has
    
    ai_agents ||--o{ agent_executions : runs
    agent_executions ||--o{ agent_execution_steps : logs
    ai_agents ||--o{ agent_schedules : scheduled_by
    
    ai_posts ||--o{ post_interactions : has
    ai_posts ||--o{ post_verifications : verified
    ai_posts ||--o{ social_feeds : appears_in
    
    l402_endpoint_fees ||--o{ l402_invoices : charges
    
    api_store_llm_platforms ||--o{ api_store_llm_models : provides
    
    conversational_ui_conversations ||--o{ conversational_ui_messages : contains
    
    backups ||--o{ rollback_events : source_for
    rollback_events ||--o{ rollback_checkpoints : tracks
```

---

## Database Statistics

### Table Count by Domain

| Domain | Tables | Views | Total |
|--------|--------|-------|-------|
| Users & Auth | 3 | 0 | 3 |
| Nodes & Network | 4 | 1 | 5 |
| Conversations | 3 | 0 | 3 |
| AI Agents | 6 | 2 | 8 |
| Social & Content | 5 | 0 | 5 |
| L402 Payments | 5 | 0 | 5 |
| API Store | 6 | 1 | 7 |
| Terminal | 4 | 0 | 4 |
| Conversational UI | 3 | 0 | 3 |
| System Metrics | 3 | 0 | 3 |
| Events & Jobs | 2 | 0 | 2 |
| Network Discovery | 3 | 0 | 3 |
| Backups & Rollbacks | 4 | 0 | 4 |
| Proxy Services | 3 | 0 | 3 |
| Settings | 5 | 0 | 5 |
| **TOTAL** | **59** | **4** | **63** |

### Relationship Types

| Type | Count | Examples |
|------|-------|----------|
| One-to-Many | 45+ | users → ai_agents, nodes → messages |
| Many-to-Many | 5+ | component_conversations, conversation_participants |
| Self-Referential | 2 | friendships (node-to-node) |

### Key Design Patterns

1. **Soft Deletes**: Several tables use status fields instead of hard deletes
2. **Audit Trails**: created_at/updated_at timestamps on most tables
3. **Time-Series**: Metrics tables with timestamp-based partitioning
4. **Queue Tables**: message_queue, event_bus_jobs with retry logic
5. **JSON Storage**: Extensive use of TEXT fields for JSON data
6. **UUID Primary Keys**: Most tables use TEXT UUIDs instead of INTEGER
7. **Composite Keys**: Several junction tables use composite primary keys

---

## Cardinality Legend

- `||--o{` : One-to-Many (one parent, many children)
- `}o--o{` : Many-to-Many (many parents, many children)
- `||--||` : One-to-One (strict relationship)
- `PK` : Primary Key
- `FK` : Foreign Key
- `UK` : Unique Key

---

## Notes

1. **Growing Tables**: 26 tables identified as high-growth (see GROWING_DATA_TABLES_ANALYSIS.md)
2. **Nullable PKs**: 15 tables have nullable primary keys (see NULLABLE_PRIMARY_KEYS_ISSUE.md)
3. **Timestamp Inconsistency**: Mix of TEXT and INTEGER/TIMESTAMP types
4. **Missing FKs**: Some relationships are implicit (e.g., message_queue node references)
5. **JSON Fields**: ~30 tables use TEXT fields for JSON storage

---

**Document Version**: 1.0  
**Generated**: December 18, 2025  
**Total Entities**: 59 tables + 4 views  
**Foreign Keys**: 30+ explicit relationships  
**Tool Used**: Mermaid ERD Syntax

