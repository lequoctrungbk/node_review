# Critical Issue: Nullable Primary Keys

## Executive Summary

**Severity: HIGH**  
**Impact: Data Integrity Violation**  
**Tables Affected: 15**

Primary keys should **NEVER** be nullable. This violates fundamental database design principles and can lead to data integrity issues.

---

## Tables with Nullable Primary Keys

### Category 1: INTEGER AUTOINCREMENT (Technically Safe)

These tables use `INTEGER PRIMARY KEY AUTOINCREMENT`, which SQLite automatically makes NOT NULL in practice, but the schema definition doesn't explicitly declare NOT NULL:

```sql
-- ⚠️ Missing explicit NOT NULL declaration
CREATE TABLE agent_execution_steps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,  -- Implicitly NOT NULL
    ...
);

CREATE TABLE api_store_credit_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ...
);

CREATE TABLE event_bus_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ...
);

CREATE TABLE events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ...
);

CREATE TABLE post_verifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ...
);

CREATE TABLE saved_components (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ...
);

CREATE TABLE system_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ...
);
```

**Status**: ✅ **Functionally Safe** (SQLite enforces NOT NULL for INTEGER PRIMARY KEY)  
**Issue**: ❌ **Schema Definition Issue** (should explicitly declare NOT NULL)

---

### Category 2: TEXT PRIMARY KEY with DEFAULT (Potentially Risky)

These tables use TEXT primary keys with DEFAULT values, but don't explicitly declare NOT NULL:

```sql
-- ⚠️ NULLABLE TEXT PRIMARY KEY
CREATE TABLE users (
    id TEXT PRIMARY KEY DEFAULT (hex(randomblob(16))),
    ...
);

CREATE TABLE auth_challenges (
    id TEXT PRIMARY KEY DEFAULT (hex(randomblob(16))),
    ...
);

CREATE TABLE hardware_reset_events (
    id TEXT PRIMARY KEY DEFAULT (hex(randomblob(16))),
    ...
);

CREATE TABLE message_queue (
    message_id TEXT PRIMARY KEY DEFAULT (hex(randomblob(16))),
    ...
);

CREATE TABLE node_onboarding_state (
    id TEXT PRIMARY KEY DEFAULT (hex(randomblob(16))),
    ...
);

CREATE TABLE onboarding_challenges (
    id TEXT PRIMARY KEY DEFAULT (hex(randomblob(16))),
    ...
);

CREATE TABLE refresh_tokens (
    id TEXT PRIMARY KEY,  -- ❌ NO DEFAULT!
    ...
);
```

**Status**: ⚠️ **Potentially Risky**  
**Risk**: If application code provides NULL explicitly, SQLite will accept it for TEXT columns

---

### Category 3: Special Case - Composite-like Primary Key

```sql
CREATE TABLE friend_post_fetch_settings (
    user_id TEXT PRIMARY KEY,  -- ⚠️ Nullable
    ...
);
```

**Status**: ⚠️ **Should be NOT NULL**

---

## Complete List of Affected Tables

| # | Table Name | PK Column | Type | Risk Level | Auto-generated? |
|---|------------|-----------|------|------------|-----------------|
| 1 | `agent_execution_steps` | `id` | INTEGER | LOW | ✅ AUTOINCREMENT |
| 2 | `api_store_credit_transactions` | `id` | INTEGER | LOW | ✅ AUTOINCREMENT |
| 3 | `auth_challenges` | `id` | TEXT | MEDIUM | ✅ DEFAULT |
| 4 | `event_bus_jobs` | `id` | INTEGER | LOW | ✅ AUTOINCREMENT |
| 5 | `events` | `id` | INTEGER | LOW | ✅ AUTOINCREMENT |
| 6 | `friend_post_fetch_settings` | `user_id` | TEXT | **HIGH** | ❌ NO DEFAULT |
| 7 | `hardware_reset_events` | `id` | TEXT | MEDIUM | ✅ DEFAULT |
| 8 | `message_queue` | `message_id` | TEXT | MEDIUM | ✅ DEFAULT |
| 9 | `node_onboarding_state` | `id` | TEXT | MEDIUM | ✅ DEFAULT |
| 10 | `onboarding_challenges` | `id` | TEXT | MEDIUM | ✅ DEFAULT |
| 11 | `post_verifications` | `id` | INTEGER | LOW | ✅ AUTOINCREMENT |
| 12 | `refresh_tokens` | `id` | TEXT | **HIGH** | ❌ NO DEFAULT |
| 13 | `saved_components` | `id` | INTEGER | LOW | ✅ AUTOINCREMENT |
| 14 | `system_metrics` | `id` | INTEGER | LOW | ✅ AUTOINCREMENT |
| 15 | `users` | `id` | TEXT | MEDIUM | ✅ DEFAULT |

---

## Why This Is a Problem

### 1. Violates Database Design Principles

Primary keys **must** be:
- ✅ **NOT NULL** (no exceptions)
- ✅ **UNIQUE** (enforced by SQLite)
- ✅ **IMMUTABLE** (should never change)

### 2. Potential Runtime Issues

```sql
-- ❌ This should fail but might not for TEXT columns
INSERT INTO users (id, public_key, username) 
VALUES (NULL, 'key123', 'john');

-- ❌ Could create orphaned foreign key references
INSERT INTO refresh_tokens (id, user_id, token_hash) 
VALUES (NULL, 'user123', 'hash');  -- NULL primary key!
```

### 3. Foreign Key Integrity Issues

```sql
-- If parent has NULL primary key, child foreign key references break
CREATE TABLE auth_challenges (
    id TEXT PRIMARY KEY,  -- Could be NULL!
    user_id TEXT REFERENCES users(id)  -- What if users.id is NULL?
);
```

### 4. Query Behavior Undefined

```sql
-- What happens here?
SELECT * FROM users WHERE id IS NULL;  -- Should never return rows
SELECT * FROM users WHERE id = 'abc' OR id IS NULL;  -- Dangerous
```

---

## SQLite Behavior Details

### INTEGER PRIMARY KEY (AUTOINCREMENT)

```sql
-- SQLite automatically enforces NOT NULL for INTEGER PRIMARY KEY
CREATE TABLE test1 (
    id INTEGER PRIMARY KEY AUTOINCREMENT
);

INSERT INTO test1 (id) VALUES (NULL);  -- ✅ WORKS (auto-generates ID)
-- Result: id = 1, 2, 3, ... (never actually NULL)
```

**Verdict**: ✅ Functionally safe (SQLite handles it)

---

### TEXT PRIMARY KEY

```sql
-- SQLite DOES allow NULL for TEXT PRIMARY KEY!
CREATE TABLE test2 (
    id TEXT PRIMARY KEY
);

INSERT INTO test2 (id) VALUES (NULL);  -- ⚠️ ACCEPTED!
INSERT INTO test2 (id) VALUES (NULL);  -- ⚠️ SECOND NULL FAILS (UNIQUE violation)

-- Result: One row with id = NULL exists!
```

**Verdict**: ❌ **Dangerous** - explicit NOT NULL required

---

## Impact Analysis

### High Risk Tables (No DEFAULT, Application-Generated)

```sql
-- ❌ HIGH RISK - Application must provide ID
CREATE TABLE refresh_tokens (
    id TEXT PRIMARY KEY,  -- No DEFAULT!
    ...
);

CREATE TABLE friend_post_fetch_settings (
    user_id TEXT PRIMARY KEY,  -- No DEFAULT!
    ...
);
```

**Risk**: If application code has a bug and provides NULL, it will be inserted.

---

### Medium Risk Tables (DEFAULT provided)

```sql
-- ⚠️ MEDIUM RISK - DEFAULT helps but not foolproof
CREATE TABLE users (
    id TEXT PRIMARY KEY DEFAULT (hex(randomblob(16))),
    ...
);
```

**Risk**: If application explicitly provides NULL, it overrides DEFAULT:
```rust
// ❌ This could bypass DEFAULT
diesel::insert_into(users::table)
    .values((
        users::id.eq(None),  // Explicit NULL!
        users::public_key.eq("key"),
        users::username.eq("john"),
    ))
```

---

### Low Risk Tables (AUTOINCREMENT)

```sql
-- ✅ LOW RISK - SQLite enforces NOT NULL automatically
CREATE TABLE events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ...
);
```

**Risk**: Minimal - SQLite won't allow NULL even if you try.

---

## Recommended Fixes

### Priority 1: High-Risk Tables (Immediate Fix Required)

```sql
-- Migration 001: Fix high-risk tables

-- 1. Ensure no existing NULL values
UPDATE refresh_tokens SET id = hex(randomblob(16)) WHERE id IS NULL;
UPDATE friend_post_fetch_settings SET user_id = 'unknown' WHERE user_id IS NULL;

-- 2. Add NOT NULL constraint (requires table rebuild in SQLite)
CREATE TABLE refresh_tokens_new (
    id TEXT PRIMARY KEY NOT NULL,  -- ✅ EXPLICIT NOT NULL
    user_id TEXT NOT NULL,
    token_hash TEXT NOT NULL UNIQUE,
    device_id TEXT NOT NULL,
    expires_at BIGINT NOT NULL,
    is_revoked BOOLEAN NOT NULL DEFAULT 0,
    created_at TEXT,
    last_used_at TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

INSERT INTO refresh_tokens_new SELECT * FROM refresh_tokens;
DROP TABLE refresh_tokens;
ALTER TABLE refresh_tokens_new RENAME TO refresh_tokens;

-- Repeat for friend_post_fetch_settings
```

---

### Priority 2: Medium-Risk Tables (Add NOT NULL)

```sql
-- Migration 002: Fix TEXT PRIMARY KEY tables

-- For each table, rebuild with NOT NULL
CREATE TABLE users_new (
    id TEXT PRIMARY KEY NOT NULL DEFAULT (hex(randomblob(16))),  -- ✅ EXPLICIT
    public_key TEXT UNIQUE NOT NULL,
    username TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now')),
    last_login TEXT,
    device_info TEXT,
    is_primary_owner BOOLEAN DEFAULT FALSE,
    first_name TEXT,
    last_name TEXT,
    user_role TEXT NOT NULL DEFAULT 'owner'
);

INSERT INTO users_new SELECT * FROM users WHERE id IS NOT NULL;
DROP TABLE users;
ALTER TABLE users_new RENAME TO users;

-- Repeat for:
-- - auth_challenges
-- - hardware_reset_events
-- - message_queue
-- - node_onboarding_state
-- - onboarding_challenges
```

---

### Priority 3: Low-Risk Tables (Best Practice Fix)

```sql
-- Migration 003: Add explicit NOT NULL for clarity

-- Even though SQLite enforces it, be explicit
CREATE TABLE events_new (
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,  -- ✅ EXPLICIT
    event_type TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    state TEXT NOT NULL,
    correlation_id TEXT,
    payload TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

INSERT INTO events_new SELECT * FROM events;
DROP TABLE events;
ALTER TABLE events_new RENAME TO events;

-- Repeat for:
-- - agent_execution_steps
-- - api_store_credit_transactions
-- - event_bus_jobs
-- - post_verifications
-- - saved_components
-- - system_metrics
```

---

## Prevention: Update Diesel Schema

After fixing database, update `schema.rs` to reflect NOT NULL:

```rust
// ❌ BEFORE (in schema.rs)
diesel::table! {
    users (id) {
        id -> Nullable<Text>,  // ❌ WRONG
    }
}

// ✅ AFTER
diesel::table! {
    users (id) {
        id -> Text,  // ✅ CORRECT (NOT NULL)
    }
}
```

Update these tables in `schema.rs`:
- `users.id`
- `auth_challenges.id`
- `hardware_reset_events.id`
- `message_queue.message_id`
- `node_onboarding_state.id`
- `onboarding_challenges.id`
- `refresh_tokens.id`
- `friend_post_fetch_settings.user_id`
- `events.id`
- `event_bus_jobs.id`
- `agent_execution_steps.id`
- `api_store_credit_transactions.id`
- `post_verifications.id`
- `saved_components.id`
- `system_metrics.id`

---

## Testing After Migration

```sql
-- Test 1: Verify NOT NULL constraint
INSERT INTO users (id, public_key, username) VALUES (NULL, 'test', 'test');
-- Expected: Error (NOT NULL constraint failed)

-- Test 2: Verify DEFAULT still works
INSERT INTO users (public_key, username) VALUES ('test2', 'test2');
SELECT id FROM users WHERE username = 'test2';
-- Expected: UUID generated

-- Test 3: Verify no NULL values exist
SELECT COUNT(*) FROM users WHERE id IS NULL;
-- Expected: 0

-- Test 4: Verify foreign keys still work
SELECT name, sql FROM sqlite_master 
WHERE type='table' AND sql LIKE '%FOREIGN KEY%';
-- Expected: All foreign keys intact
```

---

## Impact Summary

| Priority | Tables | Effort | Risk if Not Fixed |
|----------|--------|--------|-------------------|
| **HIGH** | 2 | 2 days | Data corruption, FK integrity loss |
| **MEDIUM** | 6 | 1 week | Potential runtime errors |
| **LOW** | 7 | 3 days | Schema clarity only |

**Total Effort**: ~2 weeks (includes testing)  
**Recommended Timeline**: Complete within 1 sprint

---

## Conclusion

While most tables are functionally protected (AUTOINCREMENT or DEFAULT), the lack of explicit NOT NULL constraints represents:

1. ❌ **Violation of database design principles**
2. ⚠️ **Potential data integrity risks** (especially for TEXT PRIMARY KEYs)
3. 📋 **Schema documentation issue** (misleading schema)
4. 🐛 **Possible runtime bugs** if application code changes

**Recommendation**: Fix **HIGH priority tables immediately**, then address others in next sprint.

---

**Document Version**: 1.0  
**Issue Discovered**: December 18, 2025  
**Severity**: HIGH (2 tables), MEDIUM (6 tables), LOW (7 tables)  
**Action Required**: Yes - Immediate migration needed

