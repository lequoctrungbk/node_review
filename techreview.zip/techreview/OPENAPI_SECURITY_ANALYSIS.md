# OpenAPI Security Analysis Report

> **Analysis Date:** 2025-01-18  
> **Scope:** All OpenAPI specification files  
> **Severity Levels:** Critical | High | Medium | Low | Info

---

## Executive Summary

| Severity | Count | Status |
|----------|-------|--------|
| **Critical** | 2 | 🔴 Requires immediate attention |
| **High** | 6 | 🟠 Should fix before production |
| **Medium** | 8 | 🟡 Plan to fix |
| **Low** | 5 | 🟢 Nice to have |
| **Info** | 4 | 🔵 Recommendations |

---

## Critical Issues

### SEC-001: Missing Authentication on Diagnostic Endpoints

**File:** `auto-friend-discovery-api.yaml`  
**Severity:** 🔴 Critical  
**OWASP:** A01:2021 - Broken Access Control

**Affected Endpoints:**
```yaml
GET /auto-discovery/status      # No security defined
GET /auto-discovery/metrics     # No security defined
GET /auto-discovery/events      # No security defined
GET /auto-discovery/retry-state # No security defined
```

**Issue:** These diagnostic endpoints expose sensitive system information without authentication:
- Internal system health status
- Performance metrics and statistics
- Node IDs and retry states
- Cache hit rates and configuration

**Risk:** An attacker can:
- Gather intelligence about system internals
- Identify target nodes for attacks
- Monitor system patterns for timing attacks
- Enumerate node IDs in the network

**Recommendation:**
```yaml
# Add security requirement to all endpoints
paths:
  /auto-discovery/status:
    get:
      security:
        - BearerAuth: []  # ADD THIS
      # ... rest of spec
```

**Code Fix Required:** Add JWT authentication middleware to all diagnostic routes.

---

### SEC-002: Sensitive Data Exposure in Error Responses

**Files:** Multiple  
**Severity:** 🔴 Critical  
**OWASP:** A01:2021 - Broken Access Control, A04:2021 - Insecure Design

**Issue:** Error responses may leak sensitive internal information:

```yaml
# From ip-pool-api.yaml
ErrorDetail:
  properties:
    details:
      type: object
      additionalProperties: true  # Allows ANY data
      example:
        ip_address: "Invalid IP address format"
        port: "Port must be between 1 and 65535"
```

**Risk:**
- Stack traces may be exposed
- Internal paths and configurations leaked
- Database error messages exposed
- Server version information revealed

**Recommendation:**
```yaml
ErrorDetail:
  properties:
    code:
      type: string
      enum: [VALIDATION_ERROR, ...]  # Whitelisted codes only
    message:
      type: string
      maxLength: 200  # Limit message length
    field:
      type: string
      description: Field name only, no values
    # Remove: additionalProperties: true
```

---

## High Severity Issues

### SEC-003: Missing Rate Limiting on Authentication-Sensitive Endpoints

**Files:** `auto-friend-discovery-api.yaml`, `terminal-api.yaml`  
**Severity:** 🟠 High  
**OWASP:** A04:2021 - Insecure Design

**Affected Endpoints:**
```yaml
POST /auto-discovery/control/enable
POST /auto-discovery/control/disable
POST /auto-discovery/control/retry/{node_id}
POST /terminal/sessions              # Session creation
DELETE /terminal/sessions/{id}       # Session termination
```

**Issue:** No rate limiting documented or enforced on sensitive control endpoints.

**Risk:**
- Brute force attacks on retry mechanism
- DoS through rapid session creation
- Resource exhaustion attacks

**Recommendation:**
```yaml
# Add rate limiting headers to responses
responses:
  '200':
    headers:
      X-RateLimit-Limit:
        schema:
          type: integer
        description: Max requests per window
      X-RateLimit-Remaining:
        schema:
          type: integer
      X-RateLimit-Reset:
        schema:
          type: integer
          format: int64
  '429':
    description: Rate limit exceeded
```

**Implementation:** Add rate limiting middleware (e.g., 10 requests/minute for control endpoints).

---

### SEC-004: Insufficient Input Validation on Node ID

**File:** `auto-friend-discovery-api.yaml`  
**Severity:** 🟠 High  
**OWASP:** A03:2021 - Injection

**Current Validation:**
```yaml
parameters:
  - name: node_id
    schema:
      type: string
      pattern: '^[0-9a-f]{66}$'  # Only hex pattern
      example: '02a1234...(66 hex chars)'
```

**Issues:**
1. No maximum length validation (could pass regex but cause buffer issues)
2. Pattern allows uppercase when example shows lowercase
3. No validation that it's a valid secp256k1 public key format

**Recommendation:**
```yaml
parameters:
  - name: node_id
    schema:
      type: string
      pattern: '^[0-9a-f]{66}$'
      minLength: 66
      maxLength: 66
      description: |
        33-byte compressed secp256k1 public key in hex format.
        Must start with 02 or 03.
    example: '02a1633cafcc01ebfb6d78e39f687a1f0995c62fc95f51ead10a02ee0be551b5dc'
```

**Additional Backend Validation:**
```rust
// Validate it's actually a valid public key
fn validate_node_id(node_id: &str) -> Result<(), ValidationError> {
    // 1. Length check
    if node_id.len() != 66 {
        return Err(ValidationError::InvalidLength);
    }
    // 2. Prefix check (02 or 03 for compressed keys)
    if !node_id.starts_with("02") && !node_id.starts_with("03") {
        return Err(ValidationError::InvalidPrefix);
    }
    // 3. Try to parse as actual public key
    PublicKey::from_str(node_id)?;
    Ok(())
}
```

---

### SEC-005: Command Injection Risk in Terminal API

**File:** `openapi.yaml` (Terminal)  
**Severity:** 🟠 High  
**OWASP:** A03:2021 - Injection

**Vulnerable Parameter:**
```yaml
CreateTerminalSessionRequest:
  properties:
    shell:
      type: string
      description: Shell to use (default /bin/bash)
      minLength: 1
      maxLength: 100
      example: "/bin/bash"
```

**Issue:** The shell parameter could be exploited:
```bash
# Potential attack payloads
shell: "/bin/bash; rm -rf /"
shell: "/bin/bash -c 'cat /etc/passwd'"
shell: "$(malicious_command)"
```

**Risk:** Remote code execution on the server.

**Recommendation:**
```yaml
shell:
  type: string
  enum:
    - "/bin/bash"
    - "/bin/sh"
    - "/bin/zsh"
  default: "/bin/bash"
  description: Shell must be from whitelist
```

**Backend Validation:**
```rust
const ALLOWED_SHELLS: &[&str] = &["/bin/bash", "/bin/sh", "/bin/zsh"];

fn validate_shell(shell: &str) -> Result<&str, SecurityError> {
    if ALLOWED_SHELLS.contains(&shell) {
        Ok(shell)
    } else {
        Err(SecurityError::InvalidShell)
    }
}
```

---

### SEC-006: Missing Authorization Checks Documentation

**Files:** Multiple  
**Severity:** 🟠 High  
**OWASP:** A01:2021 - Broken Access Control

**Issue:** APIs mention "user must own the notification" but don't document how authorization is enforced.

```yaml
# From notifications.openapi.yaml
/notifications/{id}/read:
  post:
    description: |
      **Authorization**: User must own the notification
      # But no scopes or roles defined in security scheme
    security:
      - BearerAuth: []  # No scopes specified
```

**Missing Elements:**
1. OAuth2 scopes for different operations
2. Role-based access control (RBAC) documentation
3. Resource ownership validation

**Recommendation:**
```yaml
components:
  securitySchemes:
    BearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT
      description: |
        JWT must contain:
        - `sub`: User ID
        - `node_id`: Node public key
        - `role`: One of [owner, admin, viewer]
        - `exp`: Expiration timestamp
        
        Authorization rules:
        - Notifications: Can only access own notifications (user_id == sub)
        - Terminal: Requires role == "owner"
        - Admin endpoints: Requires role == "admin"
```

---

### SEC-007: IP Address Validation Insufficient

**File:** `ip-pool-api.yaml`  
**Severity:** 🟠 High  
**OWASP:** A03:2021 - Injection, A04:2021 - Insecure Design

**Current Schema:**
```yaml
CreateIpRequest:
  properties:
    ip_address:
      type: string
      description: IPv4 or IPv6 address
      example: "203.0.113.42"
```

**Issues:**
1. No format validation (allows any string)
2. No pattern for IPv4/IPv6
3. Could allow internal/private IPs
4. No SSRF protection

**Risk:**
- SSRF attacks using internal IPs (127.0.0.1, 10.x.x.x, 192.168.x.x)
- DNS rebinding attacks
- Localhost bypass

**Recommendation:**
```yaml
ip_address:
  type: string
  oneOf:
    - format: ipv4
      pattern: '^(?!10\.)(?!192\.168\.)(?!172\.(1[6-9]|2[0-9]|3[01])\.)(?!127\.)(?!0\.)[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$'
    - format: ipv6
  description: |
    Public IPv4 or IPv6 address.
    Private ranges (10.x, 192.168.x, 172.16-31.x, 127.x) are NOT allowed.
```

**Backend Validation:**
```rust
fn validate_public_ip(ip: &str) -> Result<IpAddr, ValidationError> {
    let addr: IpAddr = ip.parse()?;
    
    match addr {
        IpAddr::V4(ipv4) => {
            if ipv4.is_private() || ipv4.is_loopback() || ipv4.is_link_local() {
                return Err(ValidationError::PrivateIpNotAllowed);
            }
        }
        IpAddr::V6(ipv6) => {
            if ipv6.is_loopback() {
                return Err(ValidationError::LoopbackNotAllowed);
            }
        }
    }
    Ok(addr)
}
```

---

### SEC-008: Insecure Direct Object Reference (IDOR)

**Files:** `notifications.openapi.yaml`, `terminal-api.yaml`, `ip-pool-api.yaml`  
**Severity:** 🟠 High  
**OWASP:** A01:2021 - Broken Access Control

**Pattern:**
```yaml
# All these endpoints use predictable UUIDs
/notifications/{id}
/terminal/sessions/{session_id}
/ip-pool/{id}
```

**Issue:** While UUIDs are used (good), there's no documented ownership validation.

**Risk:** User A could access User B's resources by guessing/enumerating UUIDs.

**Recommendation:**

1. **Document ownership checks explicitly:**
```yaml
/notifications/{id}:
  get:
    description: |
      Returns notification details.
      
      **Authorization:**
      - JWT `sub` claim must match notification's `user_id`
      - Returns 403 Forbidden if ownership check fails
```

2. **Backend implementation:**
```rust
async fn get_notification(
    claims: Claims,
    notification_id: Uuid,
    repo: &NotificationRepo,
) -> Result<Notification, AppError> {
    let notification = repo.find_by_id(notification_id).await?;
    
    // CRITICAL: Ownership check
    if notification.user_id != claims.sub {
        return Err(AppError::Forbidden("Not your notification"));
    }
    
    Ok(notification)
}
```

---

## Medium Severity Issues

### SEC-009: Missing HTTPS Enforcement

**Files:** All  
**Severity:** 🟡 Medium  
**OWASP:** A02:2021 - Cryptographic Failures

**Current:**
```yaml
servers:
  - url: http://localhost:3001/api/v2  # HTTP, not HTTPS
```

**Recommendation:**
```yaml
servers:
  - url: https://api.example.com/v2
    description: Production (HTTPS required)
  - url: http://localhost:3001/api/v2
    description: Development only
```

**Add security requirement:**
```yaml
# At top level
x-security-requirements:
  - All production traffic MUST use HTTPS/TLS 1.3
  - HSTS header required: Strict-Transport-Security: max-age=31536000
```

---

### SEC-010: JWT Token Not Validated for Expiration in Spec

**Files:** All with BearerAuth  
**Severity:** 🟡 Medium  
**OWASP:** A07:2021 - Identification and Authentication Failures

**Issue:** JWT security scheme doesn't document required claims validation.

**Recommendation:**
```yaml
components:
  securitySchemes:
    BearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT
      description: |
        JWT token requirements:
        
        **Required Claims:**
        - `iss`: Must be "node-backend"
        - `sub`: User/Node ID
        - `exp`: Expiration (max 24 hours from issue)
        - `iat`: Issued at timestamp
        - `jti`: Unique token ID (for revocation)
        
        **Validation Rules:**
        - Token must not be expired (exp > now)
        - Token must not be issued in future (iat <= now)
        - Token must be signed with RS256 or ES256
        - Token must not be in revocation list
```

---

### SEC-011: L402 Authentication Scheme Incomplete

**File:** `ip-pool-api.yaml`  
**Severity:** 🟡 Medium  
**OWASP:** A07:2021 - Identification and Authentication Failures

**Current:**
```yaml
l402:
  type: apiKey
  in: header
  name: Authorization
  description: L402 Lightning payment authentication (NodeId extractor)
```

**Issue:** L402 is not just an API key. It has a specific format and validation requirements.

**Recommendation:**
```yaml
l402:
  type: apiKey
  in: header
  name: Authorization
  description: |
    L402 (formerly LSAT) authentication header.
    
    **Format:** `L402 <macaroon>:<preimage>`
    
    **Validation:**
    1. Macaroon must be valid and not expired
    2. Preimage must match payment hash in macaroon
    3. Payment amount must meet endpoint minimum
    4. Macaroon caveats must be satisfied
    
    **Example:**
    ```
    Authorization: L402 AGIAJEemVQUTEyNCR0exk7ek90...:preimage_hex
    ```
```

---

### SEC-012: Missing Content-Type Validation

**Files:** All with POST/PUT  
**Severity:** 🟡 Medium  
**OWASP:** A03:2021 - Injection

**Issue:** APIs accept `application/json` but don't explicitly reject other content types.

**Risk:** Content-type confusion attacks, XXE if XML accidentally processed.

**Recommendation:**
```yaml
requestBody:
  required: true
  content:
    application/json:
      schema:
        $ref: '#/components/schemas/CreateIpRequest'
  # Add explicit note
  x-content-type-validation: |
    Server MUST return 415 Unsupported Media Type for:
    - Missing Content-Type header
    - Content-Type other than application/json
    - Content-Type with unexpected parameters
```

---

### SEC-013: Pagination Parameters Without Upper Bounds

**File:** `notifications.openapi.yaml`  
**Severity:** 🟡 Medium  
**OWASP:** A04:2021 - Insecure Design

**Current:**
```yaml
- name: page
  schema:
    type: integer
    minimum: 1
    maximum: 10000  # Very high
```

**Risk:** Resource exhaustion by requesting page 10000 with per_page=100.

**Recommendation:**
```yaml
- name: page
  schema:
    type: integer
    minimum: 1
    maximum: 1000  # Lower limit
    
# Add cursor-based pagination for large datasets
- name: cursor
  schema:
    type: string
  description: Opaque cursor for efficient pagination
```

---

### SEC-014: Sensitive Data in URL Query Parameters

**File:** `auto-friend-discovery-api.yaml`  
**Severity:** 🟡 Medium  
**OWASP:** A04:2021 - Insecure Design

**Issue:**
```yaml
- name: node_id
  in: query  # Sensitive data in URL
  schema:
    type: string
    pattern: '^[0-9a-f]{66}$'
```

**Risk:**
- Node IDs logged in access logs
- Node IDs cached in browser history
- Node IDs leaked via Referrer header

**Recommendation:**
- Use POST with request body for sensitive filters
- Or accept this as path parameter only when needed

```yaml
# Option 1: POST endpoint for sensitive queries
POST /auto-discovery/events/search
requestBody:
  content:
    application/json:
      schema:
        properties:
          node_id:
            type: string
            pattern: '^[0-9a-f]{66}$'
```

---

### SEC-015: Missing Request Size Limits

**Files:** All with POST/PUT  
**Severity:** 🟡 Medium  
**OWASP:** A04:2021 - Insecure Design

**Issue:** No documented limits on request body size.

**Risk:** DoS through large payload attacks.

**Recommendation:**
```yaml
# At API level
x-request-limits:
  max-body-size: "1MB"
  max-header-size: "8KB"
  max-uri-length: "2048"

# Per-endpoint for specific needs
/ip-pool:
  post:
    x-max-request-size: "10KB"
```

---

### SEC-016: WebSocket Security Not Documented

**File:** `notifications.openapi.yaml`  
**Severity:** 🟡 Medium  
**OWASP:** A04:2021 - Insecure Design

**Current:**
```yaml
x-websocket-events:
  notification:created:
    description: |
      WebSocket connection must be authenticated before receiving events.
```

**Issue:** WebSocket authentication mechanism not specified.

**Recommendation:**
```yaml
x-websocket-security:
  authentication:
    method: "token-in-first-message"
    description: |
      1. Client connects to wss://api.example.com/ws
      2. Client sends auth message: {"type": "auth", "token": "<JWT>"}
      3. Server validates JWT and associates connection with user
      4. Server sends: {"type": "auth_success"} or closes connection
      
  rate-limiting:
    max-connections-per-user: 5
    max-messages-per-second: 10
    
  timeout:
    auth-timeout-seconds: 10
    idle-timeout-seconds: 300
```

---

## Low Severity Issues

### SEC-017: Version Information in API

**Files:** All  
**Severity:** 🟢 Low

**Issue:** API versions exposed in specs could help attackers identify known vulnerabilities.

```yaml
info:
  version: 1.0.0  # Exposed
```

**Recommendation:** Consider using generic version identifiers in production.

---

### SEC-018: Verbose Error Examples

**Files:** Multiple  
**Severity:** 🟢 Low

**Issue:** Error examples in specs could guide attackers.

```yaml
example:
  success: false
  message: "Invalid IP address format. Supported: IPv4 (e.g., 192.168.1.1) or IPv6"
```

**Recommendation:** Use generic error messages in examples.

---

### SEC-019: Missing Security Contact

**Files:** All  
**Severity:** 🟢 Low

**Recommendation:**
```yaml
info:
  contact:
    name: Security Team
    email: security@example.com
    url: https://example.com/.well-known/security.txt
```

---

### SEC-020: No API Deprecation Policy

**Severity:** 🟢 Low

**Recommendation:**
```yaml
info:
  x-deprecation-policy: |
    - Deprecated endpoints marked with `deprecated: true`
    - Minimum 6-month notice before removal
    - Sunset header included: `Sunset: Sat, 01 Jul 2025 00:00:00 GMT`
```

---

### SEC-021: Missing CORS Documentation

**Files:** All  
**Severity:** 🟢 Low

**Recommendation:**
```yaml
x-cors-policy:
  allowed-origins:
    - "https://app.example.com"
  allowed-methods:
    - GET
    - POST
    - PUT
    - DELETE
  allowed-headers:
    - Authorization
    - Content-Type
  max-age: 86400
  credentials: true
```

---

## Informational

### SEC-022: Consider Adding Request IDs

**Recommendation:**
```yaml
# All responses should include
headers:
  X-Request-ID:
    schema:
      type: string
      format: uuid
    description: Unique request identifier for tracing
```

---

### SEC-023: Consider API Key Rotation Documentation

**Recommendation:** Document how L402 tokens and JWTs should be rotated/refreshed.

---

### SEC-024: Consider Adding Audit Logging Notes

**Recommendation:**
```yaml
x-audit-logging:
  logged-events:
    - authentication-success
    - authentication-failure
    - authorization-failure
    - resource-created
    - resource-deleted
    - admin-action
  retention: "90 days"
```

---

### SEC-025: Consider Security Headers Documentation

**Recommendation:**
```yaml
x-security-headers:
  required:
    - "Content-Security-Policy: default-src 'self'"
    - "X-Content-Type-Options: nosniff"
    - "X-Frame-Options: DENY"
    - "X-XSS-Protection: 1; mode=block"
    - "Referrer-Policy: strict-origin-when-cross-origin"
```

---

## Summary Action Items

### Immediate (Before Production)

| ID | Issue | Owner | ETA |
|----|-------|-------|-----|
| SEC-001 | Add auth to diagnostic endpoints | Backend | Week 1 |
| SEC-002 | Sanitize error responses | Backend | Week 1 |
| SEC-005 | Whitelist terminal shells | Backend | Week 1 |
| SEC-007 | Validate public IPs | Backend | Week 1 |

### Short-term (Within 30 days)

| ID | Issue | Owner | ETA |
|----|-------|-------|-----|
| SEC-003 | Add rate limiting | Backend | Week 2 |
| SEC-004 | Improve node_id validation | Backend | Week 2 |
| SEC-006 | Document authorization rules | Docs | Week 2 |
| SEC-008 | Implement IDOR protection | Backend | Week 3 |

### Medium-term (Within 90 days)

| ID | Issue | Owner | ETA |
|----|-------|-------|-----|
| SEC-009 | Enforce HTTPS | DevOps | Month 2 |
| SEC-010 | Document JWT validation | Docs | Month 2 |
| SEC-011 | Complete L402 docs | Docs | Month 2 |
| SEC-012-16 | Various hardening | Backend | Month 3 |

---

## References

- [OWASP API Security Top 10 2023](https://owasp.org/API-Security/)
- [OWASP Cheat Sheet Series](https://cheatsheetseries.owasp.org/)
- [RFC 6749 - OAuth 2.0](https://tools.ietf.org/html/rfc6749)
- [RFC 7519 - JWT](https://tools.ietf.org/html/rfc7519)
- [L402 Protocol Specification](https://lsat.tech/)

