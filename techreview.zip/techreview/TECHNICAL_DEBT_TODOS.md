# Technical Debt: TODO/FIXME/HACK Analysis

> **Analysis Date:** 2025-01-18  
> **Scope:** Backend (Rust) and Frontend (React/TypeScript)  
> **Markers Searched:** `TODO`, `FIXME`, `HACK`, `XXX`, `OPTIMIZE`, `REFACTOR`

---

## Executive Summary

| Location | Files Affected | Total Markers |
|----------|----------------|---------------|
| **Backend (Rust)** | 38 files | 67 |
| **Frontend (React)** | 3 files | 5 |
| **Total** | **41 files** | **72** |

---

## Backend Technical Debt (Rust)

### Category 1: Incomplete Features - Blocked by Migrations

These features are implemented but commented out, waiting for database migrations.

| File | Count | Description |
|------|-------|-------------|
| `transport/node_server/http_terminal.rs` | 3 | Terminal replay routes disabled |
| `terminal/handlers.rs` | 3 | Terminal replay handlers disabled |
| `state.rs` | 1 | Replay service not initialized |
| `services/terminal/mod.rs` | 2 | Replay service module commented |
| `repositories/terminal/mod.rs` | 2 | Replay repository module commented |
| `models/terminal.rs` | 2 | Terminal replay models commented |

**Details:**
```rust
// transport/node_server/http_terminal.rs:38
// TODO: Uncomment when replay migrations are created

// terminal/handlers.rs:699
// TODO: Uncomment when terminal_replay_events and terminal_replay_metadata migrations are created

// state.rs:122
// TODO: Uncomment when terminal_replay_events and terminal_replay_metadata migrations are created

// services/terminal/mod.rs:10
// TODO: Uncomment when terminal_replay_events and terminal_replay_metadata migrations are created
// pub mod replay_service;

// repositories/terminal/mod.rs:11
// TODO: Uncomment when terminal_replay_events and terminal_replay_metadata migrations are created
// pub mod replay_repository;

// models/terminal.rs:818
// TODO: Uncomment when migration is created
```

---

### Category 2: Stub Implementations (⚠️ CRITICAL)

These functions exist but have **no actual implementation** - they return empty results or do nothing.

| File | Count | Severity |
|------|-------|----------|
| `repositories/metrics.rs` | 3 | 🔴 Critical |
| `message_queue/optimizations.rs` | 1 | 🟠 High |
| `pi_uart_service/service_layer.rs` | 1 | 🟠 High |

**Details:**

```rust
// repositories/metrics.rs:228
// TODO: Implement actual Diesel batch insertion
// For now, stub to avoid compilation errors
pub fn save_metrics_batch(&self, metrics: Vec<Metric>) -> Result<()> {
    Ok(()) // ⚠️ DOES NOTHING - DATA IS LOST!
}

// repositories/metrics.rs:264
// TODO: Implement actual query logic with Diesel
// For now, return empty to avoid compilation errors
pub fn get_aggregated_metrics(...) -> Result<Vec<AggregatedMetric>> {
    Ok(vec![]) // ⚠️ ALWAYS RETURNS EMPTY!
}

// repositories/metrics.rs:298
// TODO: Implement cleanup with retention policy
pub fn cleanup_old_metrics(&self) -> Result<u64> {
    // ⚠️ NOT IMPLEMENTED - OLD DATA NEVER CLEANED!
}

// message_queue/optimizations.rs:346
// For now, simulate compression by returning the same content
// TODO: Implement actual compression
Ok(content.to_vec())

// pi_uart_service/service_layer.rs:386
// TODO: Query ESP32 via UART for actual health status
// For now, return an error response indicating not implemented
```

---

### Category 3: Missing Business Logic

| File | Count | Description |
|------|-------|-------------|
| `social_network/service.rs` | 2 | Feed aggregation, friendly name |
| `social_network/repository.rs` | 2 | Post counters, join queries |
| `posts/service.rs` | 1 | Content updates with AI |
| `posts/models.rs` | 1 | User-based friends system |
| `posts/handlers.rs` | 1 | Load blocked_node_ids |
| `posts/ldk_signing_service.rs` | 1 | Signature retrieval |
| `services/conversation/conversation_service.rs` | 1 | NodeClient notification |
| `rathole/proxy_service.rs` | 1 | L402 endpoint cleanup |

**Details:**

```rust
// social_network/service.rs:1167
author_friendly_name: None, // TODO: Get from buddies

// social_network/service.rs:1201
// TODO: Implement full feed aggregation with post data

// social_network/repository.rs:814
// TODO: Update ai_posts table engagement_score instead

// social_network/repository.rs:886
// TODO: Join with posts and enhance with post data

// posts/service.rs:264
// TODO: Implement actual content updates with re-triggering AI analysis

// posts/models.rs:389
// TODO: Update for user-based friends system

// posts/handlers.rs:211
blocked_node_ids: vec![], // TODO: Load from user settings

// posts/ldk_signing_service.rs:463
// TODO: Add additional signature retrieval mechanisms

// services/conversation/conversation_service.rs:270
// TODO: Notify participant via NodeClient about conversation creation

// rathole/proxy_service.rs:852
// TODO: Implement endpoint fee deactivation when available in L402Repository
```

---

### Category 4: Disabled Tests

All tests in message_queue directory are disabled due to test_utils needing updates.

| File | Count | Reason |
|------|-------|--------|
| `message_queue/worker_manager.rs` | 1 | test_utils needs updates |
| `message_queue/strategies/websocket.rs` | 1 | test_utils needs updates |
| `message_queue/strategies/gossip.rs` | 1 | test_utils needs updates |
| `message_queue/service.rs` | 1 | test_utils needs updates |
| `message_queue/repository.rs` | 1 | test_utils needs updates |
| `message_queue/optimizations.rs` | 1 | test_utils needs updates |
| `message_queue/integration.rs` | 1 | test_utils needs updates |
| `message_queue/handlers.rs` | 1 | test_utils needs updates |
| `message_queue/enhanced_service.rs` | 1 | test_utils needs updates |

**Common Pattern:**
```rust
// TODO: Re-enable tests when test_utils is updated
// Tests temporarily disabled - test_utils needs updates for new AppState fields
```

---

### Category 5: Unimplemented Tests

| File | Count | Description |
|------|-------|-------------|
| `pi_uart_service/uart_manager_tests.rs` | 8 | Mock tests not implemented |

**Details:**
```rust
// pi_uart_service/uart_manager_tests.rs:218
async fn test_send_command_success() {
    // TODO: Implement with mocked serial port
}

// pi_uart_service/uart_manager_tests.rs:226
async fn test_request_timeout_handling() {
    // TODO: Implement with mocked serial port that doesn't respond
}

// pi_uart_service/uart_manager_tests.rs:234
async fn test_write_error_handling() {
    // TODO: Implement with mocked serial port that fails on write
}

// pi_uart_service/uart_manager_tests.rs:242
async fn test_background_listener_frame_processing() {
    // TODO: Implement with mocked serial port that sends frames
}

// pi_uart_service/uart_manager_tests.rs:250
async fn test_buffer_overflow_protection() {
    // TODO: Implement with mocked serial port that sends excessive data
}

// pi_uart_service/uart_manager_tests.rs:258
async fn test_unknown_correlation_id_handling() {
    // TODO: Implement with mocked serial port
}

// pi_uart_service/uart_manager_tests.rs:266
async fn test_concurrent_command_handling() {
    // TODO: Implement with mocked serial port
}
```

---

### Category 6: Architecture Decisions Pending

| File | Count | Description |
|------|-------|-------------|
| `message_queue/strategies/mod.rs` | 2 | L402 handling for WebSocket/Gossip |
| `message_queue/worker_improved.rs` | 1 | L402 details extraction |

**Details:**
```rust
// message_queue/strategies/mod.rs:49
// TODO: think about a proper ways to handle websocket delivery that supports l402 invoice payments
// Box::new(WebSocketDeliveryStrategy::new(app_state.clone())),

// message_queue/strategies/mod.rs:52
// TODO: think about a proper ways to handle gossip delivery that supports l402 invoice payments
// Box::new(GossipDeliveryStrategy::new(app_state)),

// message_queue/worker_improved.rs:443
// TODO: Extract L402 details if HTTP strategy is used
// This would require modifying the DeliveryResult enum to include L402 details
```

---

### Category 7: Other Backend TODOs

| File | Count |
|------|-------|
| `main.rs` | 2 |
| `lib.rs` | 1 |
| `api_store/service.rs` | 4 |
| `api_store/credits_service.rs` | 1 |
| `api_store/credits.rs` | 1 |
| `ai_agents/executor.rs` | 2 |
| `conversational_ui/llm_client.rs` | 1 |
| `conversational_ui/handlers.rs` | 2 |
| `endpoints/terminal_endpoint.rs` | 3 |
| `endpoints/pi_uart_endpoint_tests.rs` | 2 |

---

## Frontend Technical Debt (React/TypeScript)

| File | Count | Description |
|------|-------|-------------|
| `pages/ConversationalUI.tsx` | 2 | Edit modal, refresh functionality |
| `hooks/useNodeStatus.ts` | 2 | Network health, service status |
| `components/social/index.ts` | 1 | Export other components |

**Details:**

```typescript
// pages/ConversationalUI.tsx:196
const handleEditComponent = (component: SavedComponent) => {
  // TODO: Implement edit modal/form
  console.log('Edit component:', component);
};

// pages/ConversationalUI.tsx:267
onRefresh={() => {
  // TODO: Implement refresh functionality for saved components
  console.log('Refresh component data');
}}

// hooks/useNodeStatus.ts:137
networkHealthy: true, // TODO: Add network health check logic

// hooks/useNodeStatus.ts:148
// TODO: Add service status when backend endpoints are available
services: undefined,

// components/social/index.ts:12
// TODO: Export other components when they're created
```

---

## Complete File List

### Backend Files (38 total)

```
packages/backend/src/
├── ai_agents/
│   └── executor.rs
├── api_store/
│   ├── credits.rs
│   ├── credits_service.rs
│   └── service.rs
├── conversational_ui/
│   ├── handlers.rs
│   └── llm_client.rs
├── endpoints/
│   ├── pi_uart_endpoint_tests.rs
│   └── terminal_endpoint.rs
├── message_queue/
│   ├── enhanced_service.rs
│   ├── handlers.rs
│   ├── integration.rs
│   ├── optimizations.rs
│   ├── repository.rs
│   ├── service.rs
│   ├── strategies/
│   │   ├── gossip.rs
│   │   ├── mod.rs
│   │   └── websocket.rs
│   ├── worker_improved.rs
│   └── worker_manager.rs
├── models/
│   └── terminal.rs
├── pi_uart_service/
│   ├── service_layer.rs
│   └── uart_manager_tests.rs
├── posts/
│   ├── handlers.rs
│   ├── ldk_signing_service.rs
│   ├── models.rs
│   └── service.rs
├── rathole/
│   └── proxy_service.rs
├── repositories/
│   ├── metrics.rs
│   └── terminal/
│       └── mod.rs
├── services/
│   ├── conversation/
│   │   └── conversation_service.rs
│   └── terminal/
│       └── mod.rs
├── social_network/
│   ├── repository.rs
│   └── service.rs
├── terminal/
│   └── handlers.rs
├── transport/
│   └── node_server/
│       └── http_terminal.rs
├── lib.rs
├── main.rs
└── state.rs
```

### Frontend Files (3 total)

```
packages/node-ui/src/
├── components/
│   └── social/
│       └── index.ts
├── hooks/
│   └── useNodeStatus.ts
└── pages/
    └── ConversationalUI.tsx
```

---

## Priority Matrix

### 🔴 P0 - Critical (Fix Immediately)

| File | Issue | Impact |
|------|-------|--------|
| `repositories/metrics.rs` | Stub implementations | **Data loss, features broken** |
| `message_queue/*` (9 files) | Tests disabled | **No test coverage** |

### 🟠 P1 - High (Fix This Sprint)

| File | Issue | Impact |
|------|-------|--------|
| Terminal replay (6 files) | Blocked by migrations | Feature incomplete |
| `pi_uart_service/uart_manager_tests.rs` | 8 tests not implemented | No UART test coverage |
| `message_queue/optimizations.rs` | Compression not implemented | Performance |

### 🟡 P2 - Medium (Fix This Month)

| File | Issue | Impact |
|------|-------|--------|
| `social_network/*` (2 files) | Business logic missing | Features incomplete |
| `posts/*` (4 files) | Business logic missing | Features incomplete |
| Frontend (3 files) | UI features missing | UX incomplete |

### 🟢 P3 - Low (Backlog)

| File | Issue | Impact |
|------|-------|--------|
| Other backend files (12 files) | Various TODOs | Minor improvements |

---

## Action Items

### Immediate Actions

1. **Create migration for terminal replay**
   - Tables: `terminal_replay_events`, `terminal_replay_metadata`
   - Unblock 6 files, 13 TODOs

2. **Implement `repositories/metrics.rs`**
   - `save_metrics_batch()` - Diesel batch insert
   - `get_aggregated_metrics()` - Diesel query
   - `cleanup_old_metrics()` - Retention policy

3. **Update `test_utils` for new AppState**
   - Unblock 9 test files in `message_queue/`

### Short-term Actions

4. **Implement UART mock tests** (8 tests)
5. **Implement social network business logic** (4 TODOs)
6. **Implement frontend features** (5 TODOs)

### Long-term Actions

7. **Design L402 handling for WebSocket/Gossip delivery**
8. **Address remaining backend TODOs**

---

## Detailed Line-by-Line Reference

### Backend Files with Line Numbers

#### `transport/node_server/http_terminal.rs`
| Line | Marker | Content |
|------|--------|---------|
| 38 | TODO | `// TODO: Uncomment when replay migrations are created` |
| 105 | TODO | `// TODO: Uncomment when terminal_replay_events and terminal_replay_metadata migrations are created` |
| 937 | TODO | `// TODO: Uncomment when terminal_replay_events and terminal_replay_metadata migrations are created` |

#### `terminal/handlers.rs`
| Line | Marker | Content |
|------|--------|---------|
| 33 | TODO | `// TODO: Uncomment when replay migrations are created` |
| 699 | TODO | `// TODO: Uncomment when terminal_replay_events and terminal_replay_metadata migrations are created` |
| 799 | TODO | `// TODO: Uncomment when terminal_replay_events and terminal_replay_metadata migrations are created` |

#### `state.rs`
| Line | Marker | Content |
|------|--------|---------|
| 122 | TODO | `// TODO: Uncomment when terminal_replay_events and terminal_replay_metadata migrations are created` |

#### `social_network/service.rs`
| Line | Marker | Content |
|------|--------|---------|
| 1167 | TODO | `author_friendly_name: None, // TODO: Get from buddies` |
| 1201 | TODO | `// TODO: Implement full feed aggregation with post data` |

#### `social_network/repository.rs`
| Line | Marker | Content |
|------|--------|---------|
| 814 | TODO | `// TODO: Update ai_posts table engagement_score instead` |
| 886 | TODO | `// TODO: Join with posts and enhance with post data` |

#### `services/terminal/mod.rs`
| Line | Marker | Content |
|------|--------|---------|
| 10 | TODO | `// TODO: Uncomment when terminal_replay_events and terminal_replay_metadata migrations are created` |
| 18 | TODO | `// TODO: Uncomment when terminal_replay_events and terminal_replay_metadata migrations are created` |

#### `services/conversation/conversation_service.rs`
| Line | Marker | Content |
|------|--------|---------|
| 270 | TODO | `// TODO: Notify participant via NodeClient about conversation creation` |

#### `repositories/terminal/mod.rs`
| Line | Marker | Content |
|------|--------|---------|
| 11 | TODO | `// TODO: Uncomment when terminal_replay_events and terminal_replay_metadata migrations are created` |
| 20 | TODO | `// TODO: Uncomment when terminal_replay_events and terminal_replay_metadata migrations are created` |

#### `repositories/metrics.rs` ⚠️ CRITICAL
| Line | Marker | Content |
|------|--------|---------|
| 228 | TODO | `// TODO: Implement actual Diesel batch insertion` |
| 264 | TODO | `// TODO: Implement actual query logic with Diesel` |
| 298 | TODO | `// TODO: Implement cleanup with retention policy` |

#### `rathole/proxy_service.rs`
| Line | Marker | Content |
|------|--------|---------|
| 852 | TODO | `// TODO: Implement endpoint fee deactivation when available in L402Repository` |

#### `posts/service.rs`
| Line | Marker | Content |
|------|--------|---------|
| 264 | TODO | `// TODO: Implement actual content updates with re-triggering AI analysis` |

#### `posts/models.rs`
| Line | Marker | Content |
|------|--------|---------|
| 389 | TODO | `// TODO: Update for user-based friends system` |

#### `posts/ldk_signing_service.rs`
| Line | Marker | Content |
|------|--------|---------|
| 463 | TODO | `// TODO: Add additional signature retrieval mechanisms:` |

#### `posts/handlers.rs`
| Line | Marker | Content |
|------|--------|---------|
| 211 | TODO | `blocked_node_ids: vec![], // TODO: Load from user settings` |

#### `pi_uart_service/uart_manager_tests.rs`
| Line | Marker | Content |
|------|--------|---------|
| 218 | TODO | `// TODO: Implement with mocked serial port` |
| 226 | TODO | `// TODO: Implement with mocked serial port that doesn't respond` |
| 234 | TODO | `// TODO: Implement with mocked serial port that fails on write` |
| 242 | TODO | `// TODO: Implement with mocked serial port that sends frames` |
| 250 | TODO | `// TODO: Implement with mocked serial port that sends excessive data` |
| 258 | TODO | `// TODO: Implement with mocked serial port` |
| 266 | TODO | `// TODO: Implement with mocked serial port` |

#### `pi_uart_service/service_layer.rs`
| Line | Marker | Content |
|------|--------|---------|
| 386 | TODO | `// TODO: Query ESP32 via UART for actual health status` |

#### `models/terminal.rs`
| Line | Marker | Content |
|------|--------|---------|
| 818 | TODO | `// TODO: Uncomment when migration is created` |
| 859 | TODO | `// TODO: Uncomment when migration is created` |

#### `message_queue/worker_manager.rs`
| Line | Marker | Content |
|------|--------|---------|
| 348 | TODO | `// TODO: Re-enable tests when test_utils is updated` |

#### `message_queue/worker_improved.rs`
| Line | Marker | Content |
|------|--------|---------|
| 443 | TODO | `// TODO: Extract L402 details if HTTP strategy is used` |

#### `message_queue/strategies/websocket.rs`
| Line | Marker | Content |
|------|--------|---------|
| 229 | TODO | `// TODO: Re-enable tests when test_utils is updated` |

#### `message_queue/strategies/mod.rs`
| Line | Marker | Content |
|------|--------|---------|
| 49 | TODO | `// TODO: think about a proper ways to handle websocket delivery that supports l402 invoice payments` |
| 52 | TODO | `// TODO: think about a proper ways to handle gossip delivery that supports l402 invoice payments` |

#### `message_queue/strategies/gossip.rs`
| Line | Marker | Content |
|------|--------|---------|
| 165 | TODO | `// TODO: Re-enable tests when test_utils is updated` |

#### `message_queue/service.rs`
| Line | Marker | Content |
|------|--------|---------|
| 241 | TODO | `// TODO: Re-enable tests when test_utils is updated` |

#### `message_queue/repository.rs`
| Line | Marker | Content |
|------|--------|---------|
| 260 | TODO | `// TODO: Re-enable tests when test_utils is updated` |

#### `message_queue/optimizations.rs`
| Line | Marker | Content |
|------|--------|---------|
| 346 | TODO | `// TODO: Implement actual compression` |
| 545 | TODO | `// TODO: Re-enable tests when test_utils is updated` |

#### `message_queue/integration.rs`
| Line | Marker | Content |
|------|--------|---------|
| 198 | TODO | `// TODO: Re-enable tests when test_utils is updated` |

#### `message_queue/handlers.rs`
| Line | Marker | Content |
|------|--------|---------|
| 298 | TODO | `// TODO: Re-enable tests when test_utils is updated` |

#### `message_queue/enhanced_service.rs`
| Line | Marker | Content |
|------|--------|---------|
| 554 | TODO | `// TODO: Re-enable tests when test_utils is updated` |

#### `main.rs`
| Line | Marker | Content |
|------|--------|---------|
| 889 | TODO | `// TODO: Uncomment when terminal_replay_events and terminal_replay_metadata migrations are created` |
| 1150 | TODO | `// TODO: Uncomment when terminal_replay_events and terminal_replay_metadata migrations are created` |

#### `lib.rs`
| Line | Marker | Content |
|------|--------|---------|
| 68 | TODO | `// TODO: Update test_utils to match current AppState and service signatures` |

#### `endpoints/terminal_endpoint.rs`
| Line | Marker | Content |
|------|--------|---------|
| 25 | TODO | `// TODO: Uncomment when replay migrations are created` |
| 314 | TODO | `// TODO: Uncomment when terminal_replay_events and terminal_replay_metadata migrations are created` |
| 905 | TODO | `// TODO: Uncomment when terminal_replay_events and terminal_replay_metadata migrations are created` |

#### `endpoints/pi_uart_endpoint_tests.rs`
| Line | Marker | Content |
|------|--------|---------|
| 204 | TODO | `// TODO: Implement integration tests for:` |
| 213 | TODO | `// TODO: Implement tests for:` |

#### `conversational_ui/llm_client.rs`
| Line | Marker | Content |
|------|--------|---------|
| 24 | TODO | `// TODO: Implement OpenAI provider` |

#### `conversational_ui/handlers.rs`
| Line | Marker | Content |
|------|--------|---------|
| 66 | TODO | `// TODO: Implement refresh logic` |
| 82 | TODO | `// TODO: Implement conversation retrieval from database` |

#### `api_store/service.rs`
| Line | Marker | Content |
|------|--------|---------|
| 353 | XXX | `// Pattern: "API key: XXX" or "api key XXX"` |
| 355 | XXX | `// Pattern: "token: XXX" or "token XXX"` |
| 357 | XXX | `// Pattern: "with XXX"` |
| 359 | XXX | `// Pattern: "using XXX"` |

#### `api_store/credits_service.rs`
| Line | Marker | Content |
|------|--------|---------|
| 342 | TODO | `None, // TODO: Extract invoice ID from payment` |

#### `api_store/credits.rs`
| Line | Marker | Content |
|------|--------|---------|
| 577 | TODO | `/// TODO: Update this to a realistic value or use ExchangeRateService` |

#### `ai_agents/executor.rs`
| Line | Marker | Content |
|------|--------|---------|
| 460 | TODO | `total_tokens: None, // TODO: Add total_tokens to ExecutionResult if needed` |
| 461 | TODO | `total_cost_sats: None, // TODO: Add total_cost_sats to ExecutionResult if needed` |

#### `ai_agents/resource_monitoring_summary.md`
| Line | Marker | Content |
|------|--------|---------|
| 161 | REFACTOR | `✅ **RED-GREEN-REFACTOR** - All features developed with failing tests first` |

---

### Frontend Files with Line Numbers

#### `pages/ConversationalUI.tsx`
| Line | Marker | Content |
|------|--------|---------|
| 196 | TODO | `// TODO: Implement edit modal/form` |
| 267 | TODO | `// TODO: Implement refresh functionality for saved components` |

#### `hooks/useNodeStatus.ts`
| Line | Marker | Content |
|------|--------|---------|
| 137 | TODO | `networkHealthy: true, // TODO: Add network health check logic` |
| 148 | TODO | `// TODO: Add service status when backend endpoints are available` |

#### `components/social/index.ts`
| Line | Marker | Content |
|------|--------|---------|
| 12 | TODO | `// TODO: Export other components when they're created` |

---

## Statistics by Marker Type

| Marker | Backend | Frontend | Total |
|--------|---------|----------|-------|
| **TODO** | 63 | 5 | 68 |
| **XXX** | 4 | 0 | 4 |
| **REFACTOR** | 1 | 0 | 1 |
| **FIXME** | 0 | 0 | 0 |
| **HACK** | 0 | 0 | 0 |
| **OPTIMIZE** | 0 | 0 | 0 |
| **Total** | **68** | **5** | **73** |

---

## References

- [Technical Debt Analysis](./technical-debt-analysis.md) - Full analysis
- [Security Analysis](./openapi-security-analysis.md) - Security issues
- [API Standards Review](./openapi-specs-review.md) - API compliance
- [Directory Structure Analysis](./directory-structure-analysis.md) - Project structure issues

