# OpenAPI Specs Review Report

> **Review Date:** 2025-01-18  
> **Standard Reference:** [api-path-naming-standards.md](./api-path-naming-standards.md)  
> **Reviewer:** Technical Review

---

## Executive Summary

| Metric | Value |
|--------|-------|
| **Total Files Reviewed** | 9 |
| **Total Paths Reviewed** | 35 |
| **Compliance Rate** | ~65% |
| **Critical Issues** | 12 |
| **Warnings** | 8 |
| **Passing** | 15 |

### Overall Assessment

| Criteria | Status | Notes |
|----------|--------|-------|
| **Kebab-case** | ✅ PASS | All path segments use kebab-case correctly |
| **Nouns** | ⚠️ PARTIAL | Actions use verbs instead of colon style |
| **Plural** | ❌ FAIL | Several collections use singular nouns |
| **Hierarchy** | ✅ PASS | Parent-child relationships are clear |
| **Consistent** | ⚠️ PARTIAL | Mixed action patterns across APIs |

---

## Detailed Review by File

### 1. Auto Friend Discovery API

**File:** `specs/003-auto-friend-discovery/contracts/auto-friend-discovery-api.yaml`

| Path | Kebab | Nouns | Plural | Hierarchy | Status |
|------|-------|-------|--------|-----------|--------|
| `/auto-discovery/status` | ✅ | ✅ | N/A | ✅ | ✅ PASS |
| `/auto-discovery/metrics` | ✅ | ✅ | N/A | ✅ | ✅ PASS |
| `/auto-discovery/events` | ✅ | ✅ | ✅ | ✅ | ✅ PASS |
| `/auto-discovery/retry-state` | ✅ | ✅ | ❌ | ✅ | ⚠️ WARN |
| `/auto-discovery/control/enable` | ✅ | ❌ | N/A | ✅ | ❌ FAIL |
| `/auto-discovery/control/disable` | ✅ | ❌ | N/A | ✅ | ❌ FAIL |
| `/auto-discovery/control/retry/{node_id}` | ✅ | ❌ | N/A | ✅ | ❌ FAIL |

**Query Parameters:** ✅ All snake_case (`start_time`, `end_time`, `event_type`, `limit`, `offset`, `node_id`, `result`)

**Path Parameters:** ✅ snake_case (`{node_id}`)

**Issues Found:**

| Issue | Current | Recommended | Priority |
|-------|---------|-------------|----------|
| Verb in path | `/control/enable` | `/auto-discovery:enable` | High |
| Verb in path | `/control/disable` | `/auto-discovery:disable` | High |
| Verb in path | `/control/retry/{node_id}` | `/retries/{node_id}:trigger` | High |
| Singular noun | `/retry-state` | `/retry-states` | Medium |

---

### 2. In-App Notifications API

**File:** `specs/004-in-app-notifications/contracts/notifications.openapi.yaml`

| Path | Kebab | Nouns | Plural | Hierarchy | Status |
|------|-------|-------|--------|-----------|--------|
| `/notifications` | ✅ | ✅ | ✅ | ✅ | ✅ PASS |
| `/notifications/{id}/read` | ✅ | ❌ | ✅ | ✅ | ❌ FAIL |
| `/notifications/{id}/dismiss` | ✅ | ❌ | ✅ | ✅ | ❌ FAIL |
| `/notifications/{id}` | ✅ | ✅ | ✅ | ✅ | ✅ PASS |
| `/notifications/unread-count` | ✅ | ✅ | ✅ | ✅ | ✅ PASS |

**Query Parameters:** ✅ All snake_case (`page`, `per_page`, `notification_type`, `unread_only`, `reference_id`)

**Path Parameters:** ✅ (`{id}`)

**Issues Found:**

| Issue | Current | Recommended | Priority |
|-------|---------|-------------|----------|
| Verb in path | `/{id}/read` | `/{id}:read` | Medium |
| Verb in path | `/{id}/dismiss` | `/{id}:dismiss` | Medium |

---

### 3. Health Check API

**File:** `specs/005-ota-recovery-rollback/contracts/health-check.yaml`

| Path | Kebab | Nouns | Plural | Hierarchy | Status |
|------|-------|-------|--------|-----------|--------|
| `/api/version/simple` | ✅ | ✅ | N/A | ❌ | ⚠️ WARN |

**Issues Found:**

| Issue | Current | Recommended | Priority |
|-------|---------|-------------|----------|
| Non-standard structure | `/api/version/simple` | `/health` or `/system/health` | Low |
| Redundant `/api` prefix | `/api/version/simple` | `/version` (with server base `/api`) | Low |

---

### 4. OTA Rollback API

**File:** `specs/005-ota-recovery-rollback/contracts/rollback-api.yaml`

| Path | Kebab | Nouns | Plural | Hierarchy | Status |
|------|-------|-------|--------|-----------|--------|
| `/api/rollback/trigger` | ✅ | ❌ | ❌ | ✅ | ❌ FAIL |
| `/api/rollback/history` | ✅ | ✅ | ❌ | ✅ | ⚠️ WARN |
| `/api/rollback/status/{event_id}` | ✅ | ✅ | ❌ | ✅ | ⚠️ WARN |
| `/api/rollback/backups` | ✅ | ✅ | ✅ | ✅ | ✅ PASS |

**Query Parameters:** ✅ All snake_case (`limit`, `offset`)

**Path Parameters:** ✅ snake_case (`{event_id}`)

**Issues Found:**

| Issue | Current | Recommended | Priority |
|-------|---------|-------------|----------|
| Verb in path | `/rollback/trigger` | `POST /rollbacks` or `/rollbacks:trigger` | High |
| Singular collection | `/rollback/` | `/rollbacks/` | Medium |
| Redundant `/api` prefix | `/api/rollback/` | Use server base URL | Low |

---

### 5. IP Pool Management API

**File:** `specs/006-ip-pool-management/contracts/ip-pool-api.yaml`

| Path | Kebab | Nouns | Plural | Hierarchy | Status |
|------|-------|-------|--------|-----------|--------|
| `/ip-pool` | ✅ | ✅ | ❌ | ✅ | ❌ FAIL |
| `/ip-pool/{id}` | ✅ | ✅ | ❌ | ✅ | ❌ FAIL |
| `/ip-pool/{id}/set-default` | ✅ | ❌ | ❌ | ✅ | ❌ FAIL |
| `/ip-pool/preferred` | ✅ | ✅ | ❌ | ✅ | ⚠️ WARN |
| `/ip-pool/health-check` | ✅ | ✅ | ❌ | ✅ | ⚠️ WARN |
| `/external/ip-pool/sync` | ✅ | ✅ | ❌ | ✅ | ❌ FAIL |

**Query Parameters:** ✅ All snake_case (`port_type`, `is_active`, `is_public_facing`, `limit`, `offset`)

**Path Parameters:** ✅ (`{id}`)

**Issues Found:**

| Issue | Current | Recommended | Priority |
|-------|---------|-------------|----------|
| Singular collection | `/ip-pool` | `/ip-pools` | **Critical** |
| Singular collection | `/ip-pool/{id}` | `/ip-pools/{id}` | **Critical** |
| Verb in path | `/{id}/set-default` | `/{id}:set-default` | Medium |
| Singular in external | `/external/ip-pool/sync` | `/external/ip-pools/sync` | High |

---

### 6. Terminal API

**File:** `specs/007-web-terminal/contracts/openapi.yaml`

| Path | Kebab | Nouns | Plural | Hierarchy | Status |
|------|-------|-------|--------|-----------|--------|
| `/terminal/sessions` | ⚠️ | ✅ | ✅ | ⚠️ | ⚠️ WARN |
| `/terminal/sessions/{session_id}` | ⚠️ | ✅ | ✅ | ⚠️ | ⚠️ WARN |
| `/terminal/sessions/{session_id}/history` | ⚠️ | ✅ | ✅ | ✅ | ⚠️ WARN |

**Query Parameters:** ✅ (`limit`)

**Path Parameters:** ✅ snake_case (`{session_id}`)

**Issues Found:**

| Issue | Current | Recommended | Priority |
|-------|---------|-------------|----------|
| Mixed hierarchy | `/terminal/sessions` | `/terminal-sessions` | Medium |
| Inconsistent with others | Uses nested domain | Consider flattening | Low |

**Note:** The current structure `/terminal/sessions` is technically valid as a domain-scoped resource. However, for consistency with other APIs, consider using `/terminal-sessions`.

---

### 7. System Metrics API

**File:** `specs/008-unified-node-management/contracts/system-metrics-api.yaml`

| Path | Kebab | Nouns | Plural | Hierarchy | Status |
|------|-------|-------|--------|-----------|--------|
| `/system/metrics` | ✅ | ✅ | ✅* | ✅ | ✅ PASS |

**Issues Found:** None

**Note:** "metrics" is an uncountable noun, so the singular form is grammatically correct.

---

### 8. L402 Cost Management API

**File:** `specs/009-l402-cost-management/contracts/l402-cost-management.yaml`

| Path | Kebab | Nouns | Plural | Hierarchy | Status |
|------|-------|-------|--------|-----------|--------|
| `/l402/endpoint-fees` | ✅ | ✅ | ✅ | ✅ | ✅ PASS |
| `/l402/endpoint-fees/{id}` | ✅ | ✅ | ✅ | ✅ | ✅ PASS |
| `/l402/outbound/history` | ✅ | ✅ | N/A | ✅ | ✅ PASS |
| `/l402/outbound/summary` | ✅ | ✅ | N/A | ✅ | ✅ PASS |
| `/l402/outbound/export` | ✅ | ✅ | N/A | ✅ | ✅ PASS |
| `/l402/budgets` | ✅ | ✅ | ✅ | ✅ | ✅ PASS |
| `/l402/budgets/{type}/reset` | ✅ | ❌ | ✅ | ✅ | ❌ FAIL |
| `/l402/analytics/summary` | ✅ | ✅ | N/A | ✅ | ✅ PASS |
| `/l402/analytics/time-series` | ✅ | ✅ | N/A | ✅ | ✅ PASS |
| `/l402/dashboard` | ✅ | ✅ | N/A | ✅ | ✅ PASS |

**Query Parameters:** ✅ All snake_case

**Path Parameters:** ✅ (`{id}`, `{type}`)

**Issues Found:**

| Issue | Current | Recommended | Priority |
|-------|---------|-------------|----------|
| Verb in path | `/budgets/{type}/reset` | `/budgets/{type}:reset` | Medium |

---

### 9. Event Bus API

**File:** `specs/010-event-bus-system/contracts/events-api.yaml`

| Path | Kebab | Nouns | Plural | Hierarchy | Status |
|------|-------|-------|--------|-----------|--------|
| `/messages/{message_id}/timeline` | ✅ | ✅ | ✅ | ✅ | ✅ PASS |

**Path Parameters:** ✅ snake_case (`{message_id}`)

**Issues Found:** None ✅

---

## Summary of All Issues

### Critical (Must Fix)

| File | Current Path | Recommended Path |
|------|--------------|------------------|
| ip-pool-api.yaml | `/ip-pool` | `/ip-pools` |
| ip-pool-api.yaml | `/ip-pool/{id}` | `/ip-pools/{id}` |
| ip-pool-api.yaml | `/external/ip-pool/sync` | `/external/ip-pools/sync` |

### High Priority

| File | Current Path | Recommended Path |
|------|--------------|------------------|
| auto-friend-discovery-api.yaml | `/control/enable` | `:enable` (colon style) |
| auto-friend-discovery-api.yaml | `/control/disable` | `:disable` (colon style) |
| auto-friend-discovery-api.yaml | `/control/retry/{node_id}` | `/retries/{node_id}:trigger` |
| rollback-api.yaml | `/rollback/trigger` | `POST /rollbacks` or `:trigger` |
| rollback-api.yaml | `/rollback/` | `/rollbacks/` (pluralize) |

### Medium Priority

| File | Current Path | Recommended Path |
|------|--------------|------------------|
| notifications.openapi.yaml | `/{id}/read` | `/{id}:read` |
| notifications.openapi.yaml | `/{id}/dismiss` | `/{id}:dismiss` |
| ip-pool-api.yaml | `/{id}/set-default` | `/{id}:set-default` |
| l402-cost-management.yaml | `/budgets/{type}/reset` | `/budgets/{type}:reset` |
| auto-friend-discovery-api.yaml | `/retry-state` | `/retry-states` |
| openapi.yaml (terminal) | `/terminal/sessions` | `/terminal-sessions` |

### Low Priority

| File | Current Path | Recommended Path |
|------|--------------|------------------|
| health-check.yaml | `/api/version/simple` | `/health` |
| rollback-api.yaml | `/api/rollback/` | Remove redundant `/api` |

---

## Compliance Score by File

| File | Score | Grade |
|------|-------|-------|
| events-api.yaml | 100% | A |
| system-metrics-api.yaml | 100% | A |
| l402-cost-management.yaml | 90% | A- |
| notifications.openapi.yaml | 80% | B |
| auto-friend-discovery-api.yaml | 57% | D |
| openapi.yaml (terminal) | 67% | C |
| rollback-api.yaml | 50% | D |
| ip-pool-api.yaml | 33% | F |
| health-check.yaml | 50% | D |

---

## Query & Path Parameter Compliance

### Query Parameters ✅ EXCELLENT

All files use **snake_case** for query parameters consistently:

```yaml
# Examples from all files
page, per_page, limit, offset           # Pagination
start_time, end_time, start_date        # Time filters
is_active, is_public_facing             # Boolean filters
port_type, notification_type            # Type filters
sort_by, sort_order                     # Sorting
```

### Path Parameters ✅ EXCELLENT

All files use **snake_case** for path parameters consistently:

```yaml
# Examples from all files
{user_id}
{session_id}
{message_id}
{node_id}
{event_id}
{id}           # Simple id also acceptable
```

---

## Recommended Migration Plan

### Phase 1: Critical Fixes (Week 1)

1. **Pluralize IP Pool endpoints**
   ```yaml
   # Before
   /ip-pool → /ip-pools
   /ip-pool/{id} → /ip-pools/{id}
   /external/ip-pool/sync → /external/ip-pools/sync
   ```

2. **Add backward compatibility aliases**

### Phase 2: High Priority (Week 2-3)

1. **Migrate action endpoints to colon style**
   ```yaml
   # Before → After
   POST /auto-discovery/control/enable → POST /auto-discovery:enable
   POST /notifications/{id}/read → POST /notifications/{id}:read
   POST /rollback/trigger → POST /rollbacks:trigger
   ```

2. **Pluralize remaining singular collections**
   ```yaml
   /rollback/ → /rollbacks/
   /retry-state → /retry-states
   ```

### Phase 3: Low Priority (Week 4+)

1. Flatten terminal paths (optional)
2. Standardize health check endpoint
3. Remove redundant `/api` prefixes

---

## Appendix: Quick Fix Reference

### Colon Style Action Pattern

```yaml
# Convert verb endpoints to colon style
POST /resource/{id}/action    →  POST /resource/{id}:action
POST /resource/action         →  POST /resource:action

# Examples
POST /notifications/{id}/read     →  POST /notifications/{id}:read
POST /auto-discovery/control/enable  →  POST /auto-discovery:enable
POST /budgets/{type}/reset        →  POST /budgets/{type}:reset
```

### Pluralization

```yaml
# Singular → Plural for collections
/ip-pool       →  /ip-pools
/rollback      →  /rollbacks
/retry-state   →  /retry-states
/notification  →  /notifications  # Already correct
```

### Deprecation Header Example

```yaml
# Add to old endpoints during migration
/ip-pool:
  get:
    deprecated: true
    description: |
      **DEPRECATED** - Use /ip-pools instead.
      This endpoint will be removed on 2025-07-01.
    x-sunset: "2025-07-01"
```

