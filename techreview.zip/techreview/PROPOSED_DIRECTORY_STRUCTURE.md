# Proposed Directory Structure

> **Project:** Lightning Network Node Management System  
> **Architecture:** Domain-Driven Design (DDD) with Clean Architecture  
> **Date:** 2025-01-18

---

## Executive Summary

This document proposes a professional directory structure reorganization based on **Domain-Driven Design (DDD)** principles. The goal is to improve:

- **Cohesion**: Related code lives together
- **Discoverability**: Easy to find code for any feature
- **Scalability**: Teams can work independently on domains
- **Maintainability**: Clear boundaries reduce coupling
- **Testability**: Each domain can be tested in isolation

---

## Current Issues

| Issue | Impact | Files Affected |
|-------|--------|----------------|
| Scattered migrations | Build confusion | 202 SQL files in `/packages/backend/migrations/`, 4 in `/migrations/` |
| God files | Hard to maintain | `main.rs` (1,845 lines), `api.ts` (863 lines) |
| Mixed services/repositories | Tight coupling | 28 services, 31 repositories scattered |
| Tests outside packages | CI/CD issues | `/tests/` at root level |
| Documentation sprawl | Hard to find docs | 60+ markdown files across 8 locations |
| Inconsistent component organization | Frontend confusion | 206 files in `/components/` with mixed domains |

---

## Proposed Structure

### Root Level

```
node/
├── .cursor/                         # IDE configuration
│   └── rules/
├── .github/                         # GitHub Actions, templates
│   ├── workflows/
│   └── CODEOWNERS
├── .taskmaster/                     # Task management
│
├── docs/                            # 📚 CENTRALIZED DOCUMENTATION
│   ├── README.md                    # Documentation index
│   ├── architecture/                # ADRs, system design
│   │   ├── decisions/               # Architecture Decision Records
│   │   └── diagrams/                # Mermaid, SVG diagrams
│   ├── api/                         # API documentation
│   │   ├── openapi/                 # OpenAPI specs (consolidated)
│   │   └── guides/
│   ├── deployment/                  # Deployment guides
│   ├── development/                 # Developer guides
│   └── features/                    # Feature documentation
│
├── infra/                           # 🔧 INFRASTRUCTURE
│   ├── docker/                      # Docker configurations
│   ├── scripts/                     # Deployment, maintenance scripts
│   │   ├── deploy/
│   │   ├── backup/
│   │   └── maintenance/
│   └── systemd/                     # Service definitions
│
├── packages/                        # 📦 APPLICATION PACKAGES
│   ├── backend/                     # Rust backend
│   └── node-ui/                     # React frontend
│
├── specs/                           # 📋 FEATURE SPECIFICATIONS
│   └── [feature-name]/
│       ├── README.md
│       ├── contracts/               # OpenAPI specs
│       └── docs/                    # Feature-specific docs
│
├── tools/                           # 🛠️ DEVELOPMENT TOOLS
│   ├── scripts/                     # Dev scripts
│   └── generators/                  # Code generators
│
├── .env.example                     # Environment template
├── Makefile                         # Common commands
├── package.json                     # Root package (workspaces)
├── README.md                        # Project overview
└── CLAUDE.md                        # AI assistant context
```

---

### Backend Structure (Rust)

There are **two options** for organizing domain files:

| Option | Structure | Best For |
|--------|-----------|----------|
| **Option A** | Nested (with subdirectories) | Large domains with many files |
| **Option B** | Flat (no subdirectories) | Small-medium domains with few files |

---

#### 🅰️ Option A: Nested Domain Structure

Use subdirectories (`models/`, `services/`, `repositories/`, `handlers/`) within each domain.

**Best for:** Large domains with 10+ files per category.

```
packages/backend/
├── Cargo.toml
├── Cargo.lock
├── diesel.toml
├── README.md
│
├── migrations/                      # 📊 ALL MIGRATIONS HERE
│   └── [timestamp]_[name]/
│       ├── up.sql
│       └── down.sql
│
├── src/
│   ├── main.rs                      # Entry point (~100 lines max)
│   ├── lib.rs                       # Module exports
│   │
│   │── ══════════════════════════════════════════════════════
│   │                    🔷 CORE LAYER
│   │   (Shared utilities, types, traits - NO business logic)
│   │── ══════════════════════════════════════════════════════
│   │
│   ├── core/
│   │   ├── mod.rs
│   │   │
│   │   ├── errors/                  # Error definitions
│   │   │   ├── mod.rs
│   │   │   ├── app_error.rs         # AppError enum
│   │   │   ├── service_error.rs     # ServiceError enum
│   │   │   └── repository_error.rs  # RepositoryError enum
│   │   │
│   │   ├── types/                   # Shared types & Value Objects
│   │   │   ├── mod.rs
│   │   │   ├── pagination.rs        # Pagination types
│   │   │   ├── api_response.rs      # ApiResponse<T>
│   │   │   └── uuid.rs              # UUID helpers
│   │   │
│   │   ├── traits/                  # Shared trait definitions
│   │   │   ├── mod.rs
│   │   │   ├── repository.rs        # Base repository traits
│   │   │   └── service.rs           # Base service traits
│   │   │
│   │   ├── extractors/              # Axum extractors
│   │   │   ├── mod.rs
│   │   │   ├── validated_json.rs
│   │   │   ├── validated_query.rs
│   │   │   └── claims.rs
│   │   │
│   │   └── utils/                   # Common utilities
│   │       ├── mod.rs
│   │       ├── crypto.rs
│   │       └── time.rs
│   │
│   │── ══════════════════════════════════════════════════════
│   │                 🔷 INFRASTRUCTURE LAYER
│   │      (Technical concerns, external services, database)
│   │── ══════════════════════════════════════════════════════
│   │
│   ├── infrastructure/
│   │   ├── mod.rs
│   │   │
│   │   ├── database/                # Database configuration
│   │   │   ├── mod.rs
│   │   │   ├── pool.rs              # Connection pool
│   │   │   ├── config.rs            # SQLite config
│   │   │   └── schema.rs            # Diesel schema
│   │   │
│   │   ├── http/                    # HTTP server setup
│   │   │   ├── mod.rs
│   │   │   ├── server.rs            # Axum server
│   │   │   └── middleware/
│   │   │       ├── mod.rs
│   │   │       ├── auth.rs          # Auth middleware
│   │   │       ├── cors.rs          # CORS config
│   │   │       ├── rate_limit.rs    # Rate limiting
│   │   │       └── logging.rs       # Request logging
│   │   │
│   │   ├── websocket/               # WebSocket infrastructure
│   │   │   ├── mod.rs
│   │   │   ├── manager.rs
│   │   │   └── events.rs
│   │   │
│   │   ├── external/                # External service clients
│   │   │   ├── mod.rs
│   │   │   ├── http_client.rs       # L402HttpClient
│   │   │   └── ldk_client.rs        # LDK integration
│   │   │
│   │   └── logging/                 # Logging infrastructure
│   │       ├── mod.rs
│   │       └── tracing.rs
│   │
│   │── ══════════════════════════════════════════════════════
│   │                   🔷 DOMAIN LAYER (Option A: Nested)
│   │    (Business logic organized by bounded contexts)
│   │── ══════════════════════════════════════════════════════
│   │
│   ├── domains/
│   │   ├── mod.rs
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 AUTH DOMAIN - Authentication & Authorization
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── auth/
│   │   │   ├── mod.rs
│   │   │   ├── models/
│   │   │   │   ├── mod.rs
│   │   │   │   ├── user.rs
│   │   │   │   ├── claims.rs
│   │   │   │   └── token.rs
│   │   │   ├── services/
│   │   │   │   ├── mod.rs
│   │   │   │   ├── auth_service.rs
│   │   │   │   └── jwt_service.rs
│   │   │   ├── repositories/
│   │   │   │   ├── mod.rs
│   │   │   │   └── user_repository.rs
│   │   │   ├── handlers/
│   │   │   │   ├── mod.rs
│   │   │   │   └── auth_handlers.rs
│   │   │   └── tests/
│   │   │       └── mod.rs
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 LIGHTNING DOMAIN - Payments, Channels, Invoices
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── lightning/
│   │   │   ├── mod.rs
│   │   │   ├── models/
│   │   │   │   ├── mod.rs
│   │   │   │   ├── invoice.rs
│   │   │   │   ├── payment.rs
│   │   │   │   ├── channel.rs
│   │   │   │   └── peer.rs
│   │   │   ├── services/
│   │   │   │   ├── mod.rs
│   │   │   │   ├── payment_service.rs
│   │   │   │   ├── invoice_service.rs
│   │   │   │   ├── channel_service.rs
│   │   │   │   └── ldk_manager.rs
│   │   │   ├── repositories/
│   │   │   │   ├── mod.rs
│   │   │   │   └── payment_repository.rs
│   │   │   ├── handlers/
│   │   │   │   ├── mod.rs
│   │   │   │   ├── payment_handlers.rs
│   │   │   │   ├── invoice_handlers.rs
│   │   │   │   └── channel_handlers.rs
│   │   │   └── tests/
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 L402 DOMAIN - L402 Protocol & Cost Management
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── l402/
│   │   │   ├── mod.rs
│   │   │   ├── models/
│   │   │   │   ├── mod.rs
│   │   │   │   ├── endpoint_fee.rs
│   │   │   │   ├── invoice.rs
│   │   │   │   └── macaroon.rs
│   │   │   ├── services/
│   │   │   │   ├── mod.rs
│   │   │   │   ├── l402_service.rs
│   │   │   │   └── cost_management_service.rs
│   │   │   ├── repositories/
│   │   │   │   ├── mod.rs
│   │   │   │   ├── l402_repository.rs
│   │   │   │   └── cost_management_repository.rs
│   │   │   ├── handlers/
│   │   │   │   ├── mod.rs
│   │   │   │   └── l402_handlers.rs
│   │   │   ├── middleware/
│   │   │   │   └── l402_middleware.rs
│   │   │   └── tests/
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 TERMINAL DOMAIN - Web Terminal & Commands
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── terminal/
│   │   │   ├── mod.rs
│   │   │   ├── models/
│   │   │   │   ├── mod.rs
│   │   │   │   ├── session.rs
│   │   │   │   ├── command.rs
│   │   │   │   └── replay.rs
│   │   │   ├── services/
│   │   │   │   ├── mod.rs
│   │   │   │   ├── terminal_service.rs
│   │   │   │   ├── session_service.rs
│   │   │   │   └── replay_service.rs
│   │   │   ├── repositories/
│   │   │   │   ├── mod.rs
│   │   │   │   ├── session_repository.rs
│   │   │   │   └── command_repository.rs
│   │   │   ├── handlers/
│   │   │   │   └── mod.rs
│   │   │   └── tests/
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 SOCIAL DOMAIN - Friends, Posts, Messages
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── social/
│   │   │   ├── mod.rs
│   │   │   ├── models/
│   │   │   │   ├── mod.rs
│   │   │   │   ├── friend.rs
│   │   │   │   ├── friend_request.rs
│   │   │   │   ├── post.rs
│   │   │   │   ├── message.rs
│   │   │   │   └── notification.rs
│   │   │   ├── services/
│   │   │   │   ├── mod.rs
│   │   │   │   ├── friend_service.rs
│   │   │   │   ├── post_service.rs
│   │   │   │   ├── message_service.rs
│   │   │   │   └── notification_service.rs
│   │   │   ├── repositories/
│   │   │   │   ├── mod.rs
│   │   │   │   ├── friend_repository.rs
│   │   │   │   ├── post_repository.rs
│   │   │   │   └── message_repository.rs
│   │   │   ├── handlers/
│   │   │   │   ├── mod.rs
│   │   │   │   ├── friend_handlers.rs
│   │   │   │   ├── post_handlers.rs
│   │   │   │   └── message_handlers.rs
│   │   │   └── tests/
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 AI DOMAIN - AI Agents & Conversational UI
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── ai/
│   │   │   ├── mod.rs
│   │   │   │
│   │   │   ├── agents/                  # AI Agents subdomain
│   │   │   │   ├── mod.rs
│   │   │   │   ├── models/
│   │   │   │   ├── services/
│   │   │   │   │   ├── agent_service.rs
│   │   │   │   │   ├── scheduler.rs
│   │   │   │   │   └── executor.rs
│   │   │   │   ├── repositories/
│   │   │   │   └── handlers/
│   │   │   │
│   │   │   ├── conversational/          # Conversational UI subdomain
│   │   │   │   ├── mod.rs
│   │   │   │   ├── models/
│   │   │   │   ├── services/
│   │   │   │   │   ├── conversation_service.rs
│   │   │   │   │   └── transpiler.rs
│   │   │   │   ├── providers/           # LLM providers
│   │   │   │   │   ├── mod.rs
│   │   │   │   │   ├── claude.rs
│   │   │   │   │   ├── openai.rs
│   │   │   │   │   ├── openrouter.rs
│   │   │   │   │   └── ollama.rs
│   │   │   │   ├── tools/               # AI tools
│   │   │   │   │   ├── mod.rs
│   │   │   │   │   └── lightning/
│   │   │   │   └── handlers/
│   │   │   │
│   │   │   └── llm/                     # LLM configuration
│   │   │       ├── mod.rs
│   │   │       ├── models/
│   │   │       ├── services/
│   │   │       └── repositories/
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 NETWORK DOMAIN - IP Pool, Rathole, Diagnostics
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── network/
│   │   │   ├── mod.rs
│   │   │   │
│   │   │   ├── ip_pool/                 # IP Pool management
│   │   │   │   ├── mod.rs
│   │   │   │   ├── models/
│   │   │   │   ├── services/
│   │   │   │   ├── repositories/
│   │   │   │   └── handlers/
│   │   │   │
│   │   │   ├── rathole/                 # Rathole proxy
│   │   │   │   ├── mod.rs
│   │   │   │   ├── models/
│   │   │   │   ├── services/
│   │   │   │   └── handlers/
│   │   │   │
│   │   │   └── diagnostics/             # Network diagnostics
│   │   │       ├── mod.rs
│   │   │       ├── port_checker.rs
│   │   │       ├── ip_detector.rs
│   │   │       └── handlers/
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 SYSTEM DOMAIN - Updates, Recovery, Metrics
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── system/
│   │   │   ├── mod.rs
│   │   │   │
│   │   │   ├── updates/                 # OTA Updates
│   │   │   │   ├── mod.rs
│   │   │   │   ├── models/
│   │   │   │   ├── services/
│   │   │   │   └── handlers/
│   │   │   │
│   │   │   ├── recovery/                # LDK Recovery
│   │   │   │   ├── mod.rs
│   │   │   │   ├── models/
│   │   │   │   ├── services/
│   │   │   │   └── handlers/
│   │   │   │
│   │   │   ├── metrics/                 # System Metrics
│   │   │   │   ├── mod.rs
│   │   │   │   ├── models/
│   │   │   │   ├── services/
│   │   │   │   └── handlers/
│   │   │   │
│   │   │   └── activity/                # Activity Logs
│   │   │       ├── mod.rs
│   │   │       ├── models/
│   │   │       ├── services/
│   │   │       └── handlers/
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 API_STORE DOMAIN - External API Integration
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── api_store/
│   │   │   ├── mod.rs
│   │   │   ├── models/
│   │   │   ├── services/
│   │   │   │   ├── api_store_service.rs
│   │   │   │   ├── credits_service.rs
│   │   │   │   └── exchange_rate_service.rs
│   │   │   ├── repositories/
│   │   │   └── handlers/
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 EVENTS DOMAIN - Event Bus System
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   └── events/
│   │       ├── mod.rs
│   │       ├── event_bus.rs
│   │       ├── event_types.rs
│   │       └── handlers/
│   │
│   │── ══════════════════════════════════════════════════════
│   │                   🔷 TRANSPORT LAYER
│   │           (Node-to-Node communication)
│   │── ══════════════════════════════════════════════════════
│   │
│   ├── transport/
│   │   ├── mod.rs
│   │   ├── node_server/                 # Incoming requests
│   │   │   ├── mod.rs
│   │   │   └── handlers/
│   │   └── node_client/                 # Outgoing requests
│   │       └── mod.rs
│   │
│   │── ══════════════════════════════════════════════════════
│   │                   🔷 ROUTING LAYER
│   │              (API route definitions)
│   │── ══════════════════════════════════════════════════════
│   │
│   └── routes/
│       ├── mod.rs
│       ├── v1.rs                        # API v1 routes (deprecated)
│       └── v2.rs                        # API v2 routes (current)
│
└── tests/                           # 🧪 INTEGRATION TESTS
    ├── mod.rs
    ├── helpers/
    ├── integration/
    │   ├── auth_tests.rs
    │   ├── lightning_tests.rs
    │   └── ...
    └── http/                        # HTTP test files
        └── *.http
```

---

#### 🅱️ Option B: Flat Domain Structure (Recommended)

No subdirectories within each domain. Files are named by their purpose.

**Best for:** Small-medium domains with fewer files. Simpler navigation.

**Key principle:** The folder path (`domains/auth/`) already provides context, so file names don't need to repeat the domain name.

```
packages/backend/
├── Cargo.toml
├── Cargo.lock
├── diesel.toml
├── README.md
│
├── migrations/                      # 📊 ALL MIGRATIONS HERE
│   └── [timestamp]_[name]/
│       ├── up.sql
│       └── down.sql
│
├── src/
│   ├── main.rs                      # Entry point (~100 lines max)
│   ├── lib.rs                       # Module exports
│   │
│   ├── core/                        # 🔷 CORE LAYER (same as Option A)
│   │   ├── mod.rs
│   │   ├── errors/
│   │   ├── types/
│   │   ├── traits/
│   │   ├── extractors/
│   │   └── utils/
│   │
│   ├── infrastructure/              # 🔷 INFRASTRUCTURE LAYER (same as Option A)
│   │   ├── mod.rs
│   │   ├── database/
│   │   ├── http/
│   │   ├── websocket/
│   │   ├── external/
│   │   └── logging/
│   │
│   │── ══════════════════════════════════════════════════════
│   │                   🔷 DOMAIN LAYER (Option B: Flat)
│   │    (Business logic - flat file structure per domain)
│   │── ══════════════════════════════════════════════════════
│   │
│   ├── domains/
│   │   ├── mod.rs
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 AUTH DOMAIN
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── auth/
│   │   │   ├── mod.rs              # Module exports & documentation
│   │   │   ├── models.rs           # User, Claims, Token
│   │   │   ├── service.rs          # AuthService, JwtService
│   │   │   ├── repository.rs       # UserRepository
│   │   │   ├── handlers.rs         # HTTP handlers
│   │   │   ├── error.rs            # AuthError enum
│   │   │   └── middleware.rs       # auth_middleware
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 LIGHTNING DOMAIN
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── lightning/
│   │   │   ├── mod.rs
│   │   │   ├── models.rs           # Invoice, Payment, Channel, Peer
│   │   │   ├── service.rs          # PaymentService, InvoiceService
│   │   │   ├── repository.rs       # PaymentRepository
│   │   │   ├── handlers.rs         # HTTP handlers
│   │   │   ├── error.rs            # LightningError enum
│   │   │   └── ldk_manager.rs      # LDK integration (domain-specific)
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 L402 DOMAIN
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── l402/
│   │   │   ├── mod.rs
│   │   │   ├── models.rs           # EndpointFee, L402Invoice, Macaroon
│   │   │   ├── service.rs          # L402Service, CostManagementService
│   │   │   ├── repository.rs       # L402Repository
│   │   │   ├── handlers.rs         # HTTP handlers
│   │   │   ├── error.rs            # L402Error enum
│   │   │   ├── middleware.rs       # l402_middleware
│   │   │   └── client.rs           # L402HttpClient
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 TERMINAL DOMAIN
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── terminal/
│   │   │   ├── mod.rs
│   │   │   ├── models.rs           # Session, Command, Replay
│   │   │   ├── service.rs          # TerminalService, ReplayService
│   │   │   ├── repository.rs       # SessionRepository, CommandRepository
│   │   │   ├── handlers.rs         # HTTP handlers
│   │   │   └── pty_manager.rs      # PTY management (domain-specific)
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 SOCIAL DOMAIN
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── social/
│   │   │   ├── mod.rs
│   │   │   ├── models.rs           # Friend, Post, Message, Notification
│   │   │   ├── service.rs          # FriendService, PostService, etc.
│   │   │   ├── repository.rs       # FriendRepository, PostRepository
│   │   │   ├── handlers.rs         # HTTP handlers
│   │   │   └── error.rs            # SocialError enum
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 AI DOMAIN (with subdomains)
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── ai/
│   │   │   ├── mod.rs
│   │   │   │
│   │   │   ├── agents/             # AI Agents subdomain (flat)
│   │   │   │   ├── mod.rs
│   │   │   │   ├── models.rs
│   │   │   │   ├── service.rs
│   │   │   │   ├── repository.rs
│   │   │   │   ├── handlers.rs
│   │   │   │   ├── scheduler.rs    # Domain-specific
│   │   │   │   └── executor.rs     # Domain-specific
│   │   │   │
│   │   │   ├── conversational/     # Conversational UI subdomain (flat)
│   │   │   │   ├── mod.rs
│   │   │   │   ├── models.rs
│   │   │   │   ├── service.rs
│   │   │   │   ├── handlers.rs
│   │   │   │   ├── transpiler.rs   # Domain-specific
│   │   │   │   └── providers.rs    # LLM providers (Claude, OpenAI, etc.)
│   │   │   │
│   │   │   └── llm/                # LLM configuration subdomain (flat)
│   │   │       ├── mod.rs
│   │   │       ├── models.rs
│   │   │       ├── service.rs
│   │   │       └── repository.rs
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 NETWORK DOMAIN (with subdomains)
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── network/
│   │   │   ├── mod.rs
│   │   │   │
│   │   │   ├── ip_pool/            # IP Pool subdomain (flat)
│   │   │   │   ├── mod.rs
│   │   │   │   ├── models.rs
│   │   │   │   ├── service.rs
│   │   │   │   ├── repository.rs
│   │   │   │   └── handlers.rs
│   │   │   │
│   │   │   ├── rathole/            # Rathole subdomain (flat)
│   │   │   │   ├── mod.rs
│   │   │   │   ├── models.rs
│   │   │   │   ├── service.rs
│   │   │   │   └── handlers.rs
│   │   │   │
│   │   │   └── diagnostics/        # Diagnostics subdomain (flat)
│   │   │       ├── mod.rs
│   │   │       ├── port_checker.rs
│   │   │       ├── ip_detector.rs
│   │   │       └── handlers.rs
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 SYSTEM DOMAIN (with subdomains)
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── system/
│   │   │   ├── mod.rs
│   │   │   │
│   │   │   ├── updates/            # OTA Updates subdomain (flat)
│   │   │   │   ├── mod.rs
│   │   │   │   ├── models.rs
│   │   │   │   ├── service.rs
│   │   │   │   └── handlers.rs
│   │   │   │
│   │   │   ├── recovery/           # LDK Recovery subdomain (flat)
│   │   │   │   ├── mod.rs
│   │   │   │   ├── models.rs
│   │   │   │   ├── service.rs
│   │   │   │   └── handlers.rs
│   │   │   │
│   │   │   ├── metrics/            # System Metrics subdomain (flat)
│   │   │   │   ├── mod.rs
│   │   │   │   ├── models.rs
│   │   │   │   ├── service.rs
│   │   │   │   └── handlers.rs
│   │   │   │
│   │   │   └── activity/           # Activity Logs subdomain (flat)
│   │   │       ├── mod.rs
│   │   │       ├── models.rs
│   │   │       ├── service.rs
│   │   │       └── handlers.rs
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 API_STORE DOMAIN
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── api_store/
│   │   │   ├── mod.rs
│   │   │   ├── models.rs
│   │   │   ├── service.rs          # ApiStoreService, CreditsService
│   │   │   ├── repository.rs
│   │   │   ├── handlers.rs
│   │   │   └── credits.rs          # Credits management (domain-specific)
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 EVENTS DOMAIN
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   └── events/
│   │       ├── mod.rs
│   │       ├── types.rs            # Event type definitions
│   │       ├── bus.rs              # EventBus implementation
│   │       └── handlers.rs         # Event handlers
│   │
│   ├── transport/                   # 🔷 TRANSPORT LAYER (same as Option A)
│   │   └── ...
│   │
│   └── routes/                      # 🔷 ROUTING LAYER (same as Option A)
│       └── ...
│
└── tests/                           # 🧪 INTEGRATION TESTS (same as Option A)
    └── ...
```

---

#### Option B: File Naming Convention

| File Type | Filename | Example Path |
|-----------|----------|--------------|
| Models/Entities | `models.rs` | `domains/auth/models.rs` |
| Service | `service.rs` | `domains/auth/service.rs` |
| Repository | `repository.rs` | `domains/auth/repository.rs` |
| Handlers | `handlers.rs` | `domains/auth/handlers.rs` |
| Error | `error.rs` | `domains/auth/error.rs` |
| Middleware | `middleware.rs` | `domains/auth/middleware.rs` |
| Domain-specific | `<descriptive>.rs` | `domains/lightning/ldk_manager.rs` |

**Why no domain prefix?**

```
❌ REDUNDANT:  domains/auth/auth_repository.rs    # "auth" appears twice
✅ CLEAN:      domains/auth/repository.rs         # folder provides context
```

The folder path already tells you the domain:
- `domains/auth/repository.rs` → Auth repository
- `domains/lightning/repository.rs` → Lightning repository

---

#### Option B: Module File (`mod.rs`) Example

```rust
//! Auth Domain - Authentication & Authorization
//!
//! This domain handles user authentication, JWT tokens, and authorization.
//!
//! # Files
//!
//! - `models.rs` - User, Claims, Token entities
//! - `service.rs` - AuthService, JwtService
//! - `repository.rs` - UserRepository
//! - `handlers.rs` - HTTP endpoint handlers
//! - `error.rs` - AuthError enum
//! - `middleware.rs` - Authentication middleware

mod models;
mod service;
mod repository;
mod handlers;
mod error;
mod middleware;

// Public re-exports
pub use models::*;
pub use service::{AuthService, AuthServiceTrait};
pub use repository::{UserRepository, UserRepositoryTrait};
pub use handlers::*;
pub use error::AuthError;
pub use middleware::auth_middleware;
```

---

#### Comparison: Option A vs Option B

| Aspect | Option A (Nested) | Option B (Flat) |
|--------|-------------------|-----------------|
| **Structure** | `domain/models/user.rs` | `domain/models.rs` |
| **Files per domain** | 10-30+ files | 5-10 files |
| **Directory depth** | 4-5 levels | 3 levels |
| **Navigation** | More clicks/typing | Faster access |
| **Scalability** | Better for large domains | Better for small-medium |
| **File discovery** | Need to know subdirectory | All files visible at once |
| **Module management** | More `mod.rs` files | Fewer `mod.rs` files |

---

#### When to Use Each Option

**Use Option A (Nested) when:**
- Domain has 10+ model files
- Domain has multiple services with complex logic
- Team members work on different layers independently
- You need strict layer separation for code reviews

**Use Option B (Flat) when:**
- Domain has fewer than 10 files total
- You want simpler navigation
- Single developer owns entire domain
- Prefer fewer directories to manage

**Hybrid approach:**
- Use Option B for most domains
- Use Option A only for very large domains (e.g., `ai/`, `social/`)
- Use subdomains (e.g., `ai/agents/`, `ai/conversational/`) to split large domains

---

### Frontend Structure (React/TypeScript)

```
packages/node-ui/
├── package.json
├── tsconfig.json
├── vite.config.ts
├── vitest.config.ts
├── README.md
│
├── public/                          # Static assets
│   ├── manifest.json
│   └── icons/
│
├── src/
│   ├── main.tsx                     # Entry point
│   ├── App.tsx                      # Root component (~50 lines)
│   ├── index.css                    # Global styles
│   │
│   │── ══════════════════════════════════════════════════════
│   │                    🔷 CORE LAYER
│   │   (Shared utilities, types, hooks - NO business logic)
│   │── ══════════════════════════════════════════════════════
│   │
│   ├── core/
│   │   ├── index.ts
│   │   │
│   │   ├── types/                   # Shared TypeScript types
│   │   │   ├── index.ts
│   │   │   ├── api.types.ts         # API response types
│   │   │   ├── common.types.ts      # Common types
│   │   │   └── pagination.types.ts
│   │   │
│   │   ├── hooks/                   # Global hooks
│   │   │   ├── index.ts
│   │   │   ├── useAuth.ts
│   │   │   ├── useWebSocket.ts
│   │   │   ├── useMobile.ts
│   │   │   └── useToast.ts
│   │   │
│   │   ├── utils/                   # Utilities
│   │   │   ├── index.ts
│   │   │   ├── formatters.ts
│   │   │   ├── validators.ts
│   │   │   ├── clipboard.ts
│   │   │   └── logger.ts
│   │   │
│   │   └── constants/
│   │       └── index.ts
│   │
│   │── ══════════════════════════════════════════════════════
│   │                 🔷 INFRASTRUCTURE LAYER
│   │      (Technical concerns: API client, storage, WebSocket)
│   │── ══════════════════════════════════════════════════════
│   │
│   ├── infrastructure/
│   │   ├── index.ts
│   │   │
│   │   ├── api/                     # API client setup
│   │   │   ├── index.ts
│   │   │   ├── client.ts            # Axios/fetch instance
│   │   │   ├── interceptors.ts      # Request/response interceptors
│   │   │   └── error-handler.ts     # API error handling
│   │   │
│   │   ├── storage/                 # Storage abstraction
│   │   │   ├── index.ts
│   │   │   ├── secure-storage.ts    # IndexedDB with encryption
│   │   │   └── local-storage.ts     # Simple local storage
│   │   │
│   │   ├── websocket/               # WebSocket client
│   │   │   ├── index.ts
│   │   │   └── manager.ts
│   │   │
│   │   └── query/                   # React Query setup
│   │       ├── index.ts
│   │       ├── client.ts            # QueryClient config
│   │       └── persister.ts         # Query persister
│   │
│   │── ══════════════════════════════════════════════════════
│   │                   🔷 DOMAIN LAYER
│   │    (Feature modules organized by bounded contexts)
│   │── ══════════════════════════════════════════════════════
│   │
│   ├── domains/
│   │   ├── index.ts
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 AUTH DOMAIN
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── auth/
│   │   │   ├── index.ts             # Public exports
│   │   │   ├── types/
│   │   │   │   └── auth.types.ts
│   │   │   ├── api/
│   │   │   │   └── auth.api.ts
│   │   │   ├── hooks/
│   │   │   │   ├── useLogin.ts
│   │   │   │   ├── useLogout.ts
│   │   │   │   └── useJwtToken.ts
│   │   │   ├── store/               # Domain state (Zustand)
│   │   │   │   └── auth.store.ts
│   │   │   ├── components/
│   │   │   │   ├── LoginForm.tsx
│   │   │   │   ├── AuthGuard.tsx
│   │   │   │   └── RecoverWallet.tsx
│   │   │   └── context/
│   │   │       └── AuthContext.tsx
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 WALLET DOMAIN (Lightning)
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── wallet/
│   │   │   ├── index.ts
│   │   │   ├── types/
│   │   │   │   ├── invoice.types.ts
│   │   │   │   ├── payment.types.ts
│   │   │   │   └── channel.types.ts
│   │   │   ├── api/
│   │   │   │   ├── invoices.api.ts
│   │   │   │   ├── payments.api.ts
│   │   │   │   └── channels.api.ts
│   │   │   ├── hooks/
│   │   │   │   ├── useInvoices.ts
│   │   │   │   ├── usePayments.ts
│   │   │   │   ├── useChannels.ts
│   │   │   │   ├── useSend.ts
│   │   │   │   └── useReceive.ts
│   │   │   ├── store/
│   │   │   │   └── wallet.store.ts
│   │   │   └── components/
│   │   │       ├── InvoiceList.tsx
│   │   │       ├── PaymentForm.tsx
│   │   │       ├── ChannelCard.tsx
│   │   │       └── WalletOverview.tsx
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 TERMINAL DOMAIN
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── terminal/
│   │   │   ├── index.ts
│   │   │   ├── types/
│   │   │   ├── api/
│   │   │   │   └── terminal.api.ts
│   │   │   ├── hooks/
│   │   │   │   ├── useTerminal.ts
│   │   │   │   └── useTerminalWebSocket.ts
│   │   │   └── components/
│   │   │       ├── Terminal.tsx
│   │   │       ├── TerminalSettings.tsx
│   │   │       └── CommandHistory.tsx
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 SOCIAL DOMAIN
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── social/
│   │   │   ├── index.ts
│   │   │   ├── types/
│   │   │   │   ├── friend.types.ts
│   │   │   │   ├── post.types.ts
│   │   │   │   └── message.types.ts
│   │   │   ├── api/
│   │   │   │   ├── friends.api.ts
│   │   │   │   ├── posts.api.ts
│   │   │   │   └── messages.api.ts
│   │   │   ├── hooks/
│   │   │   │   ├── useFriends.ts
│   │   │   │   ├── usePosts.ts
│   │   │   │   └── useMessages.ts
│   │   │   └── components/
│   │   │       ├── FriendList.tsx
│   │   │       ├── PostCard.tsx
│   │   │       ├── MessageThread.tsx
│   │   │       └── NewsFeed.tsx
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 AI DOMAIN
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── ai/
│   │   │   ├── index.ts
│   │   │   │
│   │   │   ├── agents/              # AI Agents
│   │   │   │   ├── types/
│   │   │   │   ├── api/
│   │   │   │   ├── hooks/
│   │   │   │   └── components/
│   │   │   │
│   │   │   └── conversational/      # Conversational UI
│   │   │       ├── types/
│   │   │       ├── api/
│   │   │       ├── hooks/
│   │   │       │   ├── useConversationalUI.ts
│   │   │       │   └── useConversationalFlow.ts
│   │   │       └── components/
│   │   │           ├── ChatInterface.tsx
│   │   │           ├── MessageBubble.tsx
│   │   │           └── RunnerTest.tsx
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 NETWORK DOMAIN
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── network/
│   │   │   ├── index.ts
│   │   │   │
│   │   │   ├── ip-pool/
│   │   │   │   ├── types/
│   │   │   │   ├── api/
│   │   │   │   ├── hooks/
│   │   │   │   └── components/
│   │   │   │
│   │   │   ├── rathole/
│   │   │   │   ├── types/
│   │   │   │   ├── api/
│   │   │   │   ├── hooks/
│   │   │   │   └── components/
│   │   │   │
│   │   │   └── diagnostics/
│   │   │       ├── hooks/
│   │   │       │   └── useNetworkStatus.ts
│   │   │       └── components/
│   │   │           └── NetworkAccessibilityCheck.tsx
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 SYSTEM DOMAIN
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── system/
│   │   │   ├── index.ts
│   │   │   │
│   │   │   ├── updates/
│   │   │   │   ├── types/
│   │   │   │   ├── hooks/
│   │   │   │   │   ├── useUpdateStatus.ts
│   │   │   │   │   └── useUpdateLogs.ts
│   │   │   │   ├── context/
│   │   │   │   │   └── UpdateContext.tsx
│   │   │   │   └── components/
│   │   │   │       └── UpdateProgressDialog.tsx
│   │   │   │
│   │   │   ├── metrics/
│   │   │   │   ├── hooks/
│   │   │   │   │   └── useSystemMetrics.ts
│   │   │   │   └── components/
│   │   │   │       └── MetricsCard.tsx
│   │   │   │
│   │   │   ├── recovery/
│   │   │   │   ├── hooks/
│   │   │   │   │   └── useLdkRecovery.ts
│   │   │   │   └── components/
│   │   │   │
│   │   │   └── notifications/
│   │   │       ├── types/
│   │   │       ├── hooks/
│   │   │       │   └── useNotifications.ts
│   │   │       └── components/
│   │   │           └── NotificationBadge.tsx
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 L402 DOMAIN
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   ├── l402/
│   │   │   ├── index.ts
│   │   │   ├── types/
│   │   │   ├── api/
│   │   │   ├── hooks/
│   │   │   │   └── useL402CostManagement.ts
│   │   │   └── components/
│   │   │
│   │   │── ─────────────────────────────────────────────────
│   │   │   🟦 SETTINGS DOMAIN
│   │   │── ─────────────────────────────────────────────────
│   │   │
│   │   └── settings/
│   │       ├── index.ts
│   │       ├── types/
│   │       ├── hooks/
│   │       └── components/
│   │
│   │── ══════════════════════════════════════════════════════
│   │                   🔷 SHARED LAYER
│   │              (Reusable UI components)
│   │── ══════════════════════════════════════════════════════
│   │
│   ├── shared/
│   │   ├── index.ts
│   │   │
│   │   ├── components/
│   │   │   ├── ui/                  # Base UI (shadcn)
│   │   │   │   ├── button.tsx
│   │   │   │   ├── input.tsx
│   │   │   │   ├── card.tsx
│   │   │   │   ├── dialog.tsx
│   │   │   │   └── ...
│   │   │   │
│   │   │   ├── feedback/            # Feedback components
│   │   │   │   ├── LoadingSpinner.tsx
│   │   │   │   ├── ErrorMessage.tsx
│   │   │   │   ├── ErrorBoundary.tsx
│   │   │   │   └── Toast.tsx
│   │   │   │
│   │   │   └── common/              # Common components
│   │   │       ├── PageHeader.tsx
│   │   │       ├── StatusIndicator.tsx
│   │   │       └── CopyableTooltip.tsx
│   │   │
│   │   └── layouts/                 # Layout components
│   │       ├── MainLayout.tsx
│   │       ├── Header.tsx
│   │       ├── Sidebar.tsx
│   │       └── NavigationTabs.tsx
│   │
│   │── ══════════════════════════════════════════════════════
│   │                   🔷 PAGES LAYER
│   │               (Route page components)
│   │── ══════════════════════════════════════════════════════
│   │
│   ├── pages/
│   │   ├── index.ts
│   │   │
│   │   ├── dashboard/
│   │   │   └── DashboardPage.tsx
│   │   │
│   │   ├── wallet/
│   │   │   ├── WalletPage.tsx
│   │   │   ├── SendPage.tsx
│   │   │   └── ReceivePage.tsx
│   │   │
│   │   ├── terminal/
│   │   │   └── TerminalPage.tsx
│   │   │
│   │   ├── social/
│   │   │   ├── FriendsPage.tsx
│   │   │   ├── MessagesPage.tsx
│   │   │   └── NewsFeedPage.tsx
│   │   │
│   │   ├── ai/
│   │   │   ├── ConversationalUIPage.tsx
│   │   │   └── AgentsPage.tsx
│   │   │
│   │   ├── network/
│   │   │   ├── IpPoolPage.tsx
│   │   │   └── RatholePage.tsx
│   │   │
│   │   ├── system/
│   │   │   ├── UpdatesPage.tsx
│   │   │   ├── MetricsPage.tsx
│   │   │   └── RecoveryPage.tsx
│   │   │
│   │   ├── settings/
│   │   │   └── SettingsPage.tsx
│   │   │
│   │   └── errors/
│   │       └── NotFoundPage.tsx
│   │
│   │── ══════════════════════════════════════════════════════
│   │                   🔷 ROUTING LAYER
│   │── ══════════════════════════════════════════════════════
│   │
│   └── router/
│       ├── index.ts
│       ├── routes.tsx               # Route definitions
│       ├── Router.tsx               # Router component
│       ├── ProtectedRoute.tsx       # Auth guard
│       └── types.ts
│
└── tests/                           # 🧪 TEST FILES
    ├── setup.ts
    ├── mocks/
    └── utils.tsx
```

---

## Domain Mapping

| Domain | Backend Location | Frontend Location | Description |
|--------|------------------|-------------------|-------------|
| **Auth** | `domains/auth/` | `domains/auth/` | Authentication, JWT, users |
| **Lightning** | `domains/lightning/` | `domains/wallet/` | Payments, invoices, channels |
| **L402** | `domains/l402/` | `domains/l402/` | L402 protocol, cost management |
| **Terminal** | `domains/terminal/` | `domains/terminal/` | Web terminal, commands |
| **Social** | `domains/social/` | `domains/social/` | Friends, posts, messages |
| **AI** | `domains/ai/` | `domains/ai/` | AI agents, conversational UI |
| **Network** | `domains/network/` | `domains/network/` | IP pool, rathole, diagnostics |
| **System** | `domains/system/` | `domains/system/` | Updates, recovery, metrics |
| **API Store** | `domains/api_store/` | - | External API integration |
| **Events** | `domains/events/` | - | Event bus system |

---

## Layer Responsibilities

### Core Layer
- **Purpose**: Shared code with NO business logic
- **Contains**: Types, utilities, extractors, base traits
- **Depends on**: Nothing (innermost layer)

### Infrastructure Layer
- **Purpose**: Technical concerns, external integrations
- **Contains**: Database, HTTP server, WebSocket, external clients
- **Depends on**: Core

### Domain Layer
- **Purpose**: Business logic organized by bounded contexts
- **Contains**: Models, services, repositories, handlers
- **Depends on**: Core, Infrastructure interfaces (not implementations)

### Transport Layer (Backend only)
- **Purpose**: Node-to-node communication
- **Contains**: Protocol adapters, message handlers
- **Depends on**: Domain, Infrastructure

### Routing Layer
- **Purpose**: API route definitions
- **Contains**: Route configuration, middleware chains
- **Depends on**: Domain handlers

### Shared Layer (Frontend only)
- **Purpose**: Reusable UI components
- **Contains**: Base components, layouts
- **Depends on**: Core

### Pages Layer (Frontend only)
- **Purpose**: Route page components
- **Contains**: Page-level components
- **Depends on**: Domains, Shared

---

## File Naming Conventions

### Backend (Rust)

| Type | Convention | Example |
|------|------------|---------|
| Module | `snake_case` | `payment_service.rs` |
| Struct | `PascalCase` | `PaymentService` |
| Trait | `PascalCase` + `Trait` | `PaymentServiceTrait` |
| Test file | `*_tests.rs` or `tests/` dir | `payment_service_tests.rs` |

### Frontend (TypeScript)

| Type | Convention | Example |
|------|------------|---------|
| Component | `PascalCase.tsx` | `PaymentForm.tsx` |
| Hook | `use*.ts` | `usePayments.ts` |
| API file | `*.api.ts` | `payments.api.ts` |
| Types | `*.types.ts` | `payment.types.ts` |
| Store | `*.store.ts` | `wallet.store.ts` |

---

## Import Patterns

### Backend

```rust
// ✅ Good - domain imports
use crate::domains::lightning::services::PaymentService;
use crate::domains::auth::models::Claims;
use crate::core::errors::AppError;

// ❌ Bad - scattered imports
use crate::services::payment_service::PaymentService;
use crate::models::user::Claims;
```

### Frontend

```typescript
// ✅ Good - domain imports
import { usePayments } from '@/domains/wallet/hooks';
import { PaymentForm } from '@/domains/wallet/components';
import type { Payment } from '@/domains/wallet/types';

// ❌ Bad - scattered imports
import { usePayments } from '@/hooks/usePayments';
import { PaymentForm } from '@/components/my-wallet/PaymentForm';
```

---

## Migration Priority

| Phase | Focus | Effort | Impact |
|-------|-------|--------|--------|
| **1** | Consolidate migrations | Low | High |
| **2** | Create `core/` and `infrastructure/` | Medium | High |
| **3** | Refactor `main.rs` to ~100 lines | Medium | High |
| **4** | Move auth domain | Medium | Medium |
| **5** | Move lightning domain | High | High |
| **6** | Move remaining domains | High | Medium |
| **7** | Frontend domain restructure | High | Medium |
| **8** | Update all imports | Medium | Low |

---

## Benefits Summary

| Benefit | Description |
|---------|-------------|
| **Discoverability** | Find all payment code in `domains/lightning/` |
| **Team Scaling** | Each team owns a domain |
| **Testing** | Each domain can be tested in isolation |
| **Microservices Ready** | Easy to extract domains later |
| **Reduced Coupling** | Clear dependency rules |
| **Onboarding** | New devs understand structure quickly |

---

## Quick Reference

```
FIND CODE FOR...        →  LOOK IN...
─────────────────────────────────────────────
Auth logic              →  domains/auth/
Payment processing      →  domains/lightning/
L402 middleware         →  domains/l402/
Terminal sessions       →  domains/terminal/
Friend requests         →  domains/social/
AI agents               →  domains/ai/agents/
Conversational UI       →  domains/ai/conversational/
IP pool management      →  domains/network/ip_pool/
OTA updates             →  domains/system/updates/
Database setup          →  infrastructure/database/
HTTP middleware         →  infrastructure/http/middleware/
Shared types            →  core/types/
UI components           →  shared/components/
```

---

*This structure follows Domain-Driven Design principles while being practical for a Lightning Network node management system.*
