# SQL Injection Security Analysis

> **Analysis Date:** 2025-01-18  
> **Database:** SQLite with Diesel ORM  
> **Scope:** Backend Rust codebase

---

## Executive Summary

| Risk Level | Count | Status |
|------------|-------|--------|
| 🔴 **Critical** | 1 | **Confirmed vulnerability** |
| 🟠 **High** | 0 | - |
| 🟡 **Medium** | 2 | Potential concerns |
| 🟢 **Low/Safe** | 8 | Using parameterized queries |

**Overall Assessment:** The project uses Diesel ORM which provides protection against SQL injection in most cases. However, **one critical vulnerability was found** using raw SQL string interpolation.

---

## 🔴 CRITICAL: Confirmed SQL Injection Vulnerability

### Location: `packages/backend/src/l402/repository.rs`

**Line:** 59  
**Severity:** 🔴 Critical  
**CWE:** CWE-89 (SQL Injection)  
**CVSS Score:** 9.8 (Critical)

**Vulnerable Code:**
```rust
// Line 51-62: l402/repository.rs
// If no exact match, use SQLite's GLOB for pattern matching
// GLOB uses * and ? wildcards, which matches our pattern format
use diesel::dsl::sql;
use diesel::sql_types::Bool;

let pattern_fee = l402_endpoint_fees::table
    .filter(l402_endpoint_fees::http_method.eq(&http_method))
    .filter(l402_endpoint_fees::is_active.eq(true))
    .filter(sql::<Bool>(&format!("'{}' GLOB endpoint_path", endpoint_path)))  // ❌ VULNERABLE!
    .first::<L402EndpointFee>(&mut conn)
    .optional()
    .map_err(L402Error::from)?;
```

### Attack Vector

The `endpoint_path` parameter is directly interpolated into the SQL query without sanitization.

**Input Source:** HTTP request path (e.g., `/api/v2/some/path`)

**Exploit Example:**
```
endpoint_path = "' OR 1=1 OR '"
# Results in SQL: '' OR 1=1 OR '' GLOB endpoint_path
# This would match ALL records

endpoint_path = "'; DROP TABLE l402_endpoint_fees; --"
# Potential for destructive SQL injection
```

### Impact

1. **Data Breach:** Attacker can read all L402 endpoint fees and bypass payment requirements
2. **Authentication Bypass:** Could bypass L402 payment verification entirely
3. **Data Manipulation:** Potential to modify or delete data
4. **Information Disclosure:** Can enumerate database schema

### Recommended Fix

**Option 1: Use Diesel's built-in `like` with escaped patterns (Recommended)**
```rust
use diesel::TextExpressionMethods;

// Escape special GLOB characters in endpoint_path
fn escape_glob_pattern(input: &str) -> String {
    input
        .replace('[', "[[]")
        .replace('*', "[*]")
        .replace('?', "[?]")
        .replace('\'', "''")
}

let safe_endpoint_path = escape_glob_pattern(&endpoint_path);

let pattern_fee = l402_endpoint_fees::table
    .filter(l402_endpoint_fees::http_method.eq(&http_method))
    .filter(l402_endpoint_fees::is_active.eq(true))
    .filter(l402_endpoint_fees::endpoint_path.like(&safe_endpoint_path))
    .first::<L402EndpointFee>(&mut conn)
    .optional()
    .map_err(L402Error::from)?;
```

**Option 2: Use parameterized SQL query**
```rust
use diesel::sql_query;
use diesel::sql_types::Text;

let pattern_fee = sql_query(
    "SELECT * FROM l402_endpoint_fees 
     WHERE http_method = ? 
     AND is_active = 1 
     AND ? GLOB endpoint_path"
)
.bind::<Text, _>(&http_method)
.bind::<Text, _>(&endpoint_path)
.get_result::<L402EndpointFee>(&mut conn)
.optional()
.map_err(L402Error::from)?;
```

**Option 3: Application-level pattern matching**
```rust
// Fetch all active endpoints for the HTTP method
let all_fees = l402_endpoint_fees::table
    .filter(l402_endpoint_fees::http_method.eq(&http_method))
    .filter(l402_endpoint_fees::is_active.eq(true))
    .load::<L402EndpointFee>(&mut conn)
    .map_err(L402Error::from)?;

// Perform GLOB matching in Rust (safe)
let pattern_fee = all_fees.into_iter()
    .find(|fee| glob_match(&fee.endpoint_path, &endpoint_path));
```

---

## 🟢 Safe SQL Usage (Properly Parameterized)

### 1. `bulletin_board/repository/repository.rs` - ✅ SAFE

```rust
// Line 65-67: Uses parameterized query with .bind()
let row = diesel::sql_query("SELECT * FROM buddies WHERE id = ?")
    .bind::<diesel::sql_types::Text, _>(buddy_id)  // ✅ Parameterized
    .get_result::<BuddyRow>(&mut self.conn)
```

### 2. `db_config.rs` - ✅ SAFE

```rust
// Lines 12-33: Static PRAGMA statements (no user input)
diesel::sql_query("PRAGMA journal_mode = WAL").execute(conn)?;
diesel::sql_query("PRAGMA busy_timeout = 10000").execute(conn)?;
diesel::sql_query("PRAGMA synchronous = NORMAL").execute(conn)?;
diesel::sql_query("PRAGMA cache_size = -10000").execute(conn)?;
diesel::sql_query("PRAGMA foreign_keys = ON").execute(conn)?;
diesel::sql_query("PRAGMA temp_store = MEMORY").execute(conn)?;
```

### 3. `services/rollback/rollback_service.rs` - ✅ SAFE

```rust
// Line 117: Static query (no user input)
let result = diesel::sql_query("SELECT version FROM schema_version ORDER BY version DESC LIMIT 1")
```

### 4. `repositories/system_metrics_repository.rs` - ⚠️ Review Needed

Uses `diesel::sql_query` - needs verification that user input is not interpolated.

---

## 🟡 Medium Risk: Potential Concerns

### 1. Dynamic `like` Pattern Usage

**File:** `repositories/terminal/saved_command_repository.rs`

```rust
// Line 172-173
.like(search_pattern.clone())
.or(terminal_saved_commands::description.like(search_pattern))
```

**Assessment:** Diesel's `.like()` method is generally safe as it uses parameterized queries. However, verify that `search_pattern` doesn't contain unescaped LIKE wildcards (`%`, `_`) that could cause unintended matches.

**Recommendation:** Escape LIKE special characters in user input:
```rust
fn escape_like_pattern(input: &str) -> String {
    input
        .replace('%', "\\%")
        .replace('_', "\\_")
}
```

### 2. String Concatenation in Error Messages

**Multiple files** use `format!()` with potentially sensitive data in error messages. While this doesn't directly cause SQL injection, it could leak information.

---

## SQL Query Patterns in Codebase

### Query Types Found

| Pattern | Count | Safety |
|---------|-------|--------|
| Diesel ORM queries | ~1000+ | ✅ Safe (parameterized) |
| `diesel::sql_query()` with `.bind()` | 3 | ✅ Safe |
| `diesel::sql_query()` with `format!()` | 1 | ❌ **VULNERABLE** |
| Static PRAGMA queries | 6 | ✅ Safe (no user input) |

### Diesel ORM Protection

The project primarily uses Diesel ORM, which provides automatic SQL injection protection through:

1. **Type-safe query builder:** Compiles to parameterized SQL
2. **Automatic escaping:** User input is escaped by default
3. **No string interpolation:** Queries are built using Rust types

**Example of safe Diesel usage (common pattern in codebase):**
```rust
// This is safe - Diesel converts to parameterized query
l402_endpoint_fees::table
    .filter(l402_endpoint_fees::endpoint_path.eq(&endpoint_path))
    .filter(l402_endpoint_fees::http_method.eq(&http_method))
    .first::<L402EndpointFee>(&mut conn)
```

---

## Input Validation Analysis

### HTTP Input Sources

| Extractor | Usage Count | Validation |
|-----------|-------------|------------|
| `Path()` | ~50+ | Type validation only |
| `Query()` | ~30+ | Type validation only |
| `Json()` | ~200+ | Via `validator` crate |
| `ValidatedJson` | Used | Full validation ✅ |

### Recommendation: Input Sanitization Layer

Add input sanitization for all string parameters that may be used in queries:

```rust
// Add to validation/mod.rs
pub fn sanitize_sql_input(input: &str) -> String {
    // Remove or escape dangerous characters
    input
        .replace('\'', "''")
        .replace(';', "")
        .replace("--", "")
        .replace("/*", "")
        .replace("*/", "")
}

// For LIKE/GLOB patterns
pub fn sanitize_pattern_input(input: &str) -> String {
    input
        .replace('*', "")
        .replace('?', "")
        .replace('%', "")
        .replace('_', "")
        .replace('[', "")
        .replace(']', "")
}
```

---

## Action Items

### 🔴 Immediate (P0)

1. **Fix `l402/repository.rs:59`** - Replace `format!()` with parameterized query
2. **Add input validation** for `endpoint_path` parameter before it reaches the repository
3. **Security review** of all `sql_query()` usages

### 🟠 Short-term (P1)

4. **Escape LIKE patterns** in `saved_command_repository.rs`
5. **Add SQL injection tests** to CI/CD pipeline
6. **Enable Clippy lint** for raw SQL string interpolation

### 🟡 Medium-term (P2)

7. **Implement input sanitization layer** for all string inputs
8. **Add security audit logging** for suspicious query patterns
9. **Consider SQLx** for compile-time query verification

---

## Testing Recommendations

### SQL Injection Test Cases

```rust
#[cfg(test)]
mod sql_injection_tests {
    use super::*;

    #[tokio::test]
    async fn test_endpoint_path_injection() {
        let repo = L402Repository::new(test_pool());
        
        // Test injection attempts
        let malicious_inputs = vec![
            "' OR 1=1 --",
            "'; DROP TABLE l402_endpoint_fees; --",
            "' UNION SELECT * FROM users --",
            "\\' OR \\'1\\'=\\'1",
            "%00",
            "{{constructor.constructor('return this')()}}",
        ];

        for input in malicious_inputs {
            let result = repo.get_endpoint_fee(input, "GET").await;
            // Should either return None or error, never execute injection
            assert!(result.is_ok() || result.is_err());
        }
    }
}
```

### Recommended Tools

| Tool | Purpose |
|------|---------|
| `sqlx` | Compile-time SQL verification |
| `cargo-audit` | Dependency vulnerability scanning |
| SQLMap | Penetration testing |
| OWASP ZAP | Automated security testing |

---

## Summary

| Finding | Severity | Status |
|---------|----------|--------|
| SQL injection in `l402/repository.rs:59` | 🔴 Critical | **Fix immediately** |
| LIKE pattern in `saved_command_repository.rs` | 🟡 Medium | Review & escape |
| Other SQL queries | 🟢 Safe | Using Diesel ORM |

**The codebase generally follows secure practices with Diesel ORM, but the one identified vulnerability in `l402/repository.rs` requires immediate attention.**

---

## References

- [OWASP SQL Injection](https://owasp.org/www-community/attacks/SQL_Injection)
- [CWE-89: SQL Injection](https://cwe.mitre.org/data/definitions/89.html)
- [Diesel Security](https://diesel.rs/guides/getting-started/)
- [SQLite Injection](https://www.sqlite.org/lang_expr.html#like)

