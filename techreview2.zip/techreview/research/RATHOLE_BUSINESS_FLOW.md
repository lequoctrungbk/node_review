# Rathole Business Process Flow

## 📊 Complete Rathole Business Flow Diagram

```mermaid
sequenceDiagram
    participant Client as 👤 Client Node<br/>(Behind NAT)
    participant UI as 🎨 Node UI
    participant Backend as 🔧 Backend Service
    participant DB as 🗄️ SQLite Database
    participant Server as 🌐 Server Node<br/>(Public IP)
    participant LDK as ⚡ LDK Lightning
    participant Rathole as 🔗 Rathole Service
    participant Gossip as 📡 Gossip Network

    %% Phase 1: Service Discovery
    rect rgb(240, 248, 255)
        Note over Client, Gossip: Phase 1: Service Discovery
        Client->>UI: User clicks "Proxy Discovery"
        UI->>Backend: GET /rathole/proxy/discover
        Backend->>Gossip: Query gossip network for proxy services
        Gossip-->>Backend: Return list of proxy providers
        Backend-->>UI: Return formatted service list
        UI-->>Client: Display available proxy services
    end

    %% Phase 2: Service Request & L402 Payment
    rect rgb(255, 250, 240)
        Note over Client, LDK: Phase 2: L402 Payment Flow

        Client->>UI: Click "Request Proxy" on Server Node
        UI->>Backend: POST /rathole/proxy/request
        Backend->>Server: POST /rathole/proxy/register (L402 protected)
        Server->>Server: Generate Lightning invoice (L402)
        Server-->>Backend: HTTP 402 + Invoice + Macaroon
        Backend-->>UI: Show payment dialog
        UI-->>Client: Display invoice QR code

        Client->>LDK: Pay Lightning invoice
        LDK-->>Server: Payment confirmed
        Server->>Server: Verify payment + issue access token
        Server-->>Backend: Success + Registration details
    end

    %% Phase 3: Port Allocation & Tunnel Setup
    rect rgb(240, 255, 240)
        Note over Server, Rathole: Phase 3: Infrastructure Setup

        Server->>DB: Save proxy registration record
        DB-->>Server: Registration confirmed
        Server->>Server: Allocate available port (e.g., 8080)
        Server->>Rathole: Create tunnel configuration
        Rathole-->>Server: Hot-reload configuration
        Server-->>Backend: Return allocated port + token

        Backend->>Backend: Determine port_type from request
        Backend->>DB: Create IP pool entry (ip_source: ProxyClient)
        DB-->>Backend: IP pool entry created
    end

    %% Phase 4: Client Tunnel Setup
    rect rgb(255, 240, 245)
        Note over Backend, Rathole: Phase 4: Client Configuration

        Backend->>Rathole: Generate client tunnel config
        Rathole-->>Backend: Client configuration ready
        Backend->>Rathole: Hot-reload client configuration
        Rathole-->>Backend: Client tunnel active

        Backend->>UI: WebSocket event: "proxy_activated"
        UI-->>Client: Show success toast + real-time UI update
    end

    %% Phase 5: Network Broadcasting
    rect rgb(248, 248, 255)
        Note over Backend, Gossip: Phase 5: Network Integration

        Backend->>Gossip: Broadcast updated node metadata
        Gossip-->>Backend: Metadata broadcast confirmed
        Backend->>Backend: Trigger IP pool health check
        Backend->>Backend: Schedule background health check

        Backend->>UI: WebSocket event: "ip_pool_updated"
        UI-->>Client: IP Pool tab updates automatically
    end

    %% Phase 6: Health Monitoring & Maintenance
    rect rgb(255, 248, 240)
        Note over Backend, DB: Phase 6: Health & Maintenance

        Backend->>Backend: Background health check task
        Backend->>Server: TCP connection test to public_ip:port
        Server-->>Backend: Connection status (open/filtered/closed)
        Backend->>DB: Update connection_state, latency, success_rate
        DB-->>Backend: Health metrics saved

        Backend->>UI: WebSocket event: "health_check_complete"
        UI-->>Client: IP status updates (🟢 Open, ⚠️ Filtered, ❌ Closed)
    end

    %% Phase 7: Ongoing Operations
    rect rgb(248, 255, 248)
        Note over Client, Server: Phase 7: Production Usage

        Client->>Server: Traffic flows through rathole tunnel
        Server->>Server: Track usage metrics
        Server->>Server: Monitor capacity limits

        loop Every 30 minutes
            Backend->>Server: Periodic health check
            Server-->>Backend: Verify tunnel still active
            Backend->>DB: Update health metrics
        end

        alt Token expires or payment fails
            Server->>Rathole: Close tunnel
            Server->>DB: Mark registration expired
            Server->>Gossip: Update service availability
            Backend->>UI: Show "tunnel expired" notification
        end
    end
```

---

## 🎯 Detailed Business Flow Breakdown

### **Phase 1: Service Discovery** 🔍
**Business Purpose**: Help users find available proxy services

```
User Journey:
1. User behind NAT needs public connectivity
2. Navigates to Network → Proxy Discovery tab
3. System queries gossip network for proxy providers
4. UI displays list of available services with pricing
```

**Key Business Rules:**
- Services filtered by compatibility (protocol support)
- Pricing displayed clearly (sats per port type)
- Capacity indicators show availability
- Real-time updates from gossip network

---

### **Phase 2: L402 Payment Flow** 💰
**Business Purpose**: Monetize proxy services using Lightning micropayments

```
Payment Workflow:
1. User selects service and clicks "Request"
2. Server generates Lightning invoice via L402
3. Client pays invoice using Lightning wallet
4. Server verifies payment and issues access token
5. Client receives registration confirmation
```

**Key Business Rules:**
- **HTTP 402**: "Payment Required" response
- **Macaroon tokens**: Bearer authentication
- **Invoice amounts**: Configurable per port type
- **Payment verification**: Cryptographic proof required
- **Token expiration**: 30 days default

---

### **Phase 3: Infrastructure Provisioning** 🏗️
**Business Purpose**: Automatically allocate and configure proxy infrastructure

```
Provisioning Steps:
1. Server allocates available port from pool
2. Creates rathole tunnel configuration
3. Updates registration database
4. Generates client configuration
5. Hot-reloads both server and client tunnels
```

**Key Business Rules:**
- **Port allocation**: Intelligent assignment algorithm
- **Capacity limits**: Maximum concurrent clients
- **Configuration persistence**: Survives restarts
- **Token management**: Unique tokens per client tunnel

---

### **Phase 4: IP Pool Integration** 📍
**Business Purpose**: Make borrowed IPs discoverable and manageable

```
IP Pool Integration:
1. Automatically create IP pool entry
2. Set ip_source = "ProxyClient" (distinguishes from manual IPs)
3. Set priority = 1000 (lower than direct IPs)
4. Trigger gossip broadcast with updated metadata
5. UI updates in real-time via WebSocket
```

**Key Business Rules:**
- **IP source hierarchy**: Direct (1) > Proxy (100) > ProxyClient (1000)
- **Automatic defaults**: First IP for port type becomes default
- **Health monitoring**: Background TCP connectivity checks
- **User control**: Can promote ProxyClient IPs to default

---

### **Phase 5: Network Broadcasting** 📡
**Business Purpose**: Make proxy IPs discoverable to other nodes

```
Broadcasting Process:
1. Update node metadata with new IP pool
2. Broadcast via Lightning gossip network
3. Other nodes receive updated connection options
4. Enables seamless peer discovery and connection
```

**Key Business Rules:**
- **Metadata updates**: Real-time IP pool synchronization
- **Gossip efficiency**: Optimized broadcasting
- **Discovery protocol**: Standard Lightning gossip format
- **Privacy preservation**: Only public-facing IPs shared

---

### **Phase 6: Health Monitoring** 🔍
**Business Purpose**: Ensure proxy tunnels remain operational

```
Health Monitoring:
1. Background TCP connectivity tests
2. Latency and success rate tracking
3. Automatic deactivation on failures
4. Real-time UI status updates
```

**Key Business Rules:**
- **Health check frequency**: Configurable intervals
- **Failure thresholds**: Auto-deactivation after consecutive failures
- **Connection states**: Open/Filtered/Closed/Unknown
- **Performance metrics**: Latency, success rate tracking

---

### **Phase 7: Production Operations** 🚀
**Business Purpose**: Ongoing service delivery and maintenance

```
Operational Activities:
1. Traffic routing through active tunnels
2. Usage metrics and capacity monitoring
3. Periodic health verification
4. Automatic cleanup of expired registrations
5. Real-time capacity updates via gossip
```

**Key Business Rules:**
- **Capacity management**: Dynamic allocation/deallocation
- **Usage tracking**: For billing and analytics
- **Expiration handling**: Automatic tunnel closure
- **Service availability**: Real-time status broadcasting

---

## 📊 Business Value Chain

### **For Proxy Providers (Server Nodes):**
```
Revenue Stream:
┌─ Public IP owners monetize spare bandwidth
├─ Lightning micropayments for NAT traversal
├─ Automated capacity management
├─ Minimal operational overhead
└─ Passive income from network infrastructure
```

### **For Proxy Consumers (Client Nodes):**
```
Value Proposition:
┌─ Zero-configuration NAT traversal
├─ Pay-per-use pricing (no subscriptions)
├─ Lightning-fast setup (< 30 seconds)
├─ Automatic IP pool management
├─ Seamless integration with existing workflows
└─ Fallback protection with priority system
```

### **For Network Ecosystem:**
```
Network Effects:
┌─ Increased Lightning node connectivity
├─ Better network resilience through redundancy
├─ Economic incentives for infrastructure provision
├─ Democratized access to public connectivity
└─ Enhanced peer-to-peer communication capabilities
```

---

## 🎨 UI/UX Flow Integration

### **Proxy Discovery Interface:**
```
┌─ Network Page ──────────────────┐
│ ┌─ Tabs ──────────────────────┐ │
│ │ 📡 Network     🔗 Proxy     │ │
│ │                           │ │
│ ├─ Proxy Discovery ──────────┤ │
│ │                           │ │
│ │ 🌐 Available Services      │ │
│ │ ├─ Alice's Node ⚡ 10 sats │ │
│ │ │   Lightning: ✅ HTTP: ✅  │ │
│ │ │   [Request Service]      │ │
│ │ └───────────────────────────┘ │
│ │ ├─ Bob's Node ⚡ 15 sats    │ │
│ │ │   Lightning: ✅           │ │
│ │ └───────────────────────────┘ │
│ └─────────────────────────────┘ │
└─────────────────────────────────┘
```

### **IP Pool Management:**
```
┌─ Network Page ──────────────────┐
│ ┌─ Tabs ──────────────────────┐ │
│ │ 📍 IP Pool     🔗 Proxy     │ │
│ │                           │ │
│ ├─ Lightning Port IPs ──────┤ │
│ │                           │ │
│ │ 🟢 198.51.100.20:9735 ⭐    │ │
│ │    ├─ Direct ⚡ │ Priority: 1 │ │
│ │    ├─ Health: Open │ 8ms     │ │
│ │    └─ Manually configured     │ │
│ │                           │ │
│ │ 🟢 203.0.113.5:8080         │ │
│ │    ├─ Rathole 🔗 │ Priority: 1000│ │
│ │    ├─ Health: Open │ 25ms    │ │
│ │    └─ Borrowed from Alice     │ │
│ └─────────────────────────────┘ │
└─────────────────────────────────┘
```

---

## 🔄 Error Handling & Edge Cases

### **Payment Failures:**
```
Client pays → Payment fails → Graceful degradation:
1. Show payment error message
2. Allow retry with new invoice
3. Log for debugging
4. Don't create tunnel until payment confirmed
```

### **Port Allocation Failures:**
```
No available ports → Capacity exceeded:
1. Show "Service temporarily unavailable"
2. Update gossip with reduced capacity
3. Suggest alternative providers
4. Automatic retry when capacity frees up
```

### **Tunnel Failures:**
```
Active tunnel fails → Automatic recovery:
1. Detect via health checks
2. Attempt tunnel reconnection
3. Deactivate IP pool entry if persistent
4. Notify user via UI
5. Update gossip network status
```

---

## 📈 Success Metrics

### **Business Metrics:**
- **Adoption Rate**: % of NAT nodes using proxy services
- **Revenue Generation**: Total sats earned by proxy providers
- **User Satisfaction**: Time to successful connection
- **Network Coverage**: % increase in routable Lightning nodes

### **Technical Metrics:**
- **Connection Success Rate**: > 95% successful tunnel establishments
- **Payment Success Rate**: > 99% successful L402 payments
- **Tunnel Uptime**: > 99% tunnel availability
- **Health Check Accuracy**: > 95% accurate connection status

### **User Experience Metrics:**
- **Time to Service**: < 30 seconds from request to active tunnel
- **Discovery Speed**: < 5 seconds to load proxy service list
- **Real-time Updates**: < 1 second UI updates after state changes
- **Error Recovery**: Automatic recovery from > 80% of failure scenarios

This comprehensive business flow ensures Rathole delivers both **technical excellence** and **business value** by creating a sustainable marketplace for NAT traversal services within the Lightning Network ecosystem.
