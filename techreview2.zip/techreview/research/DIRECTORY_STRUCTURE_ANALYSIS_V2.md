# Directory Structure Analysis V2

> **Analysis Date:** 2025-01-21
> **Project:** Node - Lightning Network Operating System + VPN Extension
> **Previous Version:** DIRECTORY_STRUCTURE_ANALYSIS.md (2025-01-18)

---

## Executive Summary

**Previous Analysis**: Good foundation, identified critical issues, proposed Domain-Driven Design for backend.

**V2 Updates**: Added VPN service extension, security hardening, scalability considerations, and infrastructure modernization.

**Key Additions:**
- 🌐 **VPN Service Architecture** (major new feature)
- 🛡️ **Security-focused Structure** (post-attack vector analysis)
- 📊 **Monitoring & Observability** (production readiness)
- ☁️ **Infrastructure as Code** (deployment automation)
- 🔄 **Microservices Preparation** (scalability)

---

## Current Directory Tree Overview (Updated)

```
node/
├── .cursor/                    # IDE configuration
├── .github/                    # GitHub workflows & templates
├── .infrastructure/            # 🆕 Infrastructure as Code
├── config/                     # Brand configuration
├── data/                       # Static JSON data
├── docs/                       # Documentation (70+ files)
├── infra/                      # Legacy infrastructure scripts (⚠️ migrate to .infrastructure/)
├── migrations/                 # ❌ CRITICAL: Move to packages/backend/
├── node_modules/               # Dependencies
├── packages/
│   ├── backend/                # Rust backend (726 files)
│   ├── node-ui/                # React frontend (427 files)
│   └── vpn-service/           # 🆕 NEW: VPN service package
├── scripts/                    # Utility scripts (mixed)
├── specs/                      # Feature specifications
├── sprints/                    # Sprint documentation
├── tests/                      # ❌ CRITICAL: Move to packages/
├── tools/                      # Additional tools
├── AGENTS.md                   # Coding conventions
├── CLAUDE.md                   # AI assistant config
├── Makefile                    # Build automation
├── migration-plan.md           # ❌ Move to docs/planning/
├── notes.md                    # ❌ Remove from repo
├── package.json                # Root package
├── README.md                   # Project overview
├── TODO.md                     # ❌ Move to docs/planning/
└── yarn.lock                   # Lockfile
```

---

## 🔴 Critical Issues (Updated)

### Issue 1: Migrations Outside Package Directory
**UNCHANGED** - Still critical, move immediately.

### Issue 2: Tests Directory at Root Level
**UNCHANGED** - Still critical, move immediately.

### Issue 3: Documentation Sprawl
**UPDATED** - Now includes VPN documentation requirements.

**New Requirements:**
```
docs/
├── vpn/                        # 🆕 VPN service docs
│   ├── architecture/
│   ├── api/
│   ├── deployment/
│   └── security/
├── security/                   # 🆕 Security documentation
│   ├── threat-model.md
│   ├── attack-vectors.md
│   ├── security-audit.md
│   └── compliance/
└── monitoring/                 # 🆕 Observability docs
    ├── metrics.md
    ├── alerting.md
    └── dashboards/
```

---

## 🆕 NEW: VPN Service Architecture

### VPN Package Structure
```
packages/vpn-service/           # 🆕 NEW PACKAGE
├── src/
│   ├── core/
│   │   ├── wireguard/          # WireGuard implementation
│   │   │   ├── manager.rs
│   │   │   ├── peer.rs
│   │   │   └── crypto.rs
│   │   ├── routing/            # Traffic routing engine
│   │   │   ├── engine.rs
│   │   │   ├── rules.rs
│   │   │   └── geoip.rs
│   │   └── censorship/         # Censorship detection
│   │       ├── detector.rs
│   │       ├── bypass.rs
│   │       └── patterns.rs
│   ├── services/
│   │   ├── connection_manager.rs
│   │   ├── pricing_engine.rs
│   │   ├── bandwidth_limiter.rs
│   │   └── exit_node_manager.rs
│   ├── models/
│   │   ├── vpn_config.rs
│   │   ├── connection.rs
│   │   ├── pricing.rs
│   │   └── geo_location.rs
│   ├── handlers/
│   │   ├── vpn_endpoints.rs
│   │   ├── connection_api.rs
│   │   └── monitoring_api.rs
│   ├── repository/
│   │   ├── connection_repo.rs
│   │   ├── pricing_repo.rs
│   │   └── audit_repo.rs
│   └── lib.rs
├── tests/
│   ├── unit/
│   ├── integration/
│   └── e2e/
├── migrations/
├── Cargo.toml
├── Dockerfile
└── README.md
```

### VPN Integration Points
```
packages/backend/src/
├── domains/
│   └── vpn_integration/         # 🆕 Bridge between main app and VPN
│       ├── mod.rs
│       ├── handlers.rs
│       ├── service.rs
│       └── models.rs
└── shared/
    └── vpn_client/              # 🆕 VPN client utilities
        ├── mod.rs
        ├── connection.rs
        └── monitoring.rs
```

---

## 🛡️ NEW: Security-Hardened Structure

### Security-First Directory Organization
```
packages/backend/src/
├── security/                    # 🆕 Dedicated security module
│   ├── authentication/
│   │   ├── jwt.rs
│   │   ├── lightning_auth.rs
│   │   └── l402.rs
│   ├── authorization/
│   │   ├── rbac.rs
│   │   ├── policies.rs
│   │   └── permissions.rs
│   ├── cryptography/
│   │   ├── keys.rs
│   │   ├── encryption.rs
│   │   └── signatures.rs
│   ├── rate_limiting/
│   │   ├── global_limiter.rs
│   │   ├── per_ip_limiter.rs
│   │   └── per_endpoint_limiter.rs
│   ├── validation/
│   │   ├── input_validator.rs
│   │   ├── sanitization.rs
│   │   └── content_filter.rs
│   └── audit/
│       ├── logger.rs
│       ├── events.rs
│       └── compliance.rs
```

### Secure Configuration Management
```
config/
├── security/                    # 🆕 Security configurations
│   ├── jwt_config.yaml
│   ├── firewall_rules.yaml
│   ├── rate_limits.yaml
│   ├── encryption_keys/         # ⚠️ Encrypted at rest
│   └── certificates/
├── vpn/                         # 🆕 VPN configurations
│   ├── wireguard/
│   ├── exit_nodes.yaml
│   └── censorship_rules.yaml
└── monitoring/
    ├── prometheus.yaml
    ├── alertmanager.yaml
    └── grafana/
```

---

## 📊 NEW: Monitoring & Observability

### Centralized Monitoring Structure
```
packages/monitoring/             # 🆕 NEW PACKAGE
├── src/
│   ├── metrics/
│   │   ├── lightning_metrics.rs
│   │   ├── vpn_metrics.rs
│   │   ├── system_metrics.rs
│   │   └── business_metrics.rs
│   ├── tracing/
│   │   ├── distributed_tracing.rs
│   │   ├── log_aggregation.rs
│   │   └── correlation.rs
│   ├── alerting/
│   │   ├── rules/
│   │   ├── channels/
│   │   └── escalations/
│   └── dashboards/
│       ├── grafana/
│       └── custom/
├── docker-compose.yml
├── prometheus.yml
├── alertmanager.yml
└── grafana/
    └── dashboards/
```

### Application-Level Observability
```
packages/backend/src/
├── observability/               # 🆕 Observability module
│   ├── metrics.rs              # Prometheus metrics
│   ├── tracing.rs              # Distributed tracing
│   ├── logging.rs              # Structured logging
│   └── health.rs               # Health checks
```

---

## ☁️ NEW: Infrastructure as Code

### Infrastructure Directory Structure
```
.infrastructure/                 # 🆕 Centralized IaC
├── terraform/
│   ├── modules/
│   │   ├── vpn_exit_nodes/
│   │   ├── lightning_nodes/
│   │   ├── monitoring/
│   │   └── networking/
│   ├── environments/
│   │   ├── development/
│   │   ├── staging/
│   │   └── production/
│   └── main.tf
├── ansible/
│   ├── playbooks/
│   │   ├── vpn_setup.yml
│   │   ├── lightning_node.yml
│   │   └── monitoring.yml
│   ├── roles/
│   └── inventory/
├── docker/
│   ├── vpn-service/
│   ├── lightning-node/
│   └── monitoring/
├── kubernetes/
│   ├── manifests/
│   ├── helm/
│   └── operators/
└── scripts/
    ├── deploy.sh
    ├── rollback.sh
    └── health-check.sh
```

---

## 🔄 NEW: Microservices Preparation

### Service Decomposition Strategy
```
packages/
├── backend/                    # Monolithic (current)
├── vpn-service/               # 🆕 New microservice
├── api-gateway/              # 🆕 Future: API Gateway service
├── payment-service/          # 🆕 Future: L402/Lightning service
├── user-service/             # 🆕 Future: Authentication service
├── notification-service/     # 🆕 Future: WebSocket/Push service
└── shared/                   # 🆕 Shared libraries
    ├── common/
    ├── crypto/
    ├── network/
    └── storage/
```

### Service Communication
```
shared/
├── proto/                     # 🆕 Protocol Buffers
│   ├── vpn.proto
│   ├── lightning.proto
│   └── common.proto
├── events/                    # 🆕 Event definitions
│   ├── vpn_events.rs
│   ├── payment_events.rs
│   └── user_events.rs
└── clients/                   # 🆕 Service clients
    ├── vpn_client.rs
    ├── payment_client.rs
    └── user_client.rs
```

---

## 🟠 High Severity Issues (Updated)

### Issue 5: Backend - Mixed Architecture Patterns
**UPDATED** - Now includes security and VPN integration considerations.

**Enhanced DDD Structure:**
```
packages/backend/src/
├── domains/
│   ├── activity/              # ✅ Keep
│   ├── ai_agents/             # ✅ Keep
│   ├── api_store/             # ✅ Keep
│   ├── auth/                  # ❌ Move to shared/security/
│   ├── conversation/          # ✅ Keep
│   ├── l402/                  # ❌ Move to payment-service/
│   ├── ldk_recovery/          # ✅ Keep
│   ├── network/               # ✅ Keep
│   ├── node/                  # ✅ Keep
│   ├── rathole/               # ✅ Keep (VPN foundation)
│   ├── social_network/        # ✅ Keep
│   ├── terminal/              # ✅ Keep
│   └── vpn_integration/       # 🆕 NEW: VPN bridge
├── shared/
│   ├── auth/                  # 🆕 Moved from domains/
│   ├── database/              # ✅ Keep
│   ├── events/                # ✅ Keep
│   ├── security/              # 🆕 NEW
│   ├── transport/             # ✅ Keep
│   ├── websocket/             # ✅ Keep
│   └── vpn_client/            # 🆕 NEW
├── config.rs
├── error.rs
├── lib.rs
├── main.rs                    # ⚠️ Still large, consider splitting
└── routes.rs
```

### Issue 6: Frontend - Component Organization
**UPDATED** - Added VPN UI components.

**Enhanced Frontend Structure:**
```
packages/node-ui/src/
├── components/
│   ├── features/
│   │   ├── agents/            # ✅ Keep
│   │   ├── auth/              # ✅ Keep
│   │   ├── vpn/               # 🆕 NEW: VPN management UI
│   │   │   ├── dashboard/
│   │   │   ├── connection/
│   │   │   ├── servers/
│   │   │   └── settings/
│   │   ├── lightning/         # ✅ Keep
│   │   └── ... (other features)
│   ├── shared/                # ✅ Keep
│   └── ui/                    # ✅ Keep
├── hooks/
│   ├── vpn/                   # 🆕 VPN-specific hooks
│   │   ├── useVpnConnection.ts
│   │   ├── useVpnServers.ts
│   │   └── useVpnPricing.ts
│   └── ... (other hooks)
├── lib/
│   ├── api/
│   │   ├── vpn.ts             # 🆕 VPN API client
│   │   └── ... (other APIs)
│   └── ... (other utilities)
```

---

## 🆕 NEW: Scalability Considerations

### Horizontal Scaling Structure
```
packages/
├── load-balancer/             # 🆕 API Gateway/Load Balancer
├── service-discovery/         # 🆕 Service registration/discovery
└── config-management/         # 🆕 Centralized configuration

.infrastructure/
├── scaling/
│   ├── auto-scaling.tf
│   ├── load-balancing.yml
│   └── service-mesh/
└── cdn/
    ├── cloudflare/
    └── fastly/
```

### Database Scaling
```
packages/backend/
├── database/
│   ├── primary/               # Main database
│   ├── read-replicas/         # Read scaling
│   └── cache/                 # Redis/Memcached layer
```

---

## 🆕 NEW: Compliance & Legal Structure

### Regulatory Compliance
```
docs/
├── compliance/
│   ├── gdpr/
│   ├── ccpa/
│   ├── vpn-licensing/
│   └── financial-regulations/
└── legal/
    ├── terms-of-service/
    ├── privacy-policy/
    └── dmca/
```

### Audit Trail Structure
```
packages/audit-service/         # 🆕 NEW PACKAGE
├── src/
│   ├── collectors/
│   ├── storage/
│   └── reporting/
└── tests/
```

---

## Summary: Updated Priority Actions

### 🔴 P0 - Critical (Immediate - This Week)
| Issue | Action | Effort | Rationale |
|-------|--------|--------|-----------|
| #1 | Move migrations/ to backend/ | 1 hour | Diesel requirement |
| #2 | Move tests/ to backend/ | 1 hour | Rust convention |
| #3 | Clean root docs | 2 hours | Organization |
| **NEW** | Create .infrastructure/ | 4 hours | IaC foundation |
| **NEW** | Add security module | 8 hours | Post-attack analysis |

### 🟠 P1 - High (This Month)
| Issue | Action | Effort | Rationale |
|-------|--------|--------|-----------|
| #5 | DDD refactor + security | 3 weeks | Architecture health |
| #6 | Component organization | 1 week | Maintainability |
| #7 | API file split | 3 days | Code organization |
| **NEW** | VPN service package | 2 weeks | Major feature |
| **NEW** | Monitoring setup | 1 week | Production readiness |

### 🟡 P2 - Medium (This Quarter)
| Issue | Action | Effort | Rationale |
|-------|--------|--------|-----------|
| #4 | Script consolidation | 1 day | Developer experience |
| #8 | Hook grouping | 2 days | Code organization |
| **NEW** | Microservices prep | 1 week | Scalability |
| **NEW** | Compliance structure | 3 days | Legal requirements |
| **NEW** | CDN integration | 1 week | Performance |

### 🟢 P3 - Low (Backlog)
| Issue | Action | Effort | Rationale |
|-------|--------|--------|-----------|
| #10 | Standard files | 2 hours | Professionalism |
| #11 | Naming fixes | 1 day | Consistency |
| #12 | Clean empty modules | 2 hours | Code health |

---

## Recommended Target Structure V2

### Root Level (Modernized)
```
node/
├── .cursor/                    # IDE config
├── .github/                    # GitHub automation
├── .infrastructure/            # 🆕 IaC centralization
├── config/                     # App configurations
├── docs/                       # Documentation hub
├── packages/                   # Service packages
├── scripts/                    # Development scripts
├── AGENTS.md                   # AI assistant config
├── CHANGELOG.md                # Release notes
├── CONTRIBUTING.md             # Contribution guide
├── Makefile                    # Build automation
├── package.json                # Root dependencies
├── README.md                   # Project overview
└── yarn.lock                   # Lockfile
```

### Multi-Package Architecture
```
packages/
├── backend/                    # Core Lightning OS
├── node-ui/                    # Web interface
├── vpn-service/               # 🆕 VPN functionality
├── monitoring/                # 🆕 Observability
├── audit-service/             # 🆕 Compliance
└── shared/                    # 🆕 Common libraries
    ├── crypto/
    ├── network/
    ├── storage/
    └── proto/                  # gRPC/protobuf definitions
```

### Infrastructure as Code
```
.infrastructure/
├── terraform/                  # Cloud infrastructure
├── ansible/                    # Configuration management
├── kubernetes/                # Container orchestration
├── docker/                     # Container definitions
└── monitoring/                 # Infrastructure monitoring
```

---

## Migration Strategy V2

### Phase 1: Foundation (Week 1-2)
1. ✅ Move critical directories (migrations/, tests/)
2. ✅ Create .infrastructure/ structure
3. ✅ Add security module skeleton
4. ✅ Setup monitoring foundations

### Phase 2: VPN Integration (Week 3-6)
1. 🆕 Create vpn-service package
2. 🆕 Implement WireGuard core
3. 🆕 Add VPN UI components
4. 🆕 Integrate L402 pricing

### Phase 3: Production Readiness (Week 7-12)
1. 🆕 Implement monitoring stack
2. 🆕 Add compliance framework
3. 🆕 Setup IaC pipelines
4. 🆕 Performance optimization

### Phase 4: Scale & Polish (Month 4+)
1. 🆕 Microservices decomposition
2. 🆕 Global CDN integration
3. 🆕 Enterprise features
4. 🆕 Advanced security features

---

## Risk Assessment V2

### Technical Risks
| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| VPN complexity | Medium | High | Start with MVP, iterate |
| Security hardening | Medium | High | Dedicated security review |
| Performance at scale | Low | Medium | Monitoring + optimization |
| Regulatory compliance | Medium | High | Legal consultation |

### Business Risks
| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| Market competition | High | Medium | Lightning advantage |
| Regulatory changes | Medium | High | Compliance framework |
| Technical debt | Medium | Medium | Regular refactoring |
| Team scaling | Low | Medium | Documentation + processes |

---

## Success Metrics

### Technical Metrics
- **Latency**: <100ms for Lightning payments
- **Uptime**: 99.9% SLA
- **Security**: Zero critical vulnerabilities
- **Scalability**: Support 10K+ concurrent users

### Business Metrics
- **Revenue**: $5K+/month from VPN subscriptions
- **Adoption**: 1000+ active Lightning nodes
- **User Satisfaction**: 4.5+ star rating
- **Compliance**: 100% regulatory compliance

---

## Conclusion

**Original Analysis**: Solid foundation, good direction.

**V2 Enhancements**:
- 🌐 **VPN Service**: Major new revenue stream
- 🛡️ **Security First**: Post-attack vector hardening
- 📊 **Observability**: Production-grade monitoring
- ☁️ **Infrastructure**: Cloud-native architecture
- 🔄 **Scalability**: Microservices preparation

**The structure now supports both current Lightning OS and future VPN service expansion while maintaining security, observability, and scalability.**

**Ready to implement the critical fixes and start VPN development?** 🚀
