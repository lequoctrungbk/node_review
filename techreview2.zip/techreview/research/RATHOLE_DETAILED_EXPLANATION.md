# 🔀 Rathole: NAT Traversal & Proxy Service

## Tổng quan về Rathole

**Rathole** là một công cụ NAT traversal và proxy service được tích hợp sâu vào hệ thống Lightning Network Operating System của bạn. Nó giải quyết vấn đề **NAT traversal** - một vấn đề phổ biến khi các node Lightning Network chạy sau NAT/firewall không thể expose port trực tiếp.

## 🎯 Rathole là gì?

### **Khái niệm cơ bản**
Rathole là một reverse tunnel/proxy tool được viết bằng Rust, cho phép:
- **NAT Traversal**: Các node sau NAT có thể expose services ra internet
- **Reverse Tunneling**: Tạo tunnel ngược từ public server về private node
- **Port Forwarding**: Forward traffic từ public port về local service

### **Trong hệ thống của bạn**
Rathole được sử dụng như một **monetized proxy service** tích hợp với L402 micropayments:
- Users thanh toán bằng Lightning Network để sử dụng proxy
- System tự động allocate ports và manage connections
- Tích hợp với IP pool management và gossip protocol

## 🏗️ Kiến trúc Rathole trong hệ thống

### **1. Core Components**

#### **RatholeService** (`rathole/mod.rs`)
```rust
pub struct RatholeService {
    handle: Option<thread::JoinHandle<()>>,     // Thread chạy rathole
    shutdown_tx: Option<broadcast::Sender<bool>>, // Shutdown signal
    config: Config,                            // System config
    rathole_config: RatholeConfig,             // Rathole specific config
    config_file_path: PathBuf,                 // TOML config file
    // ... monitoring fields
}
```

**Chức năng chính:**
- Quản lý lifecycle của rathole process
- Hot reload configuration
- Error handling và recovery
- Panic detection và recovery

#### **RatholeProxyService** (`rathole/proxy_service.rs`)
```rust
pub struct RatholeProxyService {
    config: ProxyServiceConfig,
    active_registrations: Arc<RwLock<HashMap<String, ProxyRegistration>>>,
    used_ports: Arc<RwLock<Vec<u16>>>,
    repository: ProxyRegistrationRepository,
    port_allocation_repository: PortAllocationRepository,
}
```

**Chức năng chính:**
- Quản lý proxy registrations
- Port allocation và deallocation
- Pricing và billing integration
- Resource management

### **2. Configuration Architecture**

#### **RatholeConfig**
```rust
pub struct RatholeConfig {
    pub mode: String,                    // "server" or "client"
    pub bind_addr: String,              // Server: bind address
    pub remote_addr: String,            // Client: server address
    pub default_token: String,          // Authentication token
    pub services: HashMap<String, RatholeServiceConfig>,
}
```

#### **Service Configuration**
```rust
pub struct RatholeServiceConfig {
    pub token: String,                  // Service-specific token
    pub bind_addr: Option<String>,      // Server mode: public bind addr
    pub local_addr: Option<String>,     // Client mode: local service addr
    pub service_type: String,           // "tcp" or "udp"
}
```

### **3. Two Operating Modes**

## 🖥️ **Server Mode**
```toml
[server]
bind_addr = "0.0.0.0:8000"
default_token = "server_token_123"

[server.services.econ-v1]
bind_addr = "0.0.0.0:8001"
token = "service_token_456"
type = "tcp"
```

**Server mode hoạt động như:**
- **Public Proxy Server**: Chấp nhận connections từ clients
- **Port Multiplexer**: Route traffic đến đúng service dựa trên token
- **Traffic Forwarder**: Forward traffic từ public port về client

## 🏠 **Client Mode**
```toml
[client]
remote_addr = "proxy-server.example.com:8000"
default_token = "client_token_789"

[client.services.my-api]
local_addr = "127.0.0.1:3000"
token = "service_token_456"
type = "tcp"
```

**Client mode hoạt động như:**
- **Service Exposer**: Expose local services qua tunnel
- **Reverse Proxy**: Kết nối ngược về server
- **Traffic Receiver**: Nhận traffic từ server và forward về local service

## 💰 **Monetization với L402**

### **L402 Integration**
Rathole được tích hợp với **L402 micropayments** để monetize proxy service:

```rust
// Pricing configuration
pub struct ProxyServiceConfig {
    pub api_port_price_msats: u64,          // 1000 msats = 0.001 sats
    pub lightning_port_price_msats: u64,    // 5000 msats = 0.005 sats
    pub max_concurrent_clients: u32,        // Resource limits
}
```

### **Payment Flow**
1. **Client Request**: User muốn expose service
2. **L402 Challenge**: Server gửi payment request
3. **Lightning Payment**: User thanh toán qua Lightning Network
4. **Port Allocation**: Server allocate port và tạo token
5. **Proxy Setup**: Rathole tunnel được thiết lập

### **Service Types & Pricing**
- **API Port**: 1 sat/hour - cho web services, APIs
- **Lightning Port**: 5 sats/hour - cho Lightning node connections

## 🔄 **Workflow Hoạt động**

### **1. Service Registration**
```
Client Node ──HTTP──► Proxy Server
    │                       │
    │  1. Register Service  │
    └───► L402 Payment      │
                            │
                    ┌───────┴───────┐
                    │   Payment     │
                    │ Verification  │
                    └───────┬───────┘
                            │
                    ┌───────┴───────┐
                    │ Port + Token  │
                    │  Allocation   │
                    └───────────────┘
```

### **2. Tunnel Establishment**
```
Client Node ◄──Rathole──► Proxy Server
    │                       │
    │  Local Service        │  Public Port
    │  127.0.0.1:3000       │  proxy.com:8081
    │                       │
    └───────────────────────┘
        Reverse Tunnel
```

### **3. Traffic Flow**
```
Internet User ──HTTP──► Proxy Server:8081
                            │
                    ┌───────┴───────┐
                    │Token Validation│
                    │& Routing       │
                    └───────┬───────┘
                            │
Internet User ◄──Tunnel──► Client Node:3000
```

## 🔧 **Technical Implementation**

### **1. Service Lifecycle Management**
```rust
impl RatholeService {
    pub async fn start(&mut self) -> Result<()> {
        // Validate config
        self.validate_config()?;

        // Generate TOML config
        self.write_config_file()?;

        // Spawn rathole thread
        let handle = thread::spawn(move || {
            // Tokio runtime + rathole execution
            runtime.block_on(run(cli, shutdown_rx))
        });

        // Monitor startup
        self.monitor_startup().await?;
    }
}
```

### **2. Port Allocation Algorithm**
```rust
impl RatholeProxyService {
    pub async fn allocate_proxy(&self, request: AllocateProxyRequest)
        -> Result<ClientProxyRegistration> {

        // Find available port
        let port = self.find_available_port(request.service_type).await?;

        // Generate secure token
        let token = self.generate_secure_token()?;

        // Create registration
        let registration = ProxyRegistration {
            client_node_id: request.node_id,
            assigned_port: port,
            token: token,
            expires_at: Utc::now() + Duration::hours(1),
        };

        // Store in database
        self.repository.save(&registration).await?;

        Ok(registration)
    }
}
```

### **3. Connection Monitoring**
```rust
// Health checks
pub async fn health_check(&self, port: u16) -> Result<bool> {
    match timeout(
        Duration::from_secs(5),
        TcpStream::connect(format!("127.0.0.1:{}", port))
    ).await {
        Ok(Ok(_)) => Ok(true),
        _ => Ok(false),
    }
}
```

## 🛡️ **Security Considerations**

### **1. Authentication & Authorization**
- **Token-based auth**: Mỗi service có unique token
- **L402 protection**: Payment-based access control
- **Rate limiting**: Per-client và global limits

### **2. Resource Protection**
- **Port exhaustion prevention**: Limited port pools
- **Connection limits**: Max concurrent clients
- **Timeout enforcement**: Automatic cleanup

### **3. Traffic Security**
- **TLS termination**: Optional SSL/TLS support
- **Token validation**: Every request validated
- **Audit logging**: All proxy activities logged

## 🔗 **Integration Points**

### **1. IP Pool Management**
```rust
#[async_trait]
impl RatholeServiceHook for RatholeServiceHookImpl {
    async fn on_proxy_allocated(
        &self,
        proxy_response: &ClientProxyRegistration,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        // Add proxy IP to IP pool
        // Update gossip announcements
        // Notify other nodes
    }
}
```

### **2. Gossip Protocol**
Rathole IPs được announce qua gossip network:
- **Node Discovery**: New proxy nodes announce availability
- **Service Discovery**: Services announce endpoints
- **Health Updates**: Connection status propagation

### **3. WebSocket Events**
```rust
// Real-time proxy status updates
pub enum ProxyEvent {
    ProxyAllocated { node_id: String, port: u16 },
    ProxyDeallocated { node_id: String, port: u16 },
    ProxyHealthCheck { node_id: String, status: bool },
}
```

## 📊 **Monitoring & Metrics**

### **1. System Metrics**
- **Active Connections**: Per port, per client
- **Bandwidth Usage**: Per service, per client
- **Error Rates**: Connection failures, timeouts
- **Revenue Tracking**: Payments collected

### **2. Health Monitoring**
- **Port Availability**: Automatic port health checks
- **Service Uptime**: Rathole process monitoring
- **Resource Usage**: Memory, CPU, network stats

### **3. Alerting**
- **Port Exhaustion**: When available ports < threshold
- **High Error Rates**: Connection failure alerts
- **Payment Failures**: L402 payment processing issues

## 🚀 **Advanced Features**

### **1. Hot Configuration Reload**
```rust
pub fn update_config_with_hot_reload(&mut self, new_config: RatholeConfig) -> Result<()> {
    // Validate new config
    // Write to file
    // Rathole auto-detects file change
    // No service restart needed
}
```

### **2. Automatic Recovery**
```rust
pub async fn recover(&mut self) -> Result<()> {
    // Stop failed service
    self.stop().await?;

    // Reset panic state
    self.reset_panic_state();

    // Restart with validated config
    self.start().await?;
}
```

### **3. Multi-Protocol Support**
- **TCP**: Primary protocol for HTTP/WebSocket
- **UDP**: For Lightning Network (future)
- **TLS Termination**: SSL offloading option

## 🎯 **Use Cases**

### **1. Lightning Node Operation**
```rust
// Node behind NAT wants to run Lightning service
let registration = proxy_service.allocate_proxy(AllocateProxyRequest {
    service_type: ServiceType::Lightning,
    duration_hours: 24,
}).await?;

// Now accessible at proxy-server.com:assigned_port
```

### **2. API Service Exposure**
```rust
// Developer wants to expose REST API temporarily
let api_proxy = proxy_service.allocate_proxy(AllocateProxyRequest {
    service_type: ServiceType::Api,
    duration_hours: 1,
}).await?;

// API now accessible publicly with L402 protection
```

### **3. Development Testing**
```rust
// Test Lightning integration without port forwarding
let test_proxy = proxy_service.allocate_proxy(AllocateProxyRequest {
    service_type: ServiceType::Both,
    duration_hours: 1,
}).await?;
```

## 🔧 **Configuration Examples**

### **Server Configuration**
```toml
[server]
bind_addr = "0.0.0.0:2333"
default_token = "server_default_token"

[server.services]
[server.services.api-service]
bind_addr = "0.0.0.0:8080"
token = "api_service_token"
type = "tcp"

[server.services.lightning-node]
bind_addr = "0.0.0.0:9735"
token = "lightning_token"
type = "tcp"
```

### **Client Configuration**
```toml
[client]
remote_addr = "proxy.lightning-os.com:2333"
default_token = "client_token"

[client.services]
[client.services.my-api]
local_addr = "127.0.0.1:3000"
token = "api_service_token"
type = "tcp"

[client.services.my-node]
local_addr = "127.0.0.1:9735"
token = "lightning_token"
type = "tcp"
```

## 🎉 **Kết luận**

Rathole là **core component** của hệ thống, giải quyết vấn đề NAT traversal một cách **monetized và secure**. Sự tích hợp với L402 micropayments tạo ra một **business model** độc đáo:

- **Problem Solved**: NAT traversal cho Lightning nodes
- **Revenue Model**: Pay-per-use proxy service
- **Security**: Multi-layer protection (tokens, payments, rate limiting)
- **Scalability**: Dynamic port allocation và resource management

Rathole biến một infrastructure problem thành một **revenue opportunity** thông minh! 🚀⚡




