# Directory Structure Analysis V3

> **Analysis Date:** 2025-01-21
> **Project:** Node - Lightning Network Operating System
> **Previous Version:** DIRECTORY_STRUCTURE_ANALYSIS.md (2025-01-18)
> **Focus:** Current Structure Optimization (No New Modules)

---

## Executive Summary

**Previous Analysis**: Identified critical structural issues requiring immediate fixes.

**V3 Updates**: Focused purely on optimizing current structure without introducing new modules. Updated priorities based on current project state and implementation complexity.

**Key Changes:**
- Updated priority matrix with realistic effort estimates
- Enhanced migration strategies for critical fixes
- Refined DDD recommendations for backend
- Improved frontend organization proposals
- Added implementation phases and dependencies

---

## Architectural Philosophy

### Domains vs Features: Architectural Layer Separation

**Backend (Business Logic Layer) uses `domains/`** because it implements **Domain-Driven Design (DDD)** principles. Backend code represents the core business capabilities and problem domain of the Lightning Network Operating System. Each domain (conversation, payments, networking, social) encapsulates business rules, data models, and domain logic that solve specific business problems.

**Frontend (User Interface Layer) uses `features/`** because it implements **user-facing functionality** organized around user stories and product features. Frontend code represents the solution space - how users interact with the system through UI components, workflows, and user experiences.

**This separation maintains clear architectural boundaries:**
- **Backend domains** = What the system does (business capabilities)
- **Frontend features** = How users access those capabilities (user interface)

---

## Current Directory Tree Overview (Updated)

```
node/
├── .cursor/                    # IDE configuration
├── config/                     # Brand configuration
├── data/                       # Static JSON data
├── docs/                       # Documentation (70+ files)
├── infra/                      # Infrastructure scripts
├── migrations/                 # ❌ CRITICAL: Move to packages/backend/
├── node_modules/               # Dependencies
├── packages/
│   ├── backend/                # Rust backend (726 files)
│   └── node-ui/                # React frontend (427 files)
├── scripts/                    # Utility scripts
├── specs/                      # Feature specifications
├── sprints/                    # Sprint documentation
├── tests/                      # ❌ CRITICAL: Move to packages/
├── tools/                      # Additional tools
├── AGENTS.md                   # Coding conventions
├── CLAUDE.md                   # AI assistant config
├── Makefile                    # Build automation
├── migration-plan.md           # ❌ Move to docs/planning/
├── notes.md                    # ❌ Remove from repo
├── package.json                # Root package
├── README.md                   # Project overview
├── TODO.md                     # ❌ Move to docs/planning/
└── yarn.lock                   # Lockfile
```

---

## 🔴 Critical Issues (Updated Priority Assessment)

### Issue 1: Migrations Outside Package Directory
**STATUS: UNCHANGED** - Still critical, highest priority.

**Current:**
```
node/
├── migrations/                 # ❌ At root level
│   ├── 2025-11-16.../
│   └── 2025-11-17.../
└── packages/
    └── backend/
        └── migrations/         # ✅ Should be here (if exists)
```

**Problem:**
- Migrations belong to backend package
- Diesel expects migrations in crate root
- Causes confusion about ownership
- Blocks proper package isolation

**Recommendation:**
```
packages/backend/
└── migrations/                 # Move here
    ├── 2025-11-16.../
    └── 2025-11-17.../
```

**Updated Effort:** 1 hour (simple move operation)

---

### Issue 2: Tests Directory at Root Level
**STATUS: UNCHANGED** - Still critical, highest priority.

**Current:**
```
node/
├── tests/                      # ❌ At root level
│   ├── conversation_service_tests.rs
│   ├── helpers/
│   ├── rathole_endpoints.http
│   └── unit/
```

**Problem:**
- Rust tests outside the crate
- Integration tests scattered
- `.http` test files mixed with Rust tests
- No clear ownership of test files

**Recommendation:**
```
packages/backend/
├── src/
├── tests/                      # Integration tests
│   ├── conversation_service_tests.rs
│   └── helpers/
└── http-tests/                 # API test files
    └── rathole_endpoints.http
```

**Updated Effort:** 1 hour (simple move + rename)

---

### Issue 3: Documentation Sprawl
**STATUS: UPDATED** - Still high severity, refined organization.

**Current State:** Documentation in **7+ different locations**

```
node/
├── docs/                       # Main docs (70+ files)
│   ├── adr/
│   ├── api/
│   ├── architecture/
│   ├── features/
│   └── ... (many more)
├── specs/                      # Feature specs (90+ files)
├── sprints/                    # Sprint docs (50+ files)
├── migration-plan.md           # Root level ❌
├── notes.md                    # Root level ❌
└── TODO.md                     # Root level ❌
```

**Problems:**
1. Hard to find relevant documentation
2. Unclear ownership (specs vs docs?)
3. Stale files at root level
4. Sprint-specific docs become stale

**Refined Recommendation:**
```
docs/                            # 📚 CENTRALIZED DOCUMENTATION
├── README.md                    # Documentation index
├── architecture/                # ADRs, system design
│   ├── decisions/               # Architecture Decision Records
│   └── diagrams/                # System diagrams
├── api/                         # API documentation
│   ├── openapi/                 # OpenAPI specs
│   └── guides/                  # API guides
├── development/                 # Developer guides
│   ├── coding-standards.md
│   └── contribution-guide.md
├── features/                    # Feature documentation
├── planning/                    # Project planning docs
│   ├── migration-plan.md        # Moved from root
│   └── TODO.md                  # Moved from root
└── operations/                  # Operational docs
```

**Updated Effort:** 4 hours (consolidation + reorganization)

---

## 🟠 High Severity Issues (Updated)

### Issue 4: Scripts in Multiple Locations
**STATUS: UPDATED** - Refined consolidation strategy.

**Current:**
```
node/
├── infra/                       # 47 shell scripts
├── scripts/                     # 7 files (mixed types)
└── tools/                       # 2 shell scripts
```

**Refined Recommendation:**
```
scripts/                         # 🔧 CONSOLIDATED SCRIPTS
├── infra/                       # Infrastructure scripts
│   ├── deploy/
│   ├── docker/
│   └── systemd/
├── dev/                         # Development scripts
│   ├── test.sh
│   ├── lint.sh
│   └── build.sh
└── tools/                       # Utility tools
    ├── mcp-server.js
    └── audit-rebrand.sh
```

**Updated Effort:** 2 hours (consolidation + categorization)

---

### Issue 5: Backend - Mixed Architecture Patterns
**STATUS: UPDATED** - More realistic DDD transition plan.

**Current Backend Structure:**
```
packages/backend/src/
├── activity/                   # Domain module ✅
├── ai_agents/                  # Domain module ✅
├── api_store/                  # Domain module ✅
├── auth/                       # Cross-cutting concern
├── bulletin_board/             # Domain module ✅
├── channel/                    # Domain module
├── conversation/               # Domain module ✅
├── conversational_ui/          # Domain module ✅
├── database/                   # Infrastructure ✅
├── dto/                        # Shared DTOs (⚠️ anti-pattern)
├── endpoints/                  # ❌ Breaks layered architecture
├── events/                     # Cross-cutting concern ✅
├── handlers/                   # ❌ Mixed handlers
├── l402/                       # Domain module ✅
├── ldk_recovery/               # Domain module ✅
├── llm/                        # Domain module ✅
├── message_queue/              # Infrastructure ✅
├── models/                     # ❌ Shared models (anti-pattern)
├── network/                    # Domain module ✅
├── node/                       # Domain module ✅
├── payment/                    # Domain module
├── peer/                       # Domain module
├── pi_uart_service/            # Domain module ✅
├── posts/                      # Domain module ✅
├── rathole/                    # Domain module ✅
├── repositories/               # ❌ Centralized repos (anti-pattern)
├── services/                   # ❌ Centralized services (anti-pattern)
├── social_network/             # Domain module ✅
├── terminal/                   # Domain module (partial)
├── transport/                  # Infrastructure ✅
├── updates/                    # Domain module
├── websocket/                  # Infrastructure ✅
├── config.rs
├── db_config.rs
├── error.rs
├── extractors.rs
├── lib.rs
├── main.rs                     # ⚠️ 1845 lines - God file
├── routes.rs
├── schema.rs
├── state.rs
├── utils.rs
└── validation/
```

**Problems:**
1. **Centralized `repositories/` folder (31 files)**
   - Violates domain isolation
   - Repositories should be within domain modules

2. **Centralized `services/` folder (28 files)**
   - Violates domain isolation
   - Services should be within domain modules

3. **Centralized `models/` folder (16 files)**
   - Shared models create coupling
   - Domain models should be internal

4. **`endpoints/` folder breaks architecture**
   - 15 endpoint files at root level
   - Should be within domain modules

5. **`handlers/` folder is mixed**
   - Contains multiple domain handlers
   - Unclear ownership

**Phased DDD Transition:**
```
Phase 1: Domain Grouping (Week 1-2)
packages/backend/src/
├── domains/
│   ├── conversation/
│   │   ├── mod.rs
│   │   ├── handlers.rs          # Move from endpoints/
│   │   ├── service.rs           # Move from services/
│   │   ├── repository.rs        # Move from repositories/
│   │   └── models.rs            # Move from models/
│   ├── payments/                # l402 + payment
│   ├── networking/              # rathole + network
│   └── social/                  # social_network + posts
├── shared/
│   ├── auth/                    # Cross-cutting
│   ├── database/                # Infrastructure
│   ├── events/                  # Cross-cutting
│   ├── transport/               # Infrastructure
│   └── websocket/               # Infrastructure
└── ...

Phase 2: Clean Migration (Week 3-4)
├── domains/
│   ├── ai_agents/               # Existing structure
│   ├── api_store/               # Existing structure
│   └── ... (other domains)
└── legacy/                      # Temporary for gradual migration
    ├── endpoints/               # To be distributed
    ├── services/                # To be distributed
    └── models/                  # To be distributed
```

**Updated Effort:** 3 weeks (phased approach)

---

### Issue 6: Frontend - Inconsistent Component Organization
**STATUS: UPDATED** - More practical reorganization.

**Current Frontend Structure:**
```
packages/node-ui/src/components/
├── agents/                      # Feature ✅
├── ai-agent/                    # ❌ Duplicate of agents?
├── auth/                        # Feature ✅
├── buddies/                     # Feature ✅
├── bulletin/                    # Feature
├── ConversationalUI/            # ❌ PascalCase folder
├── CopyableTooltip.tsx          # ❌ Component at root
├── dashboard/                   # Feature
├── ErrorBoundary.tsx            # ❌ Component at root
├── ErrorMessage.tsx             # ❌ Component at root
├── ip-pool/                     # Feature
├── l402/                        # Feature ✅
├── layout/                      # ❌ Single file, should merge
├── layouts/                     # ❌ Duplicate of layout?
├── ldk-recovery/                # Feature ✅
├── LoadingSpinner.tsx           # ❌ Component at root
├── messages/                    # Feature ✅
├── metrics/                     # Feature ✅
├── my-wallet/                   # Feature ✅
├── network/                     # Feature ✅
├── newsfeed/                    # Feature ✅
├── notifications/               # Feature ✅
├── PageHeader.tsx               # ❌ Component at root
├── providers/                   # Cross-cutting ✅
├── RollbackConfirmDialog.tsx        # ❌ Root level
├── RollbackHistoryTable.tsx         # ❌ Root level
├── RollbackNotificationBanner.tsx   # ❌ Root level
├── settings/                    # Feature ✅
├── social/                      # Feature ✅
├── StatusIndicator.tsx          # ❌ Component at root
├── terminal/                    # Feature ✅
├── ui/                          # Base UI components ✅
├── updates/                     # Feature ✅
└── verification/                # Feature ✅
```

**Refined Recommendation:**
```
packages/node-ui/src/components/
├── features/                    # Group feature components
│   ├── agents/                  # agents + ai-agent
│   ├── auth/                    # auth
│   ├── conversational-ui/       # ConversationalUI (renamed)
│   ├── dashboard/               # dashboard
│   ├── ip-pool/                 # ip-pool
│   ├── l402/                    # l402
│   ├── messages/                # messages
│   ├── network/                 # network
│   ├── newsfeed/                # newsfeed
│   ├── rollback/                # rollback components
│   ├── settings/                # settings
│   ├── social/                  # social + bulletin
│   ├── terminal/                # terminal
│   ├── wallet/                  # my-wallet
│   └── ... (other features)
├── layout/                      # Merge layout + layouts
│   ├── MainLayout.tsx
│   ├── TopMenu.tsx
│   └── PageLayout.tsx
├── shared/                      # Shared/reusable components
│   ├── CopyableTooltip.tsx
│   ├── ErrorBoundary.tsx
│   ├── ErrorMessage.tsx
│   ├── LoadingSpinner.tsx
│   ├── PageHeader.tsx
│   ├── StatusIndicator.tsx
│   └── RollbackNotificationBanner.tsx
├── providers/                   # Context providers
└── ui/                          # Base UI components (shadcn)
```

**Updated Effort:** 1 week (organizational changes)

---

### Issue 7: Frontend - API Files Scattered
**STATUS: UPDATED** - More systematic API organization.

**Current:**
```
packages/node-ui/src/lib/
├── activityApi.ts
├── aiAgentApi.ts
├── api/                        # ❌ Nested api folder
│   ├── conversational.ts
│   ├── ldk-recovery.ts
│   └── ... (7 files)
├── api.ts                      # ❌ God file (863 lines)
├── apiClient.ts
├── authApi.ts
├── buddiesApi.ts
├── friendAggregationApi.ts
├── ipPoolApi.ts
├── networkApi.ts
├── newsFeedApi.ts
├── ratholeApi.ts
├── socialApi.ts
├── terminalApi.ts
└── verificationApi.ts
```

**Refined Recommendation:**
```
lib/
├── api/                        # 🔧 ORGANIZED API LAYER
│   ├── index.ts                # Re-exports
│   ├── client.ts               # Base client
│   ├── types.ts                # Shared types
│   ├── activity.ts
│   ├── agents.ts               # aiAgentApi + aiAgent
│   ├── auth.ts
│   ├── buddies.ts
│   ├── conversational.ts
│   ├── ip-pool.ts              # ipPoolApi
│   ├── l402.ts
│   ├── ldk-recovery.ts
│   ├── messages.ts
│   ├── network.ts
│   ├── newsfeed.ts             # newsFeedApi
│   ├── node.ts
│   ├── rathole.ts
│   ├── social.ts
│   ├── terminal.ts
│   └── verification.ts
└── ... (other utilities)
```

**Updated Effort:** 3 days (API consolidation)

---

## 🟡 Medium Severity Issues (Updated)

### Issue 8: Hooks Flat Structure
**STATUS: UPDATED** - Practical grouping strategy.

**Current:** 60+ hooks in flat directory

**Recommendation:**
```
hooks/
├── index.ts                    # Re-exports
├── auth/
│   ├── useAuth.ts
│   └── useJwtToken.ts
├── agents/
│   ├── useAIAgent.ts
│   ├── useAgentByUserId.ts
│   └── useAgentCreation.ts
├── messaging/
│   ├── useMessages.ts
│   ├── useMessageDeliveryStatus.ts
│   └── useWebSocketMessage.ts
├── network/
│   ├── useNetwork.ts
│   ├── useNodeDetails.ts
│   └── useNodeStatus.ts
└── ... (grouped by domain)
```

**Updated Effort:** 2 days (categorization)

---

### Issue 9: Types Flat Structure
**STATUS: UPDATED** - Keep flat but add organization.

**Current:** 29 type files in flat directory

**Recommendation:** Keep flat structure but add:
```
types/
├── index.ts                    # Re-exports
├── activity.ts
├── agent.ts
├── ai-agent.ts
├── api-store.ts
├── ... (existing files)
└── README.md                   # Organization guide
```

**Updated Effort:** 1 day (add index + documentation)

---

### Issue 10: Missing Standard Files
**STATUS: UNCHANGED** - Still needed.

**Missing:**
```
packages/backend/
├── .env.example            # ❌ Missing
├── CHANGELOG.md            # ❌ Missing
└── CONTRIBUTING.md         # ❌ Missing

packages/node-ui/
├── .env.example            # ❌ Missing
└── CHANGELOG.md            # ❌ Missing
```

**Updated Effort:** 2 hours (create templates)

---

## 🟢 Low Severity Issues (Updated)

### Issue 11: Inconsistent Naming Conventions
**STATUS: UPDATED** - Specific fixes identified.

| Current | Problem | Recommended |
|---------|---------|-------------|
| `ConversationalUI/` | PascalCase folder | `conversational-ui/` |
| `my-wallet/` | Kebab-case ✅ | Keep |
| `ldk-recovery/` | Kebab-case ✅ | Keep |
| `ai-agent/` | Duplicate? | Merge with `agents/` |
| `newsFeedApi.ts` | camelCase | `newsfeed-api.ts` |

**Updated Effort:** 1 day (renaming + consolidation)

---

### Issue 12: Empty/Stub Modules
**STATUS: UPDATED** - Specific cleanup identified.

```
packages/backend/src/
├── newsfeed/
│   └── mod.rs              # Only mod.rs, minimal content
├── channel/
│   ├── handlers.rs
│   └── mod.rs              # Minimal content
```

**Recommendation:** Either implement or remove stub modules.

**Updated Effort:** 2 hours (assessment + cleanup)

---

## Updated Priority Actions

### 🔴 P0 - Critical (This Sprint - Week 1)
| Issue | Action | Effort | Impact |
|-------|--------|--------|--------|
| #1 | Move `migrations/` to `packages/backend/` | 1 hour | High |
| #2 | Move `tests/` to `packages/backend/` | 1 hour | High |
| #3 | Consolidate root-level docs | 4 hours | Medium |

### 🟠 P1 - High (This Month - Weeks 2-4)
| Issue | Action | Effort | Impact |
|-------|--------|--------|--------|
| #5 | DDD backend refactor (Phase 1) | 2 weeks | High |
| #6 | Frontend component organization | 1 week | Medium |
| #7 | API file consolidation | 3 days | Medium |
| #4 | Script consolidation | 2 hours | Low |

### 🟡 P2 - Medium (Next Month)
| Issue | Action | Effort | Impact |
|-------|--------|--------|--------|
| #8 | Hook grouping | 2 days | Low |
| #9 | Type organization | 1 day | Low |
| #5 | DDD backend refactor (Phase 2) | 1 week | High |

### 🟢 P3 - Low (Backlog)
| Issue | Action | Effort | Impact |
|-------|--------|--------|--------|
| #10 | Add standard files | 2 hours | Low |
| #11 | Naming convention fixes | 1 day | Low |
| #12 | Clean stub modules | 2 hours | Low |

---

## Implementation Dependencies

### Phase 1 Dependencies
- P0 tasks must complete before P1 starts
- Migration scripts need testing before execution
- Documentation consolidation requires team agreement

### Phase 2 Dependencies
- DDD refactor requires domain analysis
- Frontend reorganization needs design review
- API consolidation needs endpoint testing

### Risk Mitigation
- **Backup strategy**: Full git history preservation
- **Rollback plan**: Branch-based implementation
- **Testing**: Comprehensive test suite before/after
- **Communication**: Team alignment on changes

---

## Success Metrics

### Structural Health
- ✅ Zero misplaced files at root level
- ✅ Clear domain boundaries in backend
- ✅ Organized component structure in frontend
- ✅ Consolidated documentation

### Developer Experience
- ✅ Intuitive file locations
- ✅ Consistent naming conventions
- ✅ Clear architectural boundaries
- ✅ Comprehensive documentation

### Maintenance
- ✅ Easy to find relevant code
- ✅ Clear ownership of modules
- ✅ Reduced cognitive load
- ✅ Scalable structure

---

## Recommended Target Structure

### Root Level (Clean)
```
node/
├── .cursor/                    # IDE config
├── .github/                    # GitHub automation
├── config/                     # Brand configuration
├── docs/                       # 📚 Centralized docs
├── packages/                   # Service packages
├── scripts/                    # 🔧 Consolidated scripts
├── AGENTS.md                   # Coding conventions
├── CHANGELOG.md                # Release notes
├── CONTRIBUTING.md             # Contribution guide
├── Makefile                    # Build automation
├── package.json                # Root dependencies
├── README.md                   # Project overview
└── yarn.lock                   # Lockfile
```

### Backend Package (DDD)
```
packages/backend/
├── migrations/                 # ✅ Moved from root
├── src/
│   ├── domains/                # Business domains
│   │   ├── conversation/
│   │   ├── payments/
│   │   ├── networking/
│   │   └── social/
│   ├── shared/                 # Cross-cutting concerns
│   │   ├── auth/
│   │   ├── database/
│   │   ├── events/
│   │   └── transport/
│   ├── config.rs
│   ├── error.rs
│   ├── lib.rs
│   ├── main.rs
│   └── routes.rs
├── tests/                      # ✅ Moved from root
├── http-tests/                 # API test files
├── .env.example                # ✅ Added
├── Cargo.toml
└── README.md
```

### Frontend Package (Feature-Driven)
```
packages/node-ui/
├── src/
│   ├── components/
│   │   ├── features/           # Feature components
│   │   ├── layout/             # Layout components
│   │   ├── shared/             # Shared components
│   │   ├── providers/          # Context providers
│   │   └── ui/                 # Base UI components
│   ├── hooks/                  # Organized hooks
│   ├── lib/
│   │   └── api/                # Consolidated APIs
│   ├── pages/
│   ├── router/
│   ├── services/
│   ├── types/                  # Organized types
│   ├── App.tsx
│   └── main.tsx
├── .env.example                # ✅ Added
├── package.json
└── README.md
```

---

## Migration Strategy

### Week 1: Critical Fixes
1. **Day 1**: Move migrations/ and tests/ directories
2. **Day 2-3**: Consolidate root documentation
3. **Day 4-5**: Test all changes, update scripts

### Week 2-4: Architecture Refactor
1. **Week 2**: Backend DDD Phase 1 (domain grouping)
2. **Week 3**: Frontend component reorganization
3. **Week 4**: API consolidation and testing

### Week 5+: Polish & Documentation
1. Add missing standard files
2. Fix naming conventions
3. Clean up stub modules
4. Update documentation

---

## Conclusion

**Original Analysis**: Identified critical structural issues requiring fixes.

**V3 Assessment**: Realistic implementation plan with:
- **P0 Critical**: 6 hours immediate fixes
- **P1 High**: 3-4 weeks major restructuring
- **P2 Medium**: 3-4 days organizational improvements
- **P3 Low**: 5 hours final polish

**The structure will be significantly improved while maintaining current functionality and enabling future scalability.**

**Ready to start with the critical P0 fixes?** 🚀
