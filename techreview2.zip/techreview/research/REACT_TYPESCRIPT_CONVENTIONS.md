# React TypeScript Coding Conventions

This document outlines the coding standards and conventions for React TypeScript code in the node-ui package. These conventions ensure consistency, maintainability, performance, and best practices across the frontend codebase.

**⚠️ CRITICAL PERFORMANCE REQUIREMENTS:**
- **ALL** event handlers and callback functions MUST use `useCallback`
- **ALL** computed values, object/array creations, and CSS class computations MUST use `useMemo`
- **ALL** dependency arrays must be complete and accurate
- Components receiving function props should use `React.memo` when appropriate

## Table of Contents

- [Project Structure](#project-structure)
- [Component Patterns](#component-patterns)
- [TypeScript Guidelines](#typescript-guidelines)
- [State Management](#state-management)
- [API Client Usage](#api-client-usage)
- [Hooks](#hooks)
- [Performance Optimization](#performance-optimization)
- [Styling](#styling)
- [File Organization](#file-organization)
- [Naming Conventions](#naming-conventions)
- [Testing](#testing)
- [Best Practices](#best-practices)

## Project Structure

### Directory Layout

```
packages/node-ui/src/
├── components/          # Reusable UI components
│   ├── ui/             # Base UI components (shadcn/ui)
│   ├── auth/           # Authentication components
│   ├── dashboard/      # Dashboard-specific components
│   ├── messages/       # Messaging components
│   └── ...
├── pages/              # Route-based page components
├── hooks/              # Custom React hooks
├── contexts/           # React contexts/providers
├── types/              # TypeScript type definitions
├── lib/                # Utility functions and configurations
├── utils/              # Helper functions
├── services/           # API clients and external services
├── router/             # Routing configuration
├── mock/               # Mock data for development
└── test/               # Test utilities
```

### Component Organization

Organize components by feature/domain:

```
components/
├── auth/
│   ├── LoginPage.tsx
│   ├── AuthGuard.tsx
│   ├── index.ts          # Barrel exports
│   └── __tests__/
│       └── AuthGuard.test.tsx
├── messages/
│   ├── ChatInput.tsx
│   ├── MessageThread.tsx
│   └── chat-components/
│       ├── MessageBubble.tsx
│       └── TypingIndicator.tsx
```

## Component Patterns

### 1. **Functional Components with Hooks**

```tsx
// ✅ Preferred: Functional component with hooks
interface UserProfileProps {
  userId: string;
  showEditButton?: boolean;
}

export const UserProfile: React.FC<UserProfileProps> = ({
  userId,
  showEditButton = false
}) => {
  const { data: user, isLoading, error } = useUserDetails(userId);
  const [isEditing, setIsEditing] = useState(false);

  if (isLoading) return <LoadingSpinner />;
  if (error) return <ErrorMessage error={error} />;
  if (!user) return <NotFoundMessage />;

  return (
    <div className="user-profile">
      {/* Component JSX */}
    </div>
  );
};
```

### 2. **Component Props Interface**

Always define props interfaces:

```tsx
// ✅ Good: Explicit props interface
interface PostCardProps {
  post: Post;
  onLike?: (postId: string) => void;
  onShare?: (postId: string) => void;
  showActions?: boolean;
  variant?: 'default' | 'compact' | 'featured';
}

export const PostCard: React.FC<PostCardProps> = ({
  post,
  onLike,
  onShare,
  showActions = true,
  variant = 'default'
}) => {
  // Component implementation
};
```

### 3. **Default Props**

Use default parameters instead of `defaultProps`:

```tsx
// ✅ Good: Default parameters
interface ButtonProps {
  variant?: 'primary' | 'secondary' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  onClick?: () => void;
  children: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  size = 'md',
  disabled = false,
  onClick,
  children
}) => {
  // Component implementation
};

// ❌ Bad: defaultProps (deprecated in modern React)
Button.defaultProps = {
  variant: 'primary',
  size: 'md'
};
```

### 4. **Children Types**

Be specific about children types when needed:

```tsx
// ✅ Good: Specific children types
interface CardProps {
  title: string;
  children: React.ReactNode;  // Accepts any valid React children
}

// Or more specific:
interface ListProps {
  children: React.ReactElement<ListItemProps>[];  // Only ListItem components
}

// ✅ Good: Discriminated union for conditional rendering
interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}
```

### 5. **Event Handlers**

Use proper event handler naming and typing:

```tsx
// ✅ Good: Proper event handler types
interface FormProps {
  onSubmit: (data: FormData) => void | Promise<void>;
  onCancel?: () => void;
}

export const LoginForm: React.FC<FormProps> = ({ onSubmit, onCancel }) => {
  const handleSubmit = useCallback(async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const formData = new FormData(event.currentTarget);
    const data = {
      email: formData.get('email') as string,
      password: formData.get('password') as string,
    };

    await onSubmit(data);
  }, [onSubmit]);

  return (
    <form onSubmit={handleSubmit}>
      {/* Form fields */}
      <button type="submit">Login</button>
      {onCancel && <button type="button" onClick={onCancel}>Cancel</button>}
    </form>
  );
};
```

## TypeScript Guidelines

### 1. **Strict Type Checking**

Enable strict mode in `tsconfig.json`:

```json
{
  "compilerOptions": {
    "strict": true,
    "noImplicitAny": true,
    "strictNullChecks": true,
    "strictFunctionTypes": true,
    "noImplicitReturns": true,
    "noFallthroughCasesInSwitch": true,
    "noUncheckedIndexedAccess": true
  }
}
```

### 2. **Type Definitions**

Create dedicated type files:

```typescript
// types/auth.ts
export interface User {
  id: string;
  email: string;
  username: string;
  role: UserRole;
  createdAt: Date;
  updatedAt: Date;
}

export interface AuthState {
  user: User | null;
  isLoading: boolean;
  error: string | null;
}

export type UserRole = 'admin' | 'moderator' | 'user';

// types/api.ts
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}
```

### 3. **Generic Types**

Use generics for reusable components:

```tsx
// ✅ Good: Generic list component
interface ListProps<T> {
  items: T[];
  renderItem: (item: T, index: number) => React.ReactNode;
  keyExtractor: (item: T) => string | number;
  emptyMessage?: string;
  loading?: boolean;
}

export function List<T>({
  items,
  renderItem,
  keyExtractor,
  emptyMessage = "No items found",
  loading = false
}: ListProps<T>) {
  if (loading) return <LoadingSpinner />;

  if (items.length === 0) {
    return <p className="text-muted-foreground">{emptyMessage}</p>;
  }

  return (
    <ul className="space-y-2">
      {items.map((item, index) => (
        <li key={keyExtractor(item)}>
          {renderItem(item, index)}
        </li>
      ))}
    </ul>
  );
}

// Usage
<List
  items={posts}
  renderItem={(post) => <PostCard post={post} />}
  keyExtractor={(post) => post.id}
/>
```

### 4. **Utility Types**

Create reusable utility types:

```typescript
// types/utils.ts
export type Optional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;

export type RequiredFields<T, K extends keyof T> = T & Required<Pick<T, K>>;

export type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

// Usage
type CreateUserRequest = Optional<User, 'id' | 'createdAt' | 'updatedAt'>;
type UpdateUserRequest = DeepPartial<User>;
```

### 5. **Discriminated Unions**

Use discriminated unions for type safety:

```typescript
// ✅ Good: Discriminated union for notifications
export type Notification =
  | { type: 'success'; message: string }
  | { type: 'error'; message: string; code?: string }
  | { type: 'warning'; message: string; action?: NotificationAction }
  | { type: 'info'; message: string; duration?: number };

interface NotificationAction {
  label: string;
  onClick: () => void;
}

// Type-safe component
export const NotificationToast: React.FC<{ notification: Notification }> = ({
  notification
}) => {
  switch (notification.type) {
    case 'success':
      return <SuccessToast message={notification.message} />;

    case 'error':
      return <ErrorToast
        message={notification.message}
        code={notification.code}
      />;

    case 'warning':
      return <WarningToast
        message={notification.message}
        action={notification.action}
      />;

    case 'info':
      return <InfoToast
        message={notification.message}
        duration={notification.duration}
      />;

    default:
      return assertNever(notification);
  }
};

// Type guard function
function assertNever(value: never): never {
  throw new Error(`Unexpected value: ${JSON.stringify(value)}`);
}
```

## API Client Usage

### **REQUIRED: Use Centralized API Client**

**CRITICAL RULE:** ALWAYS use the centralized `apiClient` singleton from `@/lib/apiClient`. NEVER create ad-hoc `fetch()` calls or custom API clients.

```tsx
// ✅ CORRECT - Use shared apiClient
import { apiClient } from '@/lib/apiClient';
import { useQuery, useMutation } from '@tanstack/react-query';

// In custom hooks
export function usePosts() {
  return useQuery({
    queryKey: ['posts'],
    queryFn: () => apiClient.get<Post[]>('/v2/posts'),
    staleTime: 5 * 60 * 1000,
  });
}

export function useCreatePost() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: CreatePostRequest) => 
      apiClient.post<Post>('/v2/posts', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['posts'] });
    },
  });
}

// ❌ WRONG - Manual fetch() call
async function fetchPosts(token: string) {
  const response = await fetch(`${API_BASE_URL}/api/v2/posts`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  return response.json();
}
```

**Benefits of using apiClient:**
- Automatic JWT authentication and token refresh on 401
- L402 payment error detection and handling (402 status)
- Consistent error handling with `ApiError` class
- Type-safe generic methods with response unwrapping
- Centralized auth/security logic (no duplicate implementations)

**Error Handling with ApiError:**

```tsx
import { ApiError } from '@/lib/apiClient';

try {
  const result = await apiClient.post<Resource>('/v2/resource', data);
} catch (error) {
  if (error instanceof ApiError) {
    if (error.status === 402) {
      // Handle L402 payment required
      showPaymentDialog(error.paymentRequest);
    } else if (error.status === 401) {
      // Handle authentication error
      redirectToLogin();
    } else {
      // Handle other API errors
      showError(error.message);
    }
  } else {
    // Handle unexpected errors
    showError('An unexpected error occurred');
  }
}
```

## State Management

### 1. **Local State**

Use `useState` for component-specific state:

```tsx
// ✅ Good: Local state with proper typing
export const SearchInput: React.FC = () => {
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState<SearchResult[]>([]);

  const handleSearch = useCallback(async (searchQuery: string) => {
    setIsLoading(true);
    try {
      const searchResults = await searchAPI(searchQuery);
      setResults(searchResults);
    } catch (error) {
      console.error('Search failed:', error);
      setResults([]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Debounced search
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (query.trim()) {
        handleSearch(query);
      } else {
        setResults([]);
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [query, handleSearch]);

  return (
    <div>
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search..."
      />
      {isLoading && <LoadingSpinner />}
      <SearchResults results={results} />
    </div>
  );
};
```

### 2. **Client State with Zustand**

Use Zustand for client-side global state (user preferences, UI state, etc.):

```typescript
// stores/auth.ts
interface AuthState {
  user: User | null;
  isLoading: boolean;
  error: string | null;

  // Actions
  login: (credentials: LoginCredentials) => Promise<void>;
  logout: () => void;
  refreshUser: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  isLoading: false,
  error: null,

  login: async (credentials) => {
    set({ isLoading: true, error: null });

    try {
      const response = await authAPI.login(credentials);
      const user = await authAPI.getCurrentUser();

      set({
        user,
        isLoading: false,
        error: null
      });

      // Store token
      localStorage.setItem('auth_token', response.token);
    } catch (error) {
      set({
        user: null,
        isLoading: false,
        error: error instanceof Error ? error.message : 'Login failed'
      });
      throw error;
    }
  },

  logout: () => {
    localStorage.removeItem('auth_token');
    set({ user: null, error: null });
  },

  refreshUser: async () => {
    try {
      const user = await authAPI.getCurrentUser();
      set({ user, error: null });
    } catch (error) {
      set({
        user: null,
        error: error instanceof Error ? error.message : 'Failed to refresh user'
      });
    }
  }
}));

// Usage in components
export const UserProfile: React.FC = () => {
  const { user, isLoading, login, logout } = useAuthStore();

  if (isLoading) return <LoadingSpinner />;
  if (!user) return <LoginForm onSubmit={login} />;

  return (
    <div>
      <h1>Welcome, {user.username}!</h1>
      <button onClick={logout}>Logout</button>
    </div>
  );
};
```

### 3. **Server State with TanStack Query (React Query)**

Use React Query for all server state (API data, caching, synchronization):

```typescript
// hooks/usePosts.ts
export const usePosts = (filters?: PostFilters) => {
  return useQuery({
    queryKey: ['posts', filters],
    queryFn: () => postsAPI.getPosts(filters),
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000,   // 10 minutes (formerly cacheTime)
    retry: (failureCount, error) => {
      // Don't retry on 4xx errors
      if (error instanceof ApiError && error.status >= 400 && error.status < 500) {
        return false;
      }
      return failureCount < 3;
    }
  });
};

export const useCreatePost = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: postsAPI.createPost,
    onSuccess: (newPost) => {
      // Invalidate and refetch posts
      queryClient.invalidateQueries({ queryKey: ['posts'] });

      // Optimistically update the cache
      queryClient.setQueryData(['posts'], (oldPosts: Post[] | undefined) => {
        return oldPosts ? [newPost, ...oldPosts] : [newPost];
      });
    },
    onError: (error) => {
      // Handle error (show toast, etc.)
      console.error('Failed to create post:', error);
    }
  });
};

// Usage
export const PostList: React.FC = () => {
  const { data: posts, isLoading, error } = usePosts();
  const createPost = useCreatePost();

  const handleCreatePost = async (postData: CreatePostData) => {
    try {
      await createPost.mutateAsync(postData);
    } catch (error) {
      // Error already handled in mutation
    }
  };

  if (isLoading) return <LoadingSpinner />;
  if (error) return <ErrorMessage error={error} />;

  return (
    <div>
      <PostForm onSubmit={handleCreatePost} />
      {posts?.map(post => (
        <PostCard key={post.id} post={post} />
      ))}
    </div>
  );
};
```

## Hooks

### 1. **Custom Hook Patterns**

```typescript
// ✅ Good: Custom hook with proper naming
export const useAuth = () => {
  const { user, login, logout, isLoading } = useAuthStore();

  const isAuthenticated = Boolean(user);
  const isAdmin = user?.role === 'admin';

  return {
    user,
    isAuthenticated,
    isAdmin,
    isLoading,
    login,
    logout
  };
};

// ✅ Good: Data fetching hook
export const useUserProfile = (userId: string | undefined) => {
  return useQuery({
    queryKey: ['user', userId],
    queryFn: () => userAPI.getProfile(userId!),
    enabled: Boolean(userId), // Only run when userId is available
    staleTime: 5 * 60 * 1000,
  });
};

// ✅ Good: Form handling hook
export const useLoginForm = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const login = useAuthStore(state => state.login);

  const handleChange = useCallback((field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  }, [errors]);

  const handleSubmit = useCallback(async () => {
    setIsSubmitting(true);
    setErrors({});

    try {
      await login(formData);
    } catch (error) {
      if (error instanceof ValidationError) {
        setErrors(error.errors);
      } else {
        setErrors({ general: 'Login failed. Please try again.' });
      }
    } finally {
      setIsSubmitting(false);
    }
  }, [formData, login]);

  return {
    formData,
    errors,
    isSubmitting,
    handleChange,
    handleSubmit
  };
};
```

### 2. **Hook Dependencies**

Always include all dependencies in `useCallback` and `useEffect`:

```tsx
// ✅ Good: Proper dependencies
const fetchPosts = useCallback(async () => {
  if (!userId) return;
  const posts = await postsAPI.getUserPosts(userId);
  setPosts(posts);
}, [userId]); // Include all variables used inside

useEffect(() => {
  fetchPosts();
}, [fetchPosts]); // Include the callback

// ❌ Bad: Missing dependencies
const fetchPosts = useCallback(async () => {
  const posts = await postsAPI.getUserPosts(userId); // userId used but not in deps
  setPosts(posts);
}, []); // Missing userId dependency
```

### 3. **Hook Naming Conventions**

```typescript
// ✅ Good: Descriptive hook names
export const useAuth = () => { /* ... */ };
export const usePosts = (filters?: PostFilters) => { /* ... */ };
export const useCreatePost = () => { /* ... */ };
export const usePostActions = (postId: string) => { /* ... */ };
export const useDebounce = (value: string, delay: number) => { /* ... */ };

// ❌ Bad: Unclear names
export const useData = () => { /* ... */ };
export const useStuff = () => { /* ... */ };
export const useHook = () => { /* ... */ };
```

## Styling

### 1. **TailwindCSS Conventions**

```tsx
// ✅ Good: Semantic class names with Tailwind
export const Button: React.FC<ButtonProps> = ({ variant, size, disabled, children }) => {
  const baseClasses = "inline-flex items-center justify-center rounded-md font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50";

  const variantClasses = {
    primary: "bg-primary text-primary-foreground hover:bg-primary/90",
    secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
    danger: "bg-destructive text-destructive-foreground hover:bg-destructive/90"
  };

  const sizeClasses = {
    sm: "h-8 px-3 text-sm",
    md: "h-10 px-4 text-base",
    lg: "h-12 px-6 text-lg"
  };

  return (
    <button
      className={cn(
        baseClasses,
        variantClasses[variant],
        sizeClasses[size],
        disabled && "opacity-50 cursor-not-allowed"
      )}
      disabled={disabled}
    >
      {children}
    </button>
  );
};
```

### 2. **CSS Modules (if needed)**

```tsx
// styles/Button.module.css
.button {
  /* base styles */
}

.primary {
  /* primary variant */
}

.secondary {
  /* secondary variant */
}

// Button.tsx
import styles from './Button.module.css';
import { cn } from '@/lib/utils';

export const Button: React.FC<ButtonProps> = ({ variant, children }) => {
  return (
    <button className={cn(styles.button, styles[variant])}>
      {children}
    </button>
  );
};
```

### 3. **Conditional Styling**

```tsx
// ✅ Good: Conditional classes with clsx or cn
import { cn } from '@/lib/utils';

export const Alert: React.FC<AlertProps> = ({ variant, children }) => {
  return (
    <div className={cn(
      "rounded-lg p-4 text-sm",
      {
        "bg-green-50 text-green-800 border border-green-200": variant === 'success',
        "bg-red-50 text-red-800 border border-red-200": variant === 'error',
        "bg-yellow-50 text-yellow-800 border border-yellow-200": variant === 'warning'
      }
    )}>
      {children}
    </div>
  );
};

// ✅ Good: Dynamic classes
export const Card: React.FC<CardProps> = ({ shadow = 'sm', padding = 'md' }) => {
  const shadowClasses = {
    none: '',
    sm: 'shadow-sm',
    md: 'shadow-md',
    lg: 'shadow-lg'
  };

  const paddingClasses = {
    none: '',
    sm: 'p-2',
    md: 'p-4',
    lg: 'p-6'
  };

  return (
    <div className={cn(
      "bg-white rounded-lg border",
      shadowClasses[shadow],
      paddingClasses[padding]
    )}>
      {/* content */}
    </div>
  );
};
```

## File Organization

### 1. **Component Files**

```tsx
// ✅ Good: Single responsibility component
// components/auth/LoginForm.tsx
export const LoginForm: React.FC<LoginFormProps> = ({ onSubmit }) => {
  // Component logic
};

// ✅ Good: Related components in subfolder
// components/messages/
// ├── MessageList.tsx
// ├── MessageItem.tsx
// ├── MessageInput.tsx
// └── index.ts (barrel export)
```

### 2. **Barrel Exports**

```typescript
// components/ui/index.ts
export { Button } from './Button';
export { Input } from './Input';
export { Card, CardHeader, CardContent } from './Card';

// Usage
import { Button, Input, Card } from '@/components/ui';
```

### 3. **File Naming**

```typescript
// Components
LoginForm.tsx          // PascalCase for component names
UserProfile.tsx

// Hooks
useAuth.ts            // camelCase with 'use' prefix
usePosts.ts

// Types
auth.ts               // lowercase, domain-based
user.ts
api.ts

// Utils
formatDate.ts         // camelCase, descriptive
validateEmail.ts

// Tests
LoginForm.test.tsx    // ComponentName.test.tsx
useAuth.test.ts       // hookName.test.ts
```

## Naming Conventions

### 1. **Components**

```tsx
// ✅ Good: PascalCase, descriptive names
export const UserProfile = () => { /* ... */ };
export const PostCard = () => { /* ... */ };
export const LoginForm = () => { /* ... */ };

// ❌ Bad: Unclear or incorrect casing
export const userProfile = () => { /* ... */ };  // camelCase
export const Postcard = () => { /* ... */ };     // Typo
export const LgnFrm = () => { /* ... */ };       // Abbreviation
```

### 2. **Hooks**

```typescript
// ✅ Good: use + PascalCase for main word
export const useAuth = () => { /* ... */ };
export const usePosts = () => { /* ... */ };
export const useUserProfile = () => { /* ... */ };

// ❌ Bad: Incorrect prefix or casing
export const auth = () => { /* ... */ };         // Missing 'use'
export const UsePosts = () => { /* ... */ };     // Incorrect casing
```

### 3. **Types and Interfaces**

```typescript
// ✅ Good: PascalCase for type names
interface UserProfileProps {
  userId: string;
  showEditButton?: boolean;
}

type UserRole = 'admin' | 'user' | 'moderator';

interface ApiResponse<T> {
  success: boolean;
  data: T;
  error?: string;
}

// ✅ Good: Descriptive type names
type CreatePostRequest = Omit<Post, 'id' | 'createdAt'>;
type UpdatePostRequest = Partial<Post>;
```

### 4. **Variables and Functions**

```tsx
// ✅ Good: camelCase for variables and functions
const userId = '123';
const isLoading = false;
const handleSubmit = () => { /* ... */ };

// ✅ Good: Descriptive names
const filteredPosts = posts.filter(/* ... */);
const handleUserLogout = () => { /* ... */ };

// ❌ Bad: Unclear names
const x = 'user id';          // Too generic
const doStuff = () => { /* ... */ };  // Unclear purpose
const temp = calculateTotal();       // 'temp' is meaningless
```

### 5. **Constants**

```typescript
// ✅ Good: UPPER_CASE_WITH_UNDERSCORES
const MAX_RETRY_ATTEMPTS = 3;
const API_TIMEOUT_MS = 5000;
const DEFAULT_PAGE_SIZE = 20;

// ❌ Bad: camelCase for constants
const maxRetryAttempts = 3;    // Should be UPPER_CASE
const apiTimeout = 5000;       // Missing underscores
```

## Testing

### 1. **Test File Organization**

```typescript
// ✅ Good: Test files next to implementation
components/
├── Button.tsx
├── Button.test.tsx
└── __tests__/
    └── Button.integration.test.tsx

hooks/
├── useAuth.ts
└── __tests__/
    └── useAuth.test.ts
```

### 2. **Test Naming**

```typescript
// ✅ Good: Descriptive test names
describe('Button', () => {
  it('renders with default props', () => { /* ... */ });
  it('calls onClick when clicked', () => { /* ... */ });
  it('shows loading state when disabled', () => { /* ... */ });
  it('applies correct variant classes', () => { /* ... */ });
});

// ✅ Good: Test structure
describe('useAuth hook', () => {
  describe('login', () => {
    it('sets user on successful login', async () => { /* ... */ });
    it('sets error on failed login', async () => { /* ... */ });
  });

  describe('logout', () => {
    it('clears user data', () => { /* ... */ });
    it('removes auth token from storage', () => { /* ... */ });
  });
});
```

### 3. **Mocking**

```typescript
// ✅ Good: Mock external dependencies
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

// Mock API calls
jest.mock('@/services/api', () => ({
  getPosts: jest.fn(),
  createPost: jest.fn(),
}));

// Test component with providers
const renderWithProviders = (component: React.ReactElement) => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: { retry: false },
      mutations: { retry: false }
    }
  });

  return render(
    <QueryClientProvider client={queryClient}>
      {component}
    </QueryClientProvider>
  );
};

describe('PostList', () => {
  it('shows loading state initially', () => {
    // Arrange
    const mockApi = require('@/services/api');
    mockApi.getPosts.mockResolvedValue([]);

    // Act
    renderWithProviders(<PostList />);

    // Assert
    expect(screen.getByText('Loading...')).toBeInTheDocument();
  });
});
```

## Performance Optimization

### 1. **useCallback - REQUIRED for All Event Handlers**

**Rule:** ALL event handlers and callback functions MUST be wrapped in `useCallback` to prevent unnecessary re-renders.

```tsx
// ❌ BAD - Creates new function on every render
export const Button: React.FC<ButtonProps> = ({ onClick, children }) => {
  const handleClick = () => {
    onClick();
  };

  return <button onClick={handleClick}>{children}</button>;
};

// ✅ GOOD - Memoized function reference
export const Button: React.FC<ButtonProps> = ({ onClick, children }) => {
  const handleClick = useCallback(() => {
    onClick();
  }, [onClick]);

  return <button onClick={handleClick}>{children}</button>;
};

// ✅ GOOD - Event handlers with parameters
export const PostCard: React.FC<PostCardProps> = ({ post, onLike, onShare }) => {
  const handleLike = useCallback(() => {
    onLike(post.id);
  }, [onLike, post.id]);

  const handleShare = useCallback(() => {
    onShare(post, 'copy');
  }, [onShare, post]);

  return (
    <div>
      <button onClick={handleLike}>Like</button>
      <button onClick={handleShare}>Share</button>
    </div>
  );
};
```

**Enforcement Rules:**
- All event handlers (`onClick`, `onChange`, `onSubmit`, etc.) MUST use `useCallback`
- All function props passed to child components MUST use `useCallback`
- Functions used in `useEffect` dependencies SHOULD use `useCallback`
- Include ALL dependencies in the dependency array

### 2. **useMemo - REQUIRED for Computed Values**

**Rule:** ALL computed values, object/array creations, and CSS class computations MUST use `useMemo`.

```tsx
// ❌ BAD - Recalculates on every render
export const PostList: React.FC<PostListProps> = ({ posts, filter, sortBy }) => {
  const filteredPosts = posts.filter(post => 
    post.title.toLowerCase().includes(filter.toLowerCase())
  );
  
  const sortedPosts = [...filteredPosts].sort((a, b) => 
    sortBy === 'name' ? a.name.localeCompare(b.name) : a.date - b.date
  );

  const className = `list ${isActive ? 'active' : ''} ${variant}`;

  return <div className={className}>{/* ... */}</div>;
};

// ✅ GOOD - Memoized computations
export const PostList: React.FC<PostListProps> = ({ posts, filter, sortBy }) => {
  const filteredPosts = useMemo(() => 
    posts.filter(post => 
      post.title.toLowerCase().includes(filter.toLowerCase())
    ), [posts, filter]
  );

  const sortedPosts = useMemo(() => 
    [...filteredPosts].sort((a, b) => 
      sortBy === 'name' ? a.name.localeCompare(b.name) : a.date - b.date
    ), [filteredPosts, sortBy]
  );

  const className = useMemo(() => 
    cn('list', isActive && 'active', variant), 
    [isActive, variant]
  );

  return <div className={className}>{/* ... */}</div>;
};
```

**Enforcement Rules:**
- String concatenations MUST use `useMemo`
- Array operations (filter, map, reduce, sort) MUST use `useMemo`
- Object creation MUST use `useMemo`
- Mathematical calculations MUST use `useMemo`
- CSS class name computations MUST use `useMemo`

### 3. **React.memo for Component Optimization**

Use `React.memo` for components that receive stable props but may re-render frequently.

```tsx
// ✅ GOOD - Memoized component with stable props
interface PostCardProps {
  post: Post;
  onLike: (postId: string) => void;
  onShare: (post: Post, method: string) => void;
}

export const PostCard: React.FC<PostCardProps> = React.memo(({
  post,
  onLike,
  onShare,
}) => {
  const handleLike = useCallback(() => {
    onLike(post.id);
  }, [onLike, post.id]);

  const handleShare = useCallback(() => {
    onShare(post, 'copy');
  }, [onShare, post]);

  return (
    <div>
      <h3>{post.title}</h3>
      <button onClick={handleLike}>Like</button>
      <button onClick={handleShare}>Share</button>
    </div>
  );
});

PostCard.displayName = 'PostCard';
```

**When to use React.memo:**
- Component receives stable props but parent re-renders frequently
- Component is expensive to render
- Component is used in lists with many items
- Props are primitive types or memoized objects/functions

**When NOT to use React.memo:**
- Component props change on every render
- Component is simple and cheap to render
- Memoization overhead exceeds render cost

### 4. **Complete Dependency Arrays**

**Rule:** ALL hooks must have complete and accurate dependency arrays.

```tsx
// ❌ BAD - Missing dependencies
const handleClick = useCallback(() => {
  doSomething(prop1, state);
}, []); // Missing prop1, state

useEffect(() => {
  fetchData(userId);
}, []); // Missing userId

// ✅ GOOD - Complete dependencies
const handleClick = useCallback(() => {
  doSomething(prop1, state);
}, [prop1, state]);

useEffect(() => {
  fetchData(userId);
}, [userId]);
```

### 5. **Avoid Inline Object/Array Creation in JSX**

```tsx
// ❌ BAD - Creates new objects/arrays on every render
<Component 
  style={{ color: 'red', fontSize: 16 }}
  data={[item1, item2, item3]}
  config={{ enabled: true, timeout: 5000 }}
/>

// ✅ GOOD - Memoize objects/arrays
const style = useMemo(() => ({ color: 'red', fontSize: 16 }), []);
const data = useMemo(() => [item1, item2, item3], [item1, item2, item3]);
const config = useMemo(() => ({ enabled: true, timeout: 5000 }), []);

<Component style={style} data={data} config={config} />
```

### 6. **List Virtualization for Large Lists**

For lists with 100+ items, use virtualization to improve performance.

```tsx
// ✅ GOOD - Virtualized list for large datasets
import { useVirtualizer } from '@tanstack/react-virtual';

export const VirtualizedPostList: React.FC<{ posts: Post[] }> = ({ posts }) => {
  const parentRef = useRef<HTMLDivElement>(null);

  const rowVirtualizer = useVirtualizer({
    count: posts.length,
    getScrollElement: () => parentRef.current,
    estimateSize: () => 200, // Estimated item height
    overscan: 5, // Render extra items for smoother scrolling
  });

  const virtualItems = useMemo(
    () => rowVirtualizer.getVirtualItems(),
    [rowVirtualizer]
  );

  return (
    <div ref={parentRef} className="overflow-auto h-[400px]">
      <div
        style={{
          height: `${rowVirtualizer.getTotalSize()}px`,
          width: '100%',
          position: 'relative',
        }}
      >
        {virtualItems.map((virtualItem) => (
          <div
            key={virtualItem.key}
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: '100%',
              height: `${virtualItem.size}px`,
              transform: `translateY(${virtualItem.start}px)`,
            }}
          >
            <PostCard post={posts[virtualItem.index]} />
          </div>
        ))}
      </div>
    </div>
  );
};
```

### 7. **Code Splitting with Lazy Loading**

```tsx
// ✅ GOOD - Lazy load routes for better initial load time
import React, { Suspense, lazy } from 'react';

const Dashboard = lazy(() => import('@/pages/Dashboard'));
const Settings = lazy(() => import('@/pages/Settings'));

export const AppRoutes: React.FC = () => {
  return (
    <Suspense fallback={<LoadingSpinner />}>
      <Routes>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/settings" element={<Settings />} />
      </Routes>
    </Suspense>
  );
};
```

**When to use lazy loading:**
- Route-based components (pages)
- Heavy components not immediately visible
- Components with large dependencies
- Modal/dialog components loaded conditionally

## Best Practices

### 1. **Performance Checklist**

Before submitting code, ensure:
- ✅ All event handlers use `useCallback`
- ✅ All computed values use `useMemo`
- ✅ All dependency arrays are complete
- ✅ No inline object/array creation in JSX
- ✅ Components with stable props use `React.memo` when appropriate
- ✅ Large lists (100+ items) use virtualization
- ✅ Routes use lazy loading
- ✅ API calls use centralized `apiClient`

### 2. **Component Composition**

```tsx
// ✅ Good: Composition over inheritance
export const PostPage: React.FC = () => {
  return (
    <PageLayout>
      <PostHeader />
      <PostContent />
      <PostActions />
      <CommentsSection />
    </PageLayout>
  );
};

// ✅ Good: Render props pattern
interface DataFetcherProps<T> {
  url: string;
  children: (data: { data: T | null; loading: boolean; error: Error | null }) => React.ReactNode;
}

export const DataFetcher = <T,>({ url, children }: DataFetcherProps<T>) => {
  const { data, isLoading, error } = useQuery({
    queryKey: [url],
    queryFn: () => fetch(url).then(res => res.json())
  });

  return <>{children({ data, loading: isLoading, error })}</>;
};

// Usage
<DataFetcher url="/api/posts">
  {({ data, loading, error }) => {
    if (loading) return <LoadingSpinner />;
    if (error) return <ErrorMessage error={error} />;
    return <PostList posts={data || []} />;
  }}
</DataFetcher>
```

### 3. **Error Boundaries**

```tsx
// ✅ Good: Error boundary for graceful error handling
class ErrorBoundary extends React.Component<
  { children: React.ReactNode; fallback?: React.ComponentType<{ error: Error }> },
  { hasError: boolean; error: Error | null }
> {
  constructor(props: { children: React.ReactNode; fallback?: React.ComponentType<{ error: Error }> }) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    // Log error to monitoring service
    console.error('Error caught by boundary:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      const Fallback = this.props.fallback || DefaultErrorFallback;
      return <Fallback error={this.state.error!} />;
    }

    return this.props.children;
  }
}

// Usage
<ErrorBoundary fallback={CustomErrorPage}>
  <App />
</ErrorBoundary>
```

### 4. **Accessibility**

```tsx
// ✅ Good: Accessible components
export const AccessibleButton: React.FC<ButtonProps> = ({
  onClick,
  disabled,
  children,
  ariaLabel,
  ...props
}) => {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      aria-label={ariaLabel}
      aria-disabled={disabled}
      role="button"
      tabIndex={disabled ? -1 : 0}
      {...props}
    >
      {children}
    </button>
  );
};

// ✅ Good: Semantic HTML
export const ArticleCard: React.FC<ArticleProps> = ({ article }) => {
  return (
    <article>
      <header>
        <h2>{article.title}</h2>
        <time dateTime={article.publishedAt.toISOString()}>
          {formatDate(article.publishedAt)}
        </time>
      </header>

      <section>
        <p>{article.excerpt}</p>
      </section>

      <footer>
        <address>By {article.author.name}</address>
        <a href={`/articles/${article.id}`}>Read more</a>
      </footer>
    </article>
  );
};
```

### 5. **Internationalization**

```tsx
// ✅ Good: Prepare for i18n
import { useTranslation } from 'react-i18next';

export const LoginForm: React.FC = () => {
  const { t } = useTranslation();

  return (
    <form>
      <label htmlFor="email">
        {t('auth.email.label')} {/* "Email Address" */}
      </label>
      <input
        id="email"
        type="email"
        placeholder={t('auth.email.placeholder')} {/* "Enter your email" */}
        required
      />

      <button type="submit">
        {t('auth.login.button')} {/* "Sign In" */}
      </button>
    </form>
  );
};
```

### 6. **Security Best Practices**

```tsx
// ✅ Good: Sanitize user input
import DOMPurify from 'isomorphic-dompurify';

export const SafeHtml: React.FC<{ html: string }> = ({ html }) => {
  const sanitizedHtml = useMemo(() => DOMPurify.sanitize(html), [html]);

  return <div dangerouslySetInnerHTML={{ __html: sanitizedHtml }} />;
};

// ✅ Good: Content Security Policy
// In index.html or via meta tags
<meta
  http-equiv="Content-Security-Policy"
  content="default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline';"
/>

// ✅ Good: Validate props
interface UserInputProps {
  userId: string;
  content: string;
}

export const UserContent: React.FC<UserInputProps> = ({ userId, content }) => {
  // Validate userId format
  if (!/^[a-zA-Z0-9_-]{1,50}$/.test(userId)) {
    return <ErrorMessage message="Invalid user ID format" />;
  }

  // Sanitize content
  const cleanContent = sanitizeHtml(content);

  return <div>{cleanContent}</div>;
};
```

## Quick Reference: Performance Requirements

### Must Use `useCallback`:
- ✅ All event handlers (`onClick`, `onChange`, `onSubmit`, etc.)
- ✅ All function props passed to child components
- ✅ Functions used in `useEffect` dependencies
- ✅ Callback functions in custom hooks

### Must Use `useMemo`:
- ✅ Filter/map/reduce/sort operations
- ✅ Object/array creation
- ✅ String concatenations
- ✅ CSS class name computations (`cn()` calls)
- ✅ Mathematical calculations
- ✅ Expensive computations

### Must Use `React.memo`:
- ✅ Components receiving stable props but parent re-renders frequently
- ✅ Components used in lists with many items
- ✅ Expensive-to-render components

### Must NOT Create Inline:
- ❌ Objects in JSX props: `style={{ color: 'red' }}`
- ❌ Arrays in JSX props: `items={[item1, item2]}`
- ❌ Functions in JSX props: `onClick={() => doSomething()}`

---

This comprehensive guide covers all major aspects of React TypeScript development in the node-ui project. Following these conventions will ensure consistent, maintainable, performant, and high-quality code across the frontend codebase.

**Remember:** Performance optimization is not optional. All code must follow the `useCallback` and `useMemo` requirements outlined in this document.
