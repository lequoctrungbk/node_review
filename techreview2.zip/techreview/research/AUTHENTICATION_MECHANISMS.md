# 🔐 Cơ Chế Xác Thực Trong Project

Project của bạn sử dụng **kiến trúc layered authentication** với nhiều cơ chế xác thực khác nhau cho các use cases và security levels khác nhau.

## 🏗️ Kiến Trúc Layered Authentication

### 1. Public Routes (Không cần xác thực)
```rust
pub fn create_public_router() -> Router<Arc<AppState>> {
    Router::new()
        .route("/ws", get(websocket::websocket_handler))
        .merge(auth::handlers::public_auth_routes()) // Onboarding, health checks
        .merge(auth::handlers::auth_routes())        // Challenge/response flows
        .nest("/version", version::routes())         // Public version info
}
```

### 2. Lightning-Authenticated Routes (Lightning Signature)
```rust
let lightning_api_store_router = create_lightning_api_store_router()
    .route_layer(middleware::from_fn_with_state(
        app_state.clone(),
        unified_auth_middleware  // Supports both JWT & Lightning
    ));
```

### 3. L402 Protected Routes (Lightning Micropayments)
```rust
let l402_protected_router_v1 = create_l402_protected_message_routes()
    .route_layer(middleware::from_fn_with_state(
        app_state.clone(),
        l402::middleware::l402_middleware
    ));
```

### 4. JWT Protected Routes (Session-based)
```rust
let protected_router_v1 = create_protected_router()
    .route_layer(middleware::from_fn_with_state(
        app_state.clone(),
        auth_middleware  // JWT token validation
    ));
```

## 🔑 Các Cơ Chế Xác Thực Chi Tiết

### 1. JWT Authentication (Session Management)
```rust
// JWT Token Structure
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct JwtClaims {
    pub sub: String,        // user_id
    pub node_id: String,    // lightning node public key
    pub public_key_hash: String,
    pub public_key: String,
    pub device_id: String,
    pub exp: i64,
    pub iat: i64,
    pub is_primary_owner: bool,
}
```

**Workflow:**
1. **Login** → User provides credentials (public key + signature)
2. **Challenge-Response** → Server creates challenge, client signs it
3. **Token Generation** → Server verifies signature, issues JWT + refresh token
4. **Session Management** → JWT used for subsequent requests
5. **Token Refresh** → Refresh tokens extend sessions without re-auth

**Security Features:**
- ✅ **Device Tracking** - Tokens tied to specific devices
- ✅ **Role-based Access** - Owner, Agent, Guest roles
- ✅ **Token Expiration** - Configurable expiry times
- ✅ **Refresh Tokens** - Secure token rotation
- ✅ **Signature Verification** - Cryptographic proof of identity

### 2. Lightning Authentication (Node-to-Node)
```rust
// Lightning Auth Header
#[derive(Debug, Serialize, Deserialize)]
pub struct LightningAuthHeader {
    pub node_id: String,      // Lightning node public key
    pub timestamp: i64,       // Request timestamp
    pub signature: String,    // ECDSA signature
}
```

**Workflow:**
1. **Request Creation** → Client creates request with timestamp
2. **Message Signing** → Client signs `method + path + timestamp + body_hash`
3. **Signature Verification** → Server verifies using node's public key
4. **Nonce Check** → Prevents replay attacks with 2-minute validity window
5. **Access Grant** → Valid requests proceed to business logic

**Security Features:**
- ✅ **Cryptographic Security** - ECDSA signatures with secp256k1
- ✅ **Replay Protection** - Timestamp-based nonce cache
- ✅ **Identity Verification** - Direct node public key validation
- ✅ **No Shared Secrets** - Uses node's private key only

### 3. L402 Authentication (Micropayments)
```rust
// L402 Token Format: LSAT <macaroon>:<preimage>
pub struct L402Token {
    pub macaroon: String,     // Access token
    pub preimage: String,     // Payment proof
    pub amount_msats: u64,    // Payment amount
    pub service_id: String,   // Service identifier
}
```

**Workflow:**
1. **Access Request** → Client requests protected resource
2. **Payment Required** → Server responds with 402 + Lightning invoice
3. **Payment** → Client pays invoice via Lightning Network
4. **Token Issuance** → Server verifies payment, issues LSAT token
5. **Access Grant** → Client retries with `Authorization: LSAT <token>`

**Security Features:**
- ✅ **Non-reversible Payments** - Lightning prevents fraud
- ✅ **Macaroon-based Auth** - Granular access control
- ✅ **Payment Verification** - Cryptographic proof of payment
- ✅ **Service-specific Pricing** - Per-endpoint pricing
- ✅ **Time-limited Access** - Configurable token expiry

## 🎯 Use Cases & Route Protection

### Authentication Matrix:

| Route Type | Authentication | Use Case | Example |
|------------|----------------|----------|---------|
| **Public** | None | Health checks, onboarding | `/healthz`, `/version` |
| **Lightning API Store** | Lightning Auth | Node-to-node commerce | `/api/store/buy` |
| **L402 Protected** | L402 Micropayments | Paid services | `/api/messages/send` |
| **JWT Protected** | JWT Tokens | User sessions | `/api/user/profile` |

### Route Examples:

```rust
// Public routes - no authentication
.route("/healthz", get(health_check_handler))
.route("/auth/challenge", post(create_auth_challenge))

// Lightning authenticated - node signature required
.route("/api/store/purchase", post(purchase_handler))
  .layer(unified_auth_middleware)  // Supports JWT + Lightning

// L402 protected - micropayment required
.route("/api/messages/send", post(send_message_handler))
  .layer(l402_middleware)  // Lightning payment required

// JWT protected - session required
.route("/api/user/profile", get(get_user_profile))
  .layer(auth_middleware)  // JWT token required
```

## 🔧 Implementation Details

### Middleware Stack:
```rust
let app = Router::new()
    .nest("/api", api_router)
    .nest("/api/v2", api_v2_router)
    .layer(ValidationLayer::new(app_state.clone()))  // Input validation
    .layer(trace_layer)                              // Request tracing
    .layer(cors)                                     // CORS headers
    .layer(security_headers_middleware)              // Security headers
    .fallback(spa_handler)                           // React SPA
```

### Token Management:
```rust
// JWT Service Configuration
pub struct JwtServiceConfig {
    pub jwt_secret: String,
    pub jwt_token_expiry: i64,        // Access token: 15 hours
    pub refresh_token_expiry: i64,    // Refresh token: 7 days
    pub refresh_token_secret: String,
}
```

### L402 Pricing Configuration:
```rust
// Per-service pricing
pub struct ProxyServiceConfig {
    pub api_port_price_msats: u64,        // 1000 msats = 1 sat
    pub lightning_port_price_msats: u64, // 5000 msats = 5 sats
}
```

## 🔒 Security Architecture

### Defense in Depth:
- ✅ **Multiple Auth Methods** - JWT, Lightning, L402 for different contexts
- ✅ **Layered Protection** - Route-level authentication decisions
- ✅ **Cryptographic Security** - ECDSA signatures, SHA256 hashing
- ✅ **Replay Protection** - Nonce cache, timestamp validation
- ✅ **Input Validation** - Request sanitization và type safety
- ✅ **Rate Limiting** - Built-in abuse protection

### Key Security Principles:
- ✅ **Zero Trust** - Every request authenticated/authorized
- ✅ **Principle of Least Privilege** - Minimal permissions granted
- ✅ **Secure Defaults** - Authentication required by default
- ✅ **Audit Trail** - All authentication events logged
- ✅ **Token Isolation** - Different tokens for different purposes

## 🚀 Business Model Integration

### Revenue Streams:
- **API Port Rental**: Lightning nodes rent public IPs (1 sat/hour)
- **Lightning Port Rental**: Higher pricing for Lightning connectivity
- **Premium Services**: L402-protected features
- **API Store**: Node-to-node commerce via Lightning auth

### Monetization Strategy:
- ✅ **Lightning Native**: All payments via Lightning Network
- ✅ **Micropayments**: Very low friction payments
- ✅ **Automated Billing**: Self-service infrastructure rental
- ✅ **Scalable Pricing**: Dynamic pricing based on demand

## 📊 Monitoring & Analytics

### Authentication Metrics:
- ✅ **Login Success/Failure Rates**
- ✅ **Token Validation Times**
- ✅ **Payment Processing Stats**
- ✅ **Authentication Error Types**
- ✅ **Rate Limiting Events**

### Business Metrics:
- ✅ **Active Users by Auth Method**
- ✅ **Revenue by Service Type**
- ✅ **Payment Success Rates**
- ✅ **API Usage Analytics**

---

## 📝 Tóm Tắt

Project của bạn có hệ thống xác thực **layered, multi-modal** rất sophisticated, kết hợp:
- **JWT Authentication** cho user sessions và device management
- **Lightning Authentication** cho node-to-node communication
- **L402 Micropayments** cho paid services và infrastructure rental

Đây là architecture rất phù hợp cho Lightning ecosystem với emphasis vào decentralization và micropayments! ⚡🔐
