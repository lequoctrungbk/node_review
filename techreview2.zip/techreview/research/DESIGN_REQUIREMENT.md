# TỔNG HỢP YÊU CẦU THIẾT KẾ NODE

## 1. TRIẾT LÝ THIẾT KẾ UI/UX

### 1.1. Nguyên Tắc Cốt Lõi

- **Friendly + Transparent**: Đơn giản cho đại chúng, nhưng minh bạch về hoạt động
- **Mass Market First**: Hướng tới người dùng phổ thông, không chỉ kỹ sư
- **Invisible Complexity**: P2P, mã hóa, Lightning hoạt động ẩn dưới giao diện
- **No Gatekeepers**: Không cần phê duyệt từ app stores, ngân hàng, hay cloud providers

### 1.2. Tham Khảo UI

- **Cash App**: Đơn giản, trực quan
- **Wise App**: Rõ ràng về quy trình và chi phí
- **Spotify**: Trải nghiệm mượt mà

## 2. HAI CHẾ ĐỘ XEM (DUAL VIEW SYSTEM)

### 2.1. USER VIEW (Chế Độ Người Dùng)

- Giao diện tối giản, dễ hiểu
- Tự động, không cần kiến thức kỹ thuật
- Tập trung vào chức năng, không hiển thị chi tiết kỹ thuật

### 2.2. NODE EXPERT VIEW (Chế Độ Chuyên Gia)

Hiển thị đầy đủ thông tin hệ thống:

- **Routing**: Đường đi tin nhắn (NODE A → NODE X → NODE B)
- **Fees**: Chi phí từng micro-payment (ví dụ: 3 sats)
- **Cryptographic Events**: X25519 handshake, AES-GCM, session keys
- **Timeline**: Timestamp cho từng sự kiện
- **Message Lifecycle**: Từ mã hóa → routing → thanh toán → giao nhận → ACK
- **Payment Flow**: Hold invoices, hashlock, route discovery, hop settlement

**Ví dụ Expert View Log:**

```
[11:02:14] 📅 NODE A opens chat with NODE B
[11:02:14] 🌐 Fetching NODE B's peer record (G1 Cache)
[11:02:15] 🌐 X25519 handshake initiated NODE A → NODE B
[11:02:15] 🌐 Session key agreed / AES-GCM enabled
[11:02:17] 📧 NODE A types: "hey"
[11:02:17] 🌐 Message encrypted (msg_id: 0x14A2)
[11:02:18] 🚫 Calculating micro-fee for delivery (est: 3 sats)
[11:02:19] © Route discovery: NODE A → NODE X → NODE B
[11:02:20] 🚫 Payment dispatched (msg-linked, 3 sats)
[11:02:21] 📧 Message delivered to NODE B
```

## 3. KIẾN TRÚC KỸ THUẬT

### 3.1. Web-Based Architecture

- **PWA (Progressive Web App)**:
  - Cài đặt trên home screen
  - Hoạt động offline
  - Push notifications
  - Không cần app store approval
  - Không bị đánh thuế 30%
- **Self-hosted**: Truy cập từ phone, tablet, desktop qua web
- **Local-first**: Dữ liệu lưu/encrypt trên thiết bị, replicate P2P
- **IPv6 Native**: Không phụ thuộc domain, tránh kiểm duyệt

### 3.2. Front-End Loaded Architecture

- **Lý do**: Thiết bị chỉ có <1GB RAM, cần tối ưu
- **Server**: Chỉ serve data, CRUD operations
- **Client**: Xử lý rendering, logic, interaction
- **Backend**: Rust (Axum) cho performance
- **Frontend**: React 19 + TypeScript, cache local

### 3.3. 3D UI

- **Framework**: Three.js
- **Mục tiêu**: Giao diện 3D trực quan, không gian
- **Platform**:
  - Desktop/Tablet: 3D mặc định
  - Phone: 2D mode
  - WebXR-compatible: Hỗ trợ Oculus, VR headsets
- **Tương lai**: Sẵn sàng cho AR/VR

## 4. STACK CÔNG NGHỆ

### 4.1. Backend (Rust)

- **Framework**: Axum
- **Lightning**: LDK (Lightning Development Kit)
- **Bitcoin**: Bitcoin Core (full hoặc pruned)
- **Database**: SQLite + Diesel ORM
- **Runtime**: Tokio (async)
- **Platform**: ARM & x86_64

### 4.2. Frontend (React/TypeScript)

- **Framework**: React 19 + TypeScript
- **Styling**: TailwindCSS 4 + Radix UI
- **State Management**: Zustand + React Query
- **Real-time**: WebSockets
- **Crypto**: BIP39/BIP32, WebCrypto API

### 4.3. Tiny Models (In-Browser)

- **Lý do**:
  - Browser có GPU, chạy inference local
  - Giảm chi phí, bảo mật, không phụ thuộc centralized providers
- **Approach**: Nhiều model nhỏ phối hợp thay vì một model lớn

## 5. TÍNH NĂNG P2P

### 5.1. P2P Store Architecture

- **API Store**: Nodes resell APIs, thêm margin (ví dụ: 20%)
- **Agent Store**: Build và rent AI agents, kiếm Bitcoin
- **App Store**: Build apps (vibe coding), bán không cần permission
- **Benefits**:
  - Pay-per-use thay vì subscription
  - Developers monetize ngay
  - Users giữ privacy và control

### 5.2. Discovery & Communication

- **Discovery**: Gossip protocol cho node và app metadata
- **Messaging**: True P2P, không cần central service
- **Backup**: Encrypted shards (~10MB), redundancy 1x-5x

## 6. PAYMENTS & LIGHTNING

### 6.1. L402 Protocol

- **HTTP 402**: Payment Required - native web payments
- **Use Cases**:
  - Gating content, APIs, agents
  - Spam prevention (message fees)
  - Anonymous backup payments
  - In-app interactions

### 6.2. Lightning Integration

- **Stack**: LDK
- **Protocols**: LNURL, BOLT12 offers, invoice streaming
- **Contracts**: HTLC-based escrow (bets, donations, pools)
- **Identity = Wallet**: Pubkey làm user handle

## 7. SECURITY & IDENTITY

- **Identity**: Lightning pubkey = DID (Decentralized Identifier)
- **Authentication**: BIP39 seed (12 words), không cần password
- **Attestation**: Device integrity proofs
- **Encryption**: End-to-end mặc định
- **Hardware**: ATECC608A, TPM 2.0, ESP32-C6 cho tampering check

## 8. HARDWARE UI COMPONENTS

- **Display**: 1.75" AMOLED touch-screen circular
- **NFC**: Reader/writer cho backup và spend cards
- **Audio**: Microphone và speakers
- **Future**: Web/IR camera (biometric, gesture), laser projector

## 9. YÊU CẦU HIỆU NĂNG

- **Memory**: <1GB RAM
- **Efficiency**: Front-end loaded để giảm tải server
- **Offline**: Hoạt động offline
- **Sync**: Seamless sync giữa client và server

## 10. TÍNH NĂNG ĐẶC BIỆT

- **Hub Access**: Chia sẻ với bạn bè (limited features, không cần hardware)
- **Multi-device Sync**: Đồng bộ qua nhiều thiết bị
- **Physical Cards**: NFC backup/spend cards
- **Network Visualization**: Dashboard hiển thị network topology

---

## TÓM TẮT CÁC NGUYÊN TẮC THIẾT KẾ CHÍNH

1. **Simplicity First**: Giao diện đơn giản, trực quan cho đại chúng
2. **Transparency Option**: Expert view cho người muốn xem chi tiết
3. **No Gatekeepers**: PWA, IPv6, không phụ thuộc app stores
4. **Privacy by Default**: End-to-end encryption, local-first
5. **Payments Native**: L402 tích hợp sẵn, Lightning payments
6. **Performance Critical**: Front-end loaded, tối ưu cho <1GB RAM
7. **Future-Ready**: 3D UI, WebXR, AR/VR compatible
8. **P2P First**: True decentralization, không cần central services

---

**Lưu ý**: Các yêu cầu này định hướng một hệ thống vừa dễ dùng cho người dùng phổ thông, vừa minh bạch và mạnh mẽ cho người dùng kỹ thuật.

**Nguồn**: Tổng hợp từ UIFriendlyvsExpertmode.pdf và NodeFeaturesTechspecs.pdf
