# Request Flow Guide: How Requests Enter Your Project

## Entry Point: main.rs

All HTTP requests **start** in `packages/backend/src/main.rs` - this is the **entry point** of your Rust application.

## Request Flow Overview

```
┌─────────────────┐    ┌──────────────────────┐    ┌──────────────────────┐
│   HTTP Client   │───▶│   Axum Router       │───▶│   Handler Functions  │
│   (Browser/API) │    │   (main.rs:1545)    │    │   (routes/*.rs)      │
└─────────────────┘    └──────────────────────┘    └──────────────────────┘
                         │                              │
                         ▼                              ▼
                ┌──────────────────────┐    ┌──────────────────────┐
                │   Middleware         │    │   Business Logic     │
                │   (Auth, CORS, etc.) │    │   (Services)         │
                └──────────────────────┘    └──────────────────────┘
```

## Detailed Request Flow

### 1. **HTTP Request Arrives** → `main.rs:1763`
```rust
// Server starts here
axum::serve(listener, app).await
```
- **File**: `packages/backend/src/main.rs:1763`
- **Function**: `axum::serve()` starts the HTTP server
- **Port**: Configured in `config.server_address` (default: localhost:8080)

### 2. **Router Routes Request** → `main.rs:1545-1561`
```rust
let app = Router::new()
    // V1 API routes (existing endpoints)
    .nest("/api", api_router)
    // V2 API routes (new layered architecture)
    .nest("/api/v2", api_v2_router)
    // Security headers middleware
    .layer(axum::middleware::from_fn(security_headers_middleware))
    // CORS, logging, validation layers
    .layer(trace_layer)
    .layer(cors)
    .layer(ValidationLayer::new(app_state.clone()))
    // SPA fallback for frontend
    .fallback(spa_handler)
    .with_state(app_state.clone());
```

#### Route Structure:
- **`/api`** → V1 API (legacy endpoints)
- **`/api/v2`** → V2 API (layered architecture)
- **`/healthz`** → Health check
- **SPA fallback** → Serves React frontend for all other routes

### 3. **Middleware Processing**

#### Security Headers Middleware (`main.rs:1772`)
```rust
async fn security_headers_middleware(request: Request, next: Next) -> Response {
    // Adds CSP, X-Frame-Options, X-Content-Type-Options
}
```

#### Validation Layer
```rust
.layer(ValidationLayer::new(app_state.clone()))
```
- Validates request data before reaching handlers

#### Authentication Middleware
```rust
middleware::from_fn_with_state(app_state.clone(), unified_auth_middleware)
```
- **File**: `packages/backend/src/auth/middleware.rs`
- Checks JWT tokens or Lightning authentication

#### L402 Payment Middleware
```rust
middleware::from_fn_with_state(app_state.clone(), l402::middleware::l402_middleware)
```
- **File**: `packages/backend/src/l402/middleware.rs`
- Handles micropayments for API access

### 4. **Route Handlers** → `routes/*.rs`

#### Public Routes (`routes/public.rs`)
```rust
pub fn create_public_router() -> Router<AppState> {
    Router::new()
        .route("/conversations", get(get_conversations))
        .route("/posts", get(get_posts))
        // ... more public routes
}
```

#### Protected Routes (`routes/protected.rs`)
```rust
pub fn create_protected_router() -> Router<AppState> {
    Router::new()
        .route("/conversations", post(create_conversation))
        .route("/messages", post(send_message))
        // ... authenticated routes
}
```

#### L402 Protected Routes (`routes/l402.rs`)
```rust
pub fn create_l402_protected_message_routes() -> Router<AppState> {
    Router::new()
        .route("/messages", post(send_paid_message))
        // ... paid API routes
}
```

### 5. **Handler Functions** → `handlers/*.rs`

#### Example Handler Pattern:
```rust
pub async fn create_conversation(
    State(state): State<Arc<AppState>>,
    Claims(claims): Claims,  // JWT auth
    ValidatedJson(request): ValidatedJson<CreateConversationRequest>,
) -> Result<Json<ConversationResponse>, AppError> {
    // 1. Extract user_id from JWT claims
    let user_id = claims.user_id;

    // 2. Call service layer
    let conversation = state.conversation_service
        .create_conversation(user_id, request)
        .await?;

    // 3. Return response
    Ok(Json(conversation))
}
```

### 6. **Service Layer** → `services/*.rs`

#### Business Logic Processing:
```rust
impl ConversationService for DefaultConversationService {
    async fn create_conversation(
        &self,
        user_id: String,
        request: CreateConversationRequest,
    ) -> Result<Conversation, ServiceError> {
        // 1. Validate business rules
        self.validate_participants(&request.participant_ids).await?;

        // 2. Check permissions
        self.check_user_permissions(user_id, &request.participant_ids).await?;

        // 3. Create via repository
        let conversation = self.conversation_repo.create(request).await?;

        // 4. Send notifications
        self.notify_participants(&conversation).await?;

        Ok(conversation)
    }
}
```

### 7. **Repository Layer** → `repositories/*.rs`

#### Database Operations:
```rust
impl ConversationRepository for DieselConversationRepository {
    async fn create(
        &self,
        request: CreateConversationDbRequest,
    ) -> Result<Conversation, RepositoryError> {
        let mut conn = self.db_pool.get()?;

        diesel::insert_into(conversations::table)
            .values(&request)
            .execute(&mut conn)?;

        // Return created entity
        Ok(Conversation::from(request))
    }
}
```

## Complete Request Flow Examples

### Example 1: Creating a Conversation (Authenticated)

```
1. POST /api/conversations
2. → CORS middleware
3. → Security headers middleware
4. → Validation layer
5. → Authentication middleware (JWT)
6. → Router matches /api/conversations → create_conversation handler
7. → Handler calls conversation_service.create_conversation()
8. → Service validates business rules
9. → Service calls conversation_repo.create()
10. → Repository executes INSERT query
11. → Response flows back up the layers
12. → JSON response returned to client
```

### Example 2: Sending a Paid Message (L402)

```
1. POST /api/messages
2. → CORS middleware
3. → Security headers middleware
4. → Validation layer
5. → L402 payment middleware (checks Lightning invoice)
6. → Router matches /api/messages → send_paid_message handler
7. → Handler calls message_service.send_message()
8. → Service processes message
9. → Service calls message_repo.create()
10. → Repository saves message
11. → Response with payment confirmation
```

### Example 3: Public Health Check

```
1. GET /healthz
2. → CORS middleware
3. → Security headers middleware
4. → Router matches /healthz → health_check_handler
5. → Handler returns simple 200 OK response
```

## Key Files in Request Flow

| Layer | Primary Files | Responsibility |
|-------|---------------|----------------|
| **Entry** | `main.rs` | Server startup, middleware setup, routing |
| **Routes** | `routes/*.rs` | URL pattern matching, route organization |
| **Middleware** | `auth/middleware.rs`, `l402/middleware.rs` | Authentication, payments, validation |
| **Handlers** | `handlers/*.rs` | HTTP request/response handling |
| **Endpoints** | `endpoints/*.rs` | Protocol-agnostic interfaces (Layer 2) |
| **Services** | `services/*.rs` | Business logic (Layer 3) |
| **Repositories** | `repositories/*.rs` | Database operations (Layer 4) |

## Development Workflow

### Adding New Endpoints:

1. **Add route** in `routes/*.rs`
2. **Create handler** in `handlers/*.rs`
3. **Add service method** in `services/*.rs`
4. **Add repository method** in `repositories/*.rs`
5. **Update tests** in respective `*_tests.rs` files

### Debugging Requests:

1. **Check logs** with `target: "node_backend::*"` filters
2. **Use middleware** for request/response logging
3. **Test endpoints** with tools like HTTPie or Postman
4. **Check database** for data persistence issues

## Common Issues

### Authentication Problems
- Check JWT token in request headers
- Verify `Claims` extractor in handler signature
- Check middleware logs for auth failures

### Validation Errors
- Check `ValidatedJson` extractor usage
- Verify request struct derives `Validate`
- Check validation error messages

### Database Issues
- Check connection pool exhaustion
- Verify repository method implementations
- Check SQL query syntax

### Performance Problems
- Use `EXPLAIN QUERY PLAN` for slow queries
- Check middleware overhead
- Monitor connection pooling

---

**Remember**: Every HTTP request starts in `main.rs` and flows through the layered architecture. Understanding this flow is key to effective debugging and feature development! 🔄
