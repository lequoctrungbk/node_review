# Improvement Suggestions

## 1. Project Management
- Implement CI/CD for the project to easily identify which merge request causes conflicts.
- CI/CD should include at least the following stages: code build, security scanning, coverage testing, and full functional testing; integration testing can be added later.
- Roll out CI/CD in phases:
  - **Phase 1**: Schedule a daily pipeline to run at a fixed time, automatically building and testing the main branch every day.
  - **Phase 2**: Apply CI/CD to every commit (with basic tests).
- Research the use of AI to automatically check coding conventions for each Merge Request and integrate it into the CI/CD pipeline.
- Enforce coding conventions in AI-generated code: Require the AI to read and adhere to the project's specific coding convention rules prior to generating any code.

## 2. Database Design
- Large tables containing only non-critical logs should be moved to a separate schema.
- Any new or expanding tables should implement auto-rolling mechanisms (e.g., partitioning or archiving).
- Estimate traffic per node and calculate appropriate sizing. Implement a tool to automatically clean up garbage data when a node is approaching full capacity.
- Backup: Avoid relying solely on Google Drive. Implement proper backup mechanisms with support for automatic rollback in case of database crashes.

## 3. Checklist
- The system should have a separate checklist to verify issues that CI/CD cannot detect.
- Build an automated checklist using Bash or Python scripts to ensure all functions are running correctly. The checklist should include:
  - API endpoint checks
  - Server status checks (disk, CPU, memory, etc.)
  - Verification that sufficient instances/processes are running
  - Other health checks relevant to the system
  ...

## 4. Documentation
- Current documentation for individual functions is good, but it lacks an overall system overview document.
- Documentation files are scattered, with no links between them, making it difficult for new developers to understand the system.
- There is no low-level design (LLD) document for the project.
- Create a document index (table of contents) to make the documentation more professional and easier for new team members to navigate.

## 5. Testing
- **Backend**:
  - Functional tests lack coverage for many exception and error cases.
  - Unit tests currently cover only a small portion of the code; aim to achieve at least 70-80% coverage for critical files.
- **Node-UI (Frontend)**:
  - Insufficient mock test cases.
  - Lack of test cases for exception and error scenarios.

## 6. Dependency
- Build process takes too long: There are many dependencies, and it's unclear if all are actually used. The resulting build output is excessively large (10-20 GB including dependencies).
- After some time, versions are not preserved: This can lead to incompatibility issues later.
- Best practice: Create a dedicated repository suited for the project: This helps avoid conflicts with newer versions in the future.