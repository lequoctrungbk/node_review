# Markdown File Naming Conventions

This document outlines the standardized naming conventions for markdown (`.md`) files across the project.

## General Rules

### 1. **Case Convention**
- Use **`UPPER_CASE_WITH_UNDERSCORES`** for all markdown filenames
- **Examples:**
  - ✅ `DATABASE_ERD.md`
  - ✅ `ARCHITECTURAL_ANALYSIS_EVALUATION.md`
  - ✅ `RUST_CODING_CONVENTIONS.md`
  - ❌ `database_erd.md`
  - ❌ `DatabaseERD.md`
  - ❌ `database-erd.md`

### 2. **File Extension**
- Always use **lowercase** `.md` extension
- **Correct:** `README.md`
- **Incorrect:** `README.MD`, `README.mdx`

### 3. **Word Separation**
- Use **`_` (underscore)** to separate words
- **Never use:** hyphens `-`, spaces ` `, or camelCase
- **Examples:**
  - ✅ `API_PATH_NAMING_STANDARDS.md`
  - ✅ `TECHNICAL_DEBT_TODOS.md`
  - ❌ `API-PATH-NAMING-STANDARDS.md`
  - ❌ `API PATH NAMING STANDARDS.md`

## Category-Specific Naming Patterns

### 1. **Technical Review Documents** (`docs/techreview/`)
```
TOPIC_DESCRIPTION.md
```

**Examples:**
- `DATABASE_ERD.md` - Database Entity Relationship Diagram
- `OPENAPI_SECURITY_ANALYSIS.md` - OpenAPI security analysis
- `DIRECTORY_STRUCTURE_ANALYSIS.md` - Directory structure analysis
- `RUST_CODING_CONVENTIONS.md` - Rust coding conventions

### 2. **Architecture Documents** (`docs/architecture/`)
```
ARCHITECTURE_COMPONENT.md
```

**Examples:**
- `LAYERED_ARCHITECTURE_EXPLAINED.md`
- `FIVE_LAYER_ARCHITECTURE.md`

### 3. **API Documentation** (`docs/api/`)
```
SYSTEM_API.md
```

**Examples:**
- `AI_AGENT_API.md`
- `BULLETIN_BOARD_API.md`
- `NETWORK_API.md`

### 4. **Feature Documentation** (`docs/features/`)
```
FEATURE_NAME.md
```

**Examples:**
- `IP_POOL_MANAGEMENT.md`
- `WEB_TERMINAL.md`
- `L402_MANAGEMENT.md`

## Special Files

### 1. **README Files**
- Use `README.md` (standard convention)
- Place in root directories of major components

### 2. **Index Files**
- Use `INDEX.md` or `TECHREVIEW_INDEX.md` for documentation indexes

### 3. **Migration/Planning Files**
```
MIGRATION_PLAN.md
SPRINT_PLAN_WEEK2.md
PHASE1_ROADMAP.md
```

## File Organization Examples

```
docs/
├── techreview/
│   ├── ARCHITECTURAL_ANALYSIS_EVALUATION.md
│   ├── DATABASE_ERD.md
│   ├── OPENAPI_SECURITY_ANALYSIS.md
│   └── TECHREVIEW_INDEX.md
├── architecture/
│   ├── LAYERED_ARCHITECTURE_EXPLAINED.md
│   └── README.md
├── api/
│   ├── AI_AGENT_API.md
│   ├── BULLETIN_BOARD_API.md
│   └── README.md
└── features/
    ├── IP_POOL_MANAGEMENT.md
    ├── WEB_TERMINAL.md
    └── README.md
```

## Migration Guidelines

### From Kebab-Case to UPPER_CASE
When renaming existing files:

**Before:**
- `api-path-naming-standards.md`
- `backend-coding-convention-audit.md`
- `directory-structure-analysis.md`

**After:**
- `API_PATH_NAMING_STANDARDS.md`
- `BACKEND_CODING_CONVENTION_AUDIT.md`
- `DIRECTORY_STRUCTURE_ANALYSIS.md`

### Automated Renaming
Use PowerShell commands for bulk renaming:

```powershell
# Rename single file
ren "api-path-naming-standards.md" "API_PATH_NAMING_STANDARDS.md"

# Rename multiple files (example)
Get-ChildItem "*.md" | Where-Object { $_.Name -match "-" } | ForEach-Object {
    $newName = $_.Name -replace "-", "_" -replace "([a-z])([A-Z])", '$1_$2' | ForEach-Object { $_.ToUpper() }
    ren $_.Name $newName
}
```

## Benefits of UPPER_CASE_WITH_UNDERSCORES

### 1. **Consistency**
- All documentation files follow the same pattern
- Easy to identify documentation vs code files

### 2. **Readability**
- Clear word separation with underscores
- Easy to parse visually: `DATABASE_ERD` vs `databaseerd`

### 3. **Searchability**
- Consistent patterns make files easy to find
- Sort alphabetically in file explorers

### 4. **Professional Appearance**
- Matches technical documentation standards
- Looks clean and organized

### 5. **URL-Friendly**
- Underscores are safe in URLs and file paths
- No encoding issues like with spaces or special characters

## Exceptions

### 1. **Third-Party Documentation**
- Keep original naming for imported documentation
- Add prefix if needed: `THIRD_PARTY_GUIDE.md`

### 2. **Legacy Files**
- Gradually migrate legacy files to new convention
- Update references when renaming

### 3. **Generated Files**
- Auto-generated docs may use different conventions
- Document generation scripts should follow these rules

## Tooling Support

### VS Code Extensions
- Use "File Utils" extension for bulk renaming
- "Markdown All in One" for consistent formatting

### Scripts
Consider creating a rename script for consistency:

```bash
#!/bin/bash
# rename_md_files.sh
for file in *.md; do
    if [[ $file =~ ^[a-z]+(-[a-z]+)*\.md$ ]]; then
        new_name=$(echo "$file" | tr 'a-z-' 'A-Z_' | sed 's/_MD/.md/')
        mv "$file" "$new_name"
        echo "Renamed: $file → $new_name"
    fi
done
```

## Enforcement

### 1. **Pre-commit Hooks**
```bash
# .pre-commit-config.yaml
repos:
  - repo: local
    hooks:
      - id: md-naming-convention
        name: Markdown naming convention
        entry: ./scripts/check_md_naming.sh
        language: system
        files: \.md$
```

### 2. **CI/CD Checks**
```yaml
# .github/workflows/ci.yml
- name: Check Markdown naming
  run: |
    ./scripts/check_md_naming.sh
```

### 3. **Code Review Checklist**
- [ ] All new `.md` files follow UPPER_CASE_WITH_UNDERSCORES naming
- [ ] File references in documentation updated after renaming
- [ ] Links in index files updated

## Quick Reference

| Pattern | Example | Status |
|---------|---------|--------|
| `TOPIC_DESCRIPTION.md` | `DATABASE_ERD.md` | ✅ Correct |
| `topic-description.md` | `database-erd.md` | ❌ Incorrect |
| `TopicDescription.md` | `DatabaseErd.md` | ❌ Incorrect |
| `TOPIC_DESCRIPTION.MD` | `DATABASE_ERD.MD` | ❌ Incorrect |

---

*These conventions ensure consistency across all markdown documentation in the project. When in doubt, use UPPER_CASE_WITH_UNDERSCORES.*
