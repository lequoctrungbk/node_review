# REST API Path Naming Standards

> **Version:** 1.0.0  
> **Last Updated:** 2025-01-18  
> **Status:** Approved

## Overview

This document defines the standard conventions for naming REST API paths in this project. All new APIs must follow these rules. Existing APIs should be migrated when possible.

---

## 1. Core Principles

| Principle | Rule | Example |
|-----------|------|---------|
| **Kebab-case** | Use hyphens to separate words, lowercase only | `/user-profiles` |
| **Nouns** | Use nouns only, HTTP methods define actions | `GET /users` not `GET /getUsers` |
| **Plural** | Always use plural nouns for collections | `/users/{id}` not `/user/{id}` |
| **Hierarchy** | Structure paths to reflect parent-child relationships | `/users/{id}/orders` |
| **Consistent** | Apply the same rules across all APIs | No mixing styles |

---

## 2. Path Segment Rules

### 2.1 Use Kebab-case

```yaml
# ✅ CORRECT
/user-profiles
/order-items
/payment-methods
/ip-pools
/endpoint-fees

# ❌ WRONG
/userProfiles      # camelCase
/user_profiles     # snake_case
/UserProfiles      # PascalCase
/USERS             # UPPERCASE
```

### 2.2 Use Plural Nouns

```yaml
# ✅ CORRECT
/users
/users/{id}
/orders
/orders/{id}
/notifications
/ip-pools

# ❌ WRONG
/user
/user/{id}
/order
/notification
/ip-pool
```

### 2.3 No Verbs in Paths

```yaml
# ✅ CORRECT - HTTP method defines the action
GET    /users              # List users
POST   /users              # Create user
GET    /users/{id}         # Get user
PUT    /users/{id}         # Update user
DELETE /users/{id}         # Delete user

# ❌ WRONG - Verbs in path
GET    /getUsers
POST   /createUser
GET    /fetchUserById/{id}
POST   /deleteUser/{id}
```

---

## 3. Path Parameters

### 3.1 Naming Convention

Use **snake_case** for path parameters (consistent with Rust backend):

```yaml
# ✅ CORRECT - snake_case
/users/{user_id}
/orders/{order_id}
/notifications/{notification_id}
/terminal-sessions/{session_id}

# ❌ WRONG - Inconsistent naming
/users/{userId}           # camelCase (inconsistent with backend)
/orders/{OrderId}         # PascalCase
/notifications/{ID}       # Uppercase
```

### 3.2 Descriptive Names

Use descriptive parameter names, not just `{id}`:

```yaml
# ✅ PREFERRED - Descriptive
/users/{user_id}/orders/{order_id}
/nodes/{node_id}/ip-pools/{pool_id}

# ⚠️ ACCEPTABLE - Simple id for single resource
/users/{id}
/orders/{id}

# ❌ WRONG - Ambiguous in nested paths
/users/{id}/orders/{id}    # Which id is which?
```

---

## 4. Query Parameters

### 4.1 Use snake_case

```yaml
# ✅ CORRECT
GET /users?is_active=true
GET /orders?start_date=2025-01-01&end_date=2025-12-31
GET /notifications?per_page=50&page=1
GET /ip-pools?port_type=lightning&is_public_facing=true

# ❌ WRONG
GET /users?isActive=true           # camelCase
GET /orders?startDate=2025-01-01   # camelCase
GET /notifications?perPage=50      # camelCase
```

### 4.2 Standard Query Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `page` | integer | Page number (1-indexed) |
| `per_page` | integer | Items per page |
| `limit` | integer | Maximum items to return |
| `offset` | integer | Number of items to skip |
| `sort_by` | string | Field to sort by |
| `sort_order` | string | `asc` or `desc` |
| `search` | string | Search query |
| `start_date` | date | Filter start date |
| `end_date` | date | Filter end date |
| `is_active` | boolean | Filter by active status |

---

## 5. Resource Hierarchy

### 5.1 Nested Resources

Structure paths to show parent-child relationships:

```yaml
# ✅ CORRECT - Clear hierarchy
/users/{user_id}/orders
/users/{user_id}/orders/{order_id}
/users/{user_id}/orders/{order_id}/items
/terminal-sessions/{session_id}/history
/nodes/{node_id}/ip-pools

# ❌ WRONG - Flat structure
/user-orders/{user_id}
/order-items/{order_id}
/session-history/{session_id}
```

### 5.2 Maximum Nesting Depth

Limit nesting to **3 levels** maximum:

```yaml
# ✅ CORRECT - 3 levels max
/users/{user_id}/orders/{order_id}/items

# ❌ WRONG - Too deep
/users/{user_id}/orders/{order_id}/items/{item_id}/reviews/{review_id}

# Better approach - flatten deep resources
/order-items/{item_id}/reviews
```

### 5.3 Domain-Scoped Resources

Use domain prefix for logically grouped resources:

```yaml
# ✅ CORRECT - Domain grouping
/l402/endpoint-fees
/l402/budgets
/l402/analytics/summary
/auto-discovery/metrics
/auto-discovery/events

# Prefix identifies the domain/feature
```

---

## 6. Actions (Non-CRUD Operations)

### 6.1 Preferred: Google Colon Style

```yaml
# ✅ RECOMMENDED - Clear action indication
POST /notifications/{id}:read
POST /notifications/{id}:dismiss
POST /orders/{id}:cancel
POST /users/{id}:deactivate
POST /ip-pools/{id}:set-default
POST /auto-discovery:enable
POST /auto-discovery:disable
POST /budgets/{type}:reset
```

### 6.2 Alternative: Sub-resource Style

```yaml
# ✅ ACCEPTABLE - Action as noun
POST /orders/{id}/cancellation
POST /users/{id}/verification
POST /payments/{id}/refund
```

### 6.3 Alternative: Actions Namespace

```yaml
# ✅ ACCEPTABLE - Explicit actions path
POST /orders/{id}/actions/cancel
POST /users/{id}/actions/send-verification
```

### 6.4 When Verbs Are Acceptable

```yaml
# ✅ OK - Industry standard patterns
POST /auth/login
POST /auth/logout
POST /auth/refresh
POST /search
POST /export
```

---

## 7. API Versioning

### 7.1 URL Path Versioning (Required)

```yaml
# ✅ CORRECT - Version in URL path
servers:
  - url: /api/v1
  - url: /api/v2

# Full paths
GET /api/v2/users
GET /api/v2/orders
```

### 7.2 Version Migration

```yaml
# When introducing breaking changes:
# 1. Create new version
/api/v2/users           # New format

# 2. Keep old version (deprecated)
/api/v1/users           # Old format, marked deprecated

# 3. Document migration timeline
```

---

## 8. Special Endpoints

### 8.1 Aggregation Endpoints

```yaml
# Summary/Statistics
GET /notifications/unread-count
GET /l402/outbound/summary
GET /l402/analytics/summary

# Dashboard (combined data)
GET /l402/dashboard
```

### 8.2 Export Endpoints

```yaml
# Data export
GET /l402/outbound/export              # Returns CSV
GET /reports/transactions/export       # Returns CSV/PDF
```

### 8.3 External APIs

Use `/external/` prefix for APIs accessed by other nodes:

```yaml
# ✅ CORRECT - External API prefix
POST /external/ip-pools/sync
POST /external/messages/receive
GET  /external/node-info

# Internal APIs (no prefix)
GET /ip-pools
GET /messages
```

---

## 9. Complete Examples

### 9.1 User Management API

```yaml
# Collection
GET    /users                           # List users
POST   /users                           # Create user

# Single resource
GET    /users/{user_id}                 # Get user
PUT    /users/{user_id}                 # Update user
DELETE /users/{user_id}                 # Delete user

# Nested resources
GET    /users/{user_id}/orders          # List user's orders
POST   /users/{user_id}/orders          # Create order for user
GET    /users/{user_id}/orders/{order_id}  # Get specific order

# Actions
POST   /users/{user_id}:deactivate      # Deactivate user
POST   /users/{user_id}:verify          # Send verification

# Filtering
GET    /users?is_active=true&role=admin&per_page=50
```

### 9.2 Notification API

```yaml
# Collection
GET    /notifications                   # List notifications
GET    /notifications/unread-count      # Get unread count

# Single resource
GET    /notifications/{id}              # Get notification
DELETE /notifications/{id}              # Delete notification

# Actions
POST   /notifications/{id}:read         # Mark as read
POST   /notifications/{id}:dismiss      # Dismiss notification

# Filtering
GET    /notifications?unread_only=true&notification_type=friend_request
```

### 9.3 IP Pool Management API

```yaml
# Collection
GET    /ip-pools                        # List IP pools
POST   /ip-pools                        # Add IP to pool

# Single resource
GET    /ip-pools/{id}                   # Get IP entry
PUT    /ip-pools/{id}                   # Update IP entry
DELETE /ip-pools/{id}                   # Delete IP entry

# Special endpoints
GET    /ip-pools/preferred?port_type=lightning  # Get preferred IP

# Actions
POST   /ip-pools/{id}:set-default       # Set as default
POST   /ip-pools/health-check           # Trigger health check

# External
POST   /external/ip-pools/sync          # Sync from remote node

# Filtering
GET    /ip-pools?port_type=lightning&is_active=true
```

---

## 10. Quick Reference

| Aspect | Standard | Example |
|--------|----------|---------|
| Path segments | kebab-case | `/user-profiles` |
| Collections | Plural nouns | `/users`, `/orders` |
| Path params | snake_case | `{user_id}`, `{order_id}` |
| Query params | snake_case | `?is_active=true` |
| Actions | Colon style | `POST /orders/{id}:cancel` |
| Versioning | URL path | `/api/v2/users` |
| Hierarchy | Max 3 levels | `/users/{id}/orders/{id}` |
| External APIs | `/external/` prefix | `/external/ip-pools/sync` |
| No trailing slash | Omit | `/users` not `/users/` |

---

## 11. Checklist

Before submitting an API design, verify:

- [ ] All path segments use kebab-case
- [ ] All collection names are plural nouns
- [ ] No verbs in paths (except auth/search)
- [ ] Path parameters use snake_case
- [ ] Query parameters use snake_case
- [ ] Hierarchy reflects relationships (max 3 levels)
- [ ] Actions use colon style (`:action`)
- [ ] Version included in base URL (`/api/v2`)
- [ ] External APIs use `/external/` prefix
- [ ] Consistent with existing APIs in the project

---

## 12. Migration Notes

### Current APIs Requiring Updates

| Current Path | Recommended Path | Priority |
|--------------|------------------|----------|
| `/ip-pool` | `/ip-pools` | Medium |
| `/terminal/sessions` | `/terminal-sessions` | Low |
| `/notifications/{id}/read` | `/notifications/{id}:read` | Low |
| `/auto-discovery/control/enable` | `/auto-discovery:enable` | Low |

### Backward Compatibility

When migrating existing APIs:

1. **Add new endpoint** with correct naming
2. **Create alias** from old path to new path
3. **Mark old endpoint** as deprecated in OpenAPI spec
4. **Set sunset date** (minimum 6 months)
5. **Remove old endpoint** after sunset period

```yaml
# Example deprecation in OpenAPI
/ip-pool:
  get:
    deprecated: true
    description: |
      **DEPRECATED** - Use /ip-pools instead.
      This endpoint will be removed on 2025-07-01.
```

