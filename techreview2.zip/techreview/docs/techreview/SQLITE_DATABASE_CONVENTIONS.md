# SQLite Database Design Conventions

This document outlines the database design conventions and best practices for SQLite databases in this project. These conventions ensure consistency, performance, and maintainability across all database schemas.

## Table of Contents

- [Naming Conventions](#naming-conventions)
- [Data Types](#data-types)
- [Table Structure](#table-structure)
- [Constraints](#constraints)
- [Indexes](#indexes)
- [Relationships](#relationships)
- [Performance Optimization](#performance-optimization)
- [Migration Practices](#migration-practices)
- [SQLite-Specific Considerations](#sqlite-specific-considerations)
- [Best Practices](#best-practices)

## Naming Conventions

### 1. **Table Names**
- Use **`snake_case`** (lowercase with underscores)
- Use **plural nouns** for table names
- **Examples:**
  - ✅ `users`
  - ✅ `lightning_invoices`
  - ✅ `conversation_messages`
  - ❌ `User` (PascalCase)
  - ❌ `user_table` (unnecessary suffix)
  - ❌ `UserMessages` (camelCase)

### 2. **Column Names**
- Use **`snake_case`** for all column names
- Use **singular nouns** for column names
- **Examples:**
  - ✅ `user_id`, `email`, `created_at`
  - ✅ `invoice_amount`, `payment_hash`
  - ❌ `userId` (camelCase)
  - ❌ `UserEmail` (PascalCase)

### 3. **Primary Key Columns**
- Always name primary key columns **`id`**
- Use `INTEGER PRIMARY KEY` (SQLite auto-increment)
- **Examples:**
  - ✅ `id INTEGER PRIMARY KEY`
  - ❌ `user_id INTEGER PRIMARY KEY` (redundant)
  - ❌ `pk_id INTEGER PRIMARY KEY` (unnecessary prefix)

### 4. **Foreign Key Columns**
- Name foreign key columns as `{referenced_table}_id`
- Always use singular form
- **Examples:**
  - ✅ `user_id` (references users.id)
  - ✅ `conversation_id` (references conversations.id)
  - ❌ `user_fk` (unclear)
  - ❌ `users_id` (plural)

### 5. **Index Names**
- Pattern: `idx_{table}_{column1}_{column2}`
- **Examples:**
  - ✅ `idx_users_email`
  - ✅ `idx_messages_conversation_created`
  - ❌ `email_index` (unclear table)

### 6. **Constraint Names**
- Pattern: `{constraint_type}_{table}_{column}`
- **Examples:**
  - ✅ `fk_messages_conversation_id`
  - ✅ `uq_users_email`
  - ✅ `ck_users_age_positive`

## Data Types

### 1. **Recommended SQLite Data Types**

| Use Case | SQLite Type | Rust/Diesel Type | Notes |
|----------|-------------|------------------|-------|
| **Primary Keys** | `INTEGER` | `i64` | Auto-incrementing |
| **Foreign Keys** | `INTEGER` | `i64` | References other INTEGER PKs |
| **Booleans** | `INTEGER` | `bool` | 0 = false, 1 = true |
| **Timestamps** | `INTEGER` | `i64` | Unix timestamp in seconds |
| **Text/Strings** | `TEXT` | `String` | UTF-8 encoded |
| **JSON Data** | `TEXT` | `serde_json::Value` | JSON as string |
| **Binary Data** | `BLOB` | `Vec<u8>` | Raw bytes |

### 2. **Timestamp Handling**
- Store as `INTEGER` (Unix timestamp)
- Use seconds precision for consistency
- **Examples:**
  ```sql
  created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
  updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
  ```

### 3. **Boolean Fields**
- Use `INTEGER` with 0/1 values
- **Examples:**
  ```sql
  is_active INTEGER NOT NULL DEFAULT 1,
  email_verified INTEGER NOT NULL DEFAULT 0
  ```

## Table Structure

### 1. **Standard Table Template**

```sql
CREATE TABLE table_name (
    -- Primary key
    id INTEGER PRIMARY KEY,

    -- Foreign keys
    parent_id INTEGER,

    -- Core data fields
    name TEXT NOT NULL,
    description TEXT,

    -- Status/enum fields
    status TEXT NOT NULL DEFAULT 'active',

    -- Metadata
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),

    -- Foreign key constraints
    FOREIGN KEY (parent_id) REFERENCES parent_table(id)
);
```

### 2. **Audit Fields**
Always include these standard fields:

```sql
-- Required audit fields
created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),

-- Optional audit fields (when needed)
created_by INTEGER,  -- User who created the record
updated_by INTEGER,  -- User who last updated the record
version INTEGER NOT NULL DEFAULT 1,  -- Optimistic locking
```

### 3. **Status Fields**
Use consistent status values:

```sql
-- Common status patterns
status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'deleted')),
payment_status TEXT NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending', 'paid', 'failed', 'refunded')),
```

## Constraints

### 1. **Primary Key Constraints**
```sql
-- Simple primary key
id INTEGER PRIMARY KEY,

-- Composite primary key (rare, use with caution)
PRIMARY KEY (user_id, item_id),
```

### 2. **Foreign Key Constraints**
```sql
-- Basic foreign key
user_id INTEGER NOT NULL,
FOREIGN KEY (user_id) REFERENCES users(id),

-- Foreign key with actions
conversation_id INTEGER NOT NULL,
FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
```

### 3. **Check Constraints**
```sql
-- Value validation
age INTEGER CHECK (age >= 0 AND age <= 150),
amount INTEGER CHECK (amount > 0),

-- String validation
email TEXT CHECK (email LIKE '%@%'),
status TEXT CHECK (status IN ('active', 'inactive', 'suspended')),
```

### 4. **Unique Constraints**
```sql
-- Single column
email TEXT UNIQUE,

-- Multiple columns
UNIQUE (user_id, token_type),

-- Named constraint
CONSTRAINT uq_users_email UNIQUE (email),
```

### 5. **Not Null Constraints**
```sql
-- Required fields
email TEXT NOT NULL,
created_at INTEGER NOT NULL,

-- Optional fields (explicitly allow NULL)
description TEXT,  -- NULL allowed by default
```

## Indexes

### 1. **Index Naming Convention**
```
idx_{table}_{column1}_{column2}_{...}
```

### 2. **When to Create Indexes**

**Always Index:**
- Primary keys (automatic in SQLite)
- Foreign keys (critical for joins)
- Columns used in WHERE clauses frequently
- Columns used in ORDER BY clauses

**Consider Indexing:**
- Columns used in JOIN conditions
- Columns with high selectivity
- Composite indexes for multi-column queries

### 3. **Index Examples**

```sql
-- Foreign key indexes (critical)
CREATE INDEX idx_messages_conversation_id ON messages(conversation_id);
CREATE INDEX idx_payments_user_id ON payments(user_id);

-- Query optimization indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_invoices_status_created ON invoices(status, created_at);

-- Composite indexes for complex queries
CREATE INDEX idx_messages_conversation_created ON messages(conversation_id, created_at DESC);
```

### 4. **Index Best Practices**

- **Don't over-index**: Each index has maintenance cost
- **Covering indexes**: Include all columns needed for a query
- **Partial indexes**: Index only relevant rows
- **Regular maintenance**: ANALYZE tables periodically

## Relationships

### 1. **One-to-Many Relationships**

```sql
-- Users have many posts
CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    username TEXT NOT NULL UNIQUE
);

CREATE TABLE posts (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    content TEXT,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),

    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX idx_posts_user_id ON posts(user_id);
```

### 2. **Many-to-Many Relationships**

```sql
-- Users belong to many groups, groups have many users
CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    username TEXT NOT NULL UNIQUE
);

CREATE TABLE groups (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE
);

CREATE TABLE user_groups (
    user_id INTEGER NOT NULL,
    group_id INTEGER NOT NULL,
    joined_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),

    PRIMARY KEY (user_id, group_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (group_id) REFERENCES groups(id) ON DELETE CASCADE
);

CREATE INDEX idx_user_groups_user_id ON user_groups(user_id);
CREATE INDEX idx_user_groups_group_id ON user_groups(group_id);
```

### 3. **Self-Referencing Relationships**

```sql
-- Hierarchical categories (parent-child)
CREATE TABLE categories (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    parent_id INTEGER,  -- References same table

    FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE CASCADE
);

CREATE INDEX idx_categories_parent_id ON categories(parent_id);
```

## Performance Optimization

### 1. **Query Optimization**

- **Use EXPLAIN QUERY PLAN** to analyze queries:
  ```sql
  EXPLAIN QUERY PLAN SELECT * FROM messages WHERE conversation_id = ?;
  ```

- **Avoid table scans**: Ensure WHERE clauses use indexed columns

- **Limit result sets**: Use LIMIT for pagination
  ```sql
  SELECT * FROM messages ORDER BY created_at DESC LIMIT 50 OFFSET 0;
  ```

### 2. **Schema Optimization**

- **Normalize when appropriate**: Don't over-normalize for read-heavy workloads
- **Denormalize for performance**: Duplicate data when joins are expensive
- **Use appropriate data types**: Smaller types when possible

### 3. **Connection Management**

- **Connection pooling**: Use connection limits appropriate for SQLite
- **WAL mode**: Enable Write-Ahead Logging for better concurrency
  ```sql
  PRAGMA journal_mode = WAL;
  PRAGMA synchronous = NORMAL;
  ```

### 4. **Maintenance**

- **Regular ANALYZE**: Update query planner statistics
  ```sql
  ANALYZE;
  ```

- **VACUUM**: Reclaim space and optimize storage
  ```sql
  VACUUM;
  ```

## Migration Practices

### 1. **Migration File Naming**
```
YYYYMMDD_HHMMSS_description.sql
```
**Examples:**
- `20250115_120000_add_user_profiles.sql`
- `20250116_090000_create_payment_table.sql`

### 2. **Migration Content Structure**

```sql
-- Migration: Add user profiles table
-- Created: 2025-01-15
-- Description: Adds user profile information separate from authentication

BEGIN;

-- Create table
CREATE TABLE user_profiles (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL UNIQUE,
    display_name TEXT,
    bio TEXT,
    avatar_url TEXT,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
    updated_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),

    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create indexes
CREATE INDEX idx_user_profiles_user_id ON user_profiles(user_id);

-- Data migration (if needed)
-- INSERT INTO user_profiles (user_id, display_name)
-- SELECT id, username FROM users WHERE username IS NOT NULL;

COMMIT;
```

### 3. **Migration Best Practices**

- **Atomic operations**: Use transactions for multi-step changes
- **Idempotent**: Migrations should be safe to run multiple times
- **Reversible**: Include rollback scripts when possible
- **Test migrations**: Test on copy of production data first

## SQLite-Specific Considerations

### 1. **SQLite Limitations**

- **No concurrent writes**: Single writer, multiple readers
- **No right joins**: Use left joins instead
- **Limited ALTER TABLE**: Can't drop columns, limited modifications
- **No native UUID**: Store as TEXT or BLOB

### 2. **SQLite Advantages**

- **Zero configuration**: No server setup required
- **Embedded**: Perfect for desktop/mobile apps
- **ACID compliance**: Reliable transactions
- **Small footprint**: Minimal resource usage

### 3. **SQLite Pragmas**

Essential pragmas for production use:

```sql
-- Performance and reliability
PRAGMA journal_mode = WAL;        -- Better concurrency
PRAGMA synchronous = NORMAL;      -- Balance safety/speed
PRAGMA cache_size = 1000000;      -- 1GB cache (adjust as needed)
PRAGMA temp_store = memory;       -- Temp tables in memory
PRAGMA mmap_size = 268435456;     -- 256MB memory mapping

-- Foreign keys (enable enforcement)
PRAGMA foreign_keys = ON;
```

### 4. **SQLite Date/Time Handling**

```sql
-- Store as Unix timestamp (seconds)
created_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),

-- Query by date range
SELECT * FROM events
WHERE created_at >= strftime('%s', '2025-01-01')
  AND created_at < strftime('%s', '2025-02-01');
```

## Best Practices

### 1. **Schema Design**

- **Start normalized**: Begin with proper normalization
- **Denormalize strategically**: For performance-critical read patterns
- **Document decisions**: Explain why certain design choices were made

### 2. **Data Integrity**

- **Use constraints**: CHECK, UNIQUE, NOT NULL, FOREIGN KEY
- **Validate at application level**: Additional validation beyond DB constraints
- **Handle constraint violations**: Proper error handling in application code

### 3. **Performance Monitoring**

- **Monitor slow queries**: Use EXPLAIN QUERY PLAN regularly
- **Track index usage**: Ensure indexes are being used effectively
- **Monitor database size**: Plan for growth and archiving

### 4. **Backup and Recovery**

- **Regular backups**: Automate database backups
- **Test restores**: Regularly test backup restoration
- **Point-in-time recovery**: Use WAL mode for better recovery options

### 5. **Security**

- **Parameterize queries**: Never use string concatenation for SQL
- **Limit permissions**: Principle of least privilege
- **Encrypt sensitive data**: Use SQLCipher for encrypted databases
- **Sanitize inputs**: Validate all user inputs

### 6. **Development Workflow**

- **Use migrations**: Never modify schema directly in production
- **Version control schema**: Keep schema.sql in version control
- **Test migrations**: Test on development data before production
- **Document schema changes**: Update documentation with schema changes

## Common Patterns

### 1. **Soft Deletes**
```sql
-- Add deleted flag instead of hard deletes
ALTER TABLE posts ADD COLUMN deleted_at INTEGER;
CREATE INDEX idx_posts_deleted_at ON posts(deleted_at);

-- Query active posts only
SELECT * FROM posts WHERE deleted_at IS NULL;
```

### 2. **Audit Trail**
```sql
-- Track all changes
CREATE TABLE audit_log (
    id INTEGER PRIMARY KEY,
    table_name TEXT NOT NULL,
    record_id INTEGER NOT NULL,
    action TEXT NOT NULL, -- INSERT, UPDATE, DELETE
    old_values TEXT, -- JSON of old values
    new_values TEXT, -- JSON of new values
    changed_by INTEGER,
    changed_at INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
);

CREATE INDEX idx_audit_log_table_record ON audit_log(table_name, record_id);
```

### 3. **Pagination**
```sql
-- Efficient pagination with indexed ordering
SELECT * FROM messages
WHERE conversation_id = ?
ORDER BY created_at DESC
LIMIT ? OFFSET ?;
```

### 4. **Full-Text Search**
```sql
-- FTS virtual table for search
CREATE VIRTUAL TABLE posts_fts USING fts5(title, content, tokenize = 'porter');

-- Populate FTS table
INSERT INTO posts_fts(rowid, title, content)
SELECT id, title, content FROM posts;

-- Search query
SELECT p.* FROM posts_fts pfts
JOIN posts p ON p.id = pfts.rowid
WHERE posts_fts MATCH 'rust programming'
ORDER BY rank;
```

---

## Quick Reference

### Data Type Mapping (Rust/Diesel ↔ SQLite)

| Rust/Diesel | SQLite | Use Case |
|-------------|--------|----------|
| `i64` | `INTEGER` | Primary keys, foreign keys, counts |
| `String` | `TEXT` | Names, descriptions, content |
| `bool` | `INTEGER` | Flags, boolean values |
| `Vec<u8>` | `BLOB` | Binary data, files |
| `serde_json::Value` | `TEXT` | JSON data structures |

### Index Guidelines

- **Always**: Primary keys, foreign keys, frequently queried columns
- **Usually**: Columns in WHERE clauses, JOIN conditions, ORDER BY
- **Sometimes**: Composite indexes for complex queries
- **Rarely**: Low-selectivity columns, small tables

### Constraint Priority

1. **NOT NULL** - Required fields
2. **FOREIGN KEY** - Referential integrity
3. **UNIQUE** - Business rules
4. **CHECK** - Data validation
5. **DEFAULT** - Sensible defaults

Following these conventions ensures consistent, performant, and maintainable SQLite database schemas across the project.
