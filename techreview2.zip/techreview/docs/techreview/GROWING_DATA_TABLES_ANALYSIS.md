# Growing Data Tables Analysis

## Executive Summary

This document identifies and analyzes **26 tables** in the database that store continuously growing data (historical records, logs, transactions, metrics, audit trails). These tables require special attention for:
- **Data retention policies**
- **Archival strategies**
- **Query performance optimization**
- **Storage management**

**Total Growing Tables**: 26  
**High-Growth Tables**: 8 (>10K rows/day potential)  
**Critical Transaction Tables**: 5  
**Time-Series Tables**: 6  

---

## 1. Table Categories

### Category 1: Critical Transaction Tables (Financial/Business)

These tables store **critical business transactions** that must be preserved and audited.

#### 1.1 L402 Payment Transactions

```sql
CREATE TABLE l402_invoices (
    id TEXT PRIMARY KEY,
    invoice_id TEXT NOT NULL UNIQUE,
    payment_hash TEXT NOT NULL UNIQUE,
    payment_preimage TEXT,
    invoice_bolt11 TEXT NOT NULL,
    endpoint_path TEXT NOT NULL,
    amount_sats INTEGER NOT NULL,
    status TEXT NOT NULL,  -- 'pending', 'paid', 'expired'
    paid_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL,
    expires_at TIMESTAMP NOT NULL
);
```

**Growth Rate**: Medium-High (~100-1,000/day)  
**Retention**: **PERMANENT** (financial records)  
**Indexes**: 3 (payment_hash, status, expires_at)  
**Data Sensitivity**: **HIGH** (payment preimages)  
**Regulatory**: May require 7+ years retention  

---

```sql
CREATE TABLE l402_outbound_payments (
    id TEXT PRIMARY KEY,
    target_node_id TEXT NOT NULL,
    endpoint_path TEXT NOT NULL,
    payment_hash TEXT NOT NULL,
    payment_preimage TEXT,
    invoice_bolt11 TEXT NOT NULL,
    amount_sats INTEGER NOT NULL,
    status TEXT NOT NULL,
    error_message TEXT,
    paid_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL
);
```

**Growth Rate**: Medium (~50-500/day)  
**Retention**: **PERMANENT**  
**Indexes**: 4 (created, endpoint, status, target)  

---

```sql
CREATE TABLE api_store_credit_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    transaction_type TEXT NOT NULL,
    amount_sats INTEGER NOT NULL,
    balance_after_sats INTEGER NOT NULL,
    description TEXT,
    l402_invoice_id TEXT,
    prompt_tokens INTEGER,
    completion_tokens INTEGER,
    total_tokens INTEGER,
    llm_service TEXT,
    model TEXT,
    correlation_id TEXT,
    created_at TIMESTAMP NOT NULL
);
```

**Growth Rate**: High (~500-5,000/day)  
**Retention**: **PERMANENT** (account history)  
**Indexes**: 3 (user, type, created)  
**Query Pattern**: User balance history, usage analytics  

---

#### 1.2 L402 Analytics (Aggregated)

```sql
CREATE TABLE l402_analytics_daily (
    id TEXT PRIMARY KEY,
    date DATE NOT NULL,
    direction TEXT NOT NULL,  -- 'inbound', 'outbound'
    total_requests INTEGER NOT NULL,
    successful_payments INTEGER NOT NULL,
    failed_payments INTEGER NOT NULL,
    total_amount_sats INTEGER NOT NULL,
    avg_amount_sats REAL,
    top_endpoints TEXT,  -- JSON
    top_nodes TEXT,      -- JSON
    created_at TIMESTAMP NOT NULL,
    UNIQUE(date, direction)
);
```

**Growth Rate**: Low (~2/day = 730/year)  
**Retention**: 2-3 years recommended  
**Purpose**: Daily rollup for analytics dashboard  
**Data Type**: Pre-aggregated time-series  

---

### Category 2: High-Volume Time-Series Metrics

These tables grow **very rapidly** and require aggressive retention policies.

#### 2.1 System Monitoring

```sql
CREATE TABLE system_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME NOT NULL,
    
    -- CPU metrics
    cpu_usage_percent REAL NOT NULL,
    cpu_history TEXT NOT NULL,  -- JSON array
    
    -- Memory metrics
    memory_used_bytes BIGINT NOT NULL,
    memory_total_bytes BIGINT NOT NULL,
    memory_usage_percent REAL NOT NULL,
    
    -- Disk metrics
    disk_used_bytes BIGINT NOT NULL,
    disk_total_bytes BIGINT NOT NULL,
    disk_usage_percent REAL NOT NULL,
    
    -- Network metrics
    network_upload_mbps REAL NOT NULL,
    network_download_mbps REAL NOT NULL,
    network_upload_history TEXT NOT NULL,   -- JSON
    network_download_history TEXT NOT NULL  -- JSON
);
```

**Growth Rate**: **VERY HIGH** (~86,400/day @ 1 sample/sec)  
**Estimated Size**: ~500MB/year (with JSON history)  
**Retention**: **7-30 days** (then aggregate or delete)  
**Indexes**: 1 (timestamp)  
**Query Pattern**: Last 24h dashboard, trending  

**⚠️ Critical Issue**: This table will grow to millions of rows rapidly.

**Recommended Strategy**:
```sql
-- 1. Aggregate to hourly after 24h
INSERT INTO system_metrics_hourly 
SELECT 
    strftime('%Y-%m-%d %H:00:00', timestamp) as hour,
    AVG(cpu_usage_percent),
    AVG(memory_usage_percent),
    AVG(disk_usage_percent),
    MAX(network_upload_mbps),
    MAX(network_download_mbps)
FROM system_metrics
WHERE timestamp < datetime('now', '-1 day')
GROUP BY hour;

-- 2. Delete raw data older than 7 days
DELETE FROM system_metrics 
WHERE timestamp < datetime('now', '-7 days');

-- 3. Run VACUUM monthly
VACUUM;
```

---

#### 2.2 Transport Metrics (Raw)

```sql
CREATE TABLE transport_metrics (
    id TEXT PRIMARY KEY,
    timestamp INTEGER NOT NULL,  -- Unix timestamp (ms)
    protocol TEXT NOT NULL,      -- 'http', 'websocket', 'gossip'
    event_type TEXT NOT NULL,
    latency_ms INTEGER,
    bytes_transferred INTEGER,
    success BOOLEAN NOT NULL,
    error_code TEXT,
    l402_payment_made BOOLEAN NOT NULL,
    payment_amount_msat INTEGER,
    node_id TEXT,
    endpoint TEXT,
    created_at TIMESTAMP NOT NULL
);
```

**Growth Rate**: **VERY HIGH** (~864,000/day @ 10 req/sec)  
**Estimated Size**: ~2GB/year  
**Retention**: **24 hours** (raw data)  
**Indexes**: 5 (timestamp_protocol, created, endpoint, event_type, node_id)  
**Query Pattern**: Real-time monitoring, debugging  

**⚠️ Critical Issue**: Highest growth rate in database.

---

#### 2.3 Transport Metrics (Aggregated)

```sql
CREATE TABLE transport_metrics_hourly (
    id TEXT PRIMARY KEY,
    hour_timestamp INTEGER NOT NULL,
    protocol TEXT NOT NULL,
    total_requests INTEGER NOT NULL,
    successful_requests INTEGER NOT NULL,
    failed_requests INTEGER NOT NULL,
    avg_latency_ms REAL,
    p50_latency_ms INTEGER,
    p95_latency_ms INTEGER,
    p99_latency_ms INTEGER,
    total_bytes_transferred INTEGER,
    total_l402_payments INTEGER,
    total_payment_amount_msat INTEGER,
    created_at TIMESTAMP NOT NULL,
    UNIQUE(hour_timestamp, protocol)
);
```

**Growth Rate**: Low (~72/day = hourly rollups)  
**Estimated Size**: ~50MB/year  
**Retention**: **90 days - 1 year**  
**Purpose**: Historical analytics and trending  
**Data Type**: Pre-aggregated percentiles  

**✅ Excellent Design**: Shows proper time-series optimization.

---

### Category 3: Communication & Messaging

#### 3.1 Messages (User Conversations)

```sql
CREATE TABLE messages (
    id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL,
    sender_id TEXT NOT NULL,
    message TEXT NOT NULL,
    timestamp TIMESTAMP NOT NULL,
    read_at TIMESTAMP,
    status TEXT NOT NULL,
    FOREIGN KEY (conversation_id) REFERENCES conversations(id),
    FOREIGN KEY (sender_id) REFERENCES nodes(node_id)
);
```

**Growth Rate**: High (~1,000-10,000/day)  
**Retention**: **User-controlled** (delete conversation feature)  
**Indexes**: Multiple (conversation_id, sender_id, timestamp)  
**Data Sensitivity**: **HIGH** (private messages)  
**Query Pattern**: Recent messages in conversation  

---

#### 3.2 Message Queue (Delivery)

```sql
CREATE TABLE message_queue (
    message_id TEXT PRIMARY KEY,
    sender_node_id TEXT NOT NULL,
    recipient_node_id TEXT NOT NULL,
    content BLOB NOT NULL,
    status TEXT NOT NULL,  -- 'Pending', 'Processing', 'Delivered', 'Failed'
    retry_count INTEGER,
    next_retry_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL,
    delivered_at TIMESTAMP,
    conversation_id TEXT,
    delivery_method TEXT,
    last_error_message TEXT,
    l402_invoice_id TEXT
);
```

**Growth Rate**: High (~1,000-10,000/day)  
**Retention**: **Short-term** (delete after delivery or max retries)  
**Indexes**: 7 (comprehensive)  
**Pattern**: Queue table (should be cleared regularly)  

**Recommended Strategy**:
```sql
-- Delete delivered messages older than 7 days
DELETE FROM message_queue 
WHERE status = 'Delivered' 
  AND delivered_at < datetime('now', '-7 days');

-- Delete failed messages older than 30 days
DELETE FROM message_queue 
WHERE status = 'Failed' 
  AND created_at < datetime('now', '-30 days');
```

---

#### 3.3 Conversational UI Messages

```sql
CREATE TABLE conversational_ui_messages (
    id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL,
    role TEXT NOT NULL,  -- 'user', 'assistant', 'system'
    content TEXT NOT NULL,
    timestamp TIMESTAMP NOT NULL,
    metadata TEXT,  -- JSON (tools_used, etc.)
    FOREIGN KEY (conversation_id) REFERENCES conversational_ui_conversations(id)
);
```

**Growth Rate**: Medium-High (~500-5,000/day)  
**Retention**: **User-controlled** (AI chat history)  
**Indexes**: 2 (conversation_id, timestamp)  
**Data Sensitivity**: Medium  
**Storage Concern**: Large text content  

---

### Category 4: AI Agent Execution Logs

#### 4.1 Agent Executions (Parent Records)

```sql
CREATE TABLE agent_executions (
    execution_id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL,
    execution_type TEXT NOT NULL,
    status TEXT NOT NULL,
    started_at TIMESTAMP NOT NULL,
    completed_at TIMESTAMP,
    duration_ms INTEGER,
    cost_sats INTEGER NOT NULL,
    revenue_sats INTEGER NOT NULL,
    output_data TEXT,  -- JSON
    error_message TEXT,
    resource_usage TEXT,  -- JSON
    total_tokens INTEGER,
    total_cost_sats INTEGER,
    summary TEXT,
    created_at TIMESTAMP NOT NULL
);
```

**Growth Rate**: Medium (~100-1,000/day)  
**Retention**: 90 days - 6 months  
**Indexes**: 3 (agent_started, status, type)  
**Purpose**: Audit trail for AI agent runs  

---

#### 4.2 Agent Execution Steps (Detailed Logs)

```sql
CREATE TABLE agent_execution_steps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    execution_id TEXT NOT NULL,
    agent_id TEXT NOT NULL,
    step_type TEXT NOT NULL,  -- 10 different types
    step_index INTEGER NOT NULL,
    turn_index INTEGER,
    tool_name TEXT,
    tool_call_id TEXT,
    
    -- Step details
    input_data TEXT,   -- JSON
    output_data TEXT,  -- JSON
    error_message TEXT,
    outcome TEXT,
    
    -- Timing
    started_at TIMESTAMP NOT NULL,
    completed_at TIMESTAMP,
    duration_ms INTEGER,
    
    -- Resource usage
    tokens_used INTEGER,
    memory_mb REAL,
    cpu_percent REAL,
    
    metadata TEXT,  -- JSON
    created_at TIMESTAMP NOT NULL
);
```

**Growth Rate**: **VERY HIGH** (~10,000-100,000/day)  
**Estimated Size**: ~1GB/year  
**Retention**: **30-90 days**  
**Indexes**: 5 (execution_id, agent_id, started, step_type, tool_name)  
**Pattern**: Detailed debugging logs  

**⚠️ High-Volume Issue**: Steps can multiply quickly (100+ steps per execution).

**Recommended Strategy**:
```sql
-- Archive completed executions older than 90 days
CREATE TABLE agent_execution_steps_archive AS 
SELECT * FROM agent_execution_steps 
WHERE started_at < datetime('now', '-90 days');

DELETE FROM agent_execution_steps 
WHERE started_at < datetime('now', '-90 days');
```

---

### Category 5: Event & Audit Logs

#### 5.1 Events (Generic Event Log)

```sql
CREATE TABLE events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    state TEXT NOT NULL,
    correlation_id TEXT,
    payload TEXT,  -- JSON
    created_at TEXT NOT NULL
);
```

**Growth Rate**: High (~1,000-10,000/day)  
**Retention**: 30-90 days  
**Indexes**: 4 (correlation, created, entity, event_type)  
**Purpose**: General event sourcing/audit log  

---

#### 5.2 Event Bus Jobs

```sql
CREATE TABLE event_bus_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bus_type TEXT NOT NULL,
    event_data TEXT NOT NULL,  -- JSON
    status TEXT NOT NULL,      -- 'pending', 'processing', 'done', 'failed'
    error_message TEXT,
    attempts INTEGER NOT NULL,
    max_attempts INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    processed_at TEXT
);
```

**Growth Rate**: High (~1,000-10,000/day)  
**Retention**: **7 days** (delete after processing)  
**Indexes**: 3 (bus_type, created, status)  
**Pattern**: Job queue (should be cleared)  

**Recommended Strategy**:
```sql
-- Delete completed jobs older than 7 days
DELETE FROM event_bus_jobs 
WHERE status IN ('done', 'failed') 
  AND processed_at < datetime('now', '-7 days');
```

---

#### 5.3 Auto Discovery Events

```sql
CREATE TABLE auto_discovery_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    node_id TEXT NOT NULL,
    gossip_timestamp INTEGER NOT NULL,
    processed_at INTEGER NOT NULL,
    discovery_result TEXT NOT NULL,
    failure_reason TEXT,
    created_at TIMESTAMP NOT NULL,
    UNIQUE(node_id, gossip_timestamp)  -- Deduplication
);
```

**Growth Rate**: Medium (~100-1,000/day)  
**Retention**: 30 days  
**Indexes**: 3 (node_id, processed, dedup unique)  
**Purpose**: Network discovery audit trail  

---

### Category 6: Social & Content Interactions

#### 6.1 AI Posts

```sql
CREATE TABLE ai_posts (
    post_id TEXT PRIMARY KEY,
    author_user_id TEXT NOT NULL,
    content TEXT NOT NULL,
    ai_metadata TEXT NOT NULL,  -- JSON
    visibility TEXT NOT NULL,
    tips_received_msats INTEGER NOT NULL,
    engagement_score REAL NOT NULL,
    post_source TEXT NOT NULL,
    status TEXT NOT NULL,
    signature TEXT,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL,
    expires_at TIMESTAMP
);
```

**Growth Rate**: Medium (~100-1,000/day)  
**Retention**: **Permanent** (user content) + expiration logic  
**Indexes**: 5 (author, source, signature, expires, original_node)  
**Data Sensitivity**: Medium (public/private content)  

---

#### 6.2 Post Interactions (Likes, Comments, etc.)

```sql
CREATE TABLE post_interactions (
    id TEXT PRIMARY KEY,
    post_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    interaction_type TEXT NOT NULL,  -- 'like', 'comment', 'share'
    content TEXT,
    created_at TIMESTAMP NOT NULL,
    UNIQUE(post_id, user_id, interaction_type)
);
```

**Growth Rate**: High (~1,000-10,000/day)  
**Retention**: Permanent (engagement history)  
**Indexes**: 2 (post, user)  

---

#### 6.3 Post Verifications

```sql
CREATE TABLE post_verifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id TEXT NOT NULL,
    author_user_id TEXT NOT NULL,
    signature TEXT,
    verification_status TEXT NOT NULL,
    verification_timestamp TIMESTAMP,
    verification_error TEXT,
    verified_by_node_id TEXT NOT NULL,
    signature_method TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL,
    UNIQUE(post_id, verified_by_node_id)
);
```

**Growth Rate**: Medium (~100-1,000/day)  
**Retention**: 90 days - 1 year  
**Indexes**: 9 (comprehensive)  
**Purpose**: Content authenticity audit trail  

---

#### 6.4 Social Feeds

```sql
CREATE TABLE social_feeds (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    post_id TEXT NOT NULL,
    source_type TEXT NOT NULL,
    source_id TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL,
    is_read BOOLEAN NOT NULL,
    UNIQUE(user_id, post_id, source_type)
);
```

**Growth Rate**: High (~1,000-10,000/day)  
**Retention**: 30 days (feed cache)  
**Indexes**: 2 (user, unread)  
**Pattern**: Cache table (should be cleared)  

---

### Category 7: Notifications

```sql
CREATE TABLE notifications (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    notification_type TEXT NOT NULL,
    content TEXT NOT NULL,
    reference_id TEXT,
    read_at TEXT,
    dismissed_at TEXT,
    created_at TEXT NOT NULL,
    UNIQUE(user_id, notification_type, reference_id)
);
```

**Growth Rate**: Medium-High (~500-5,000/day)  
**Retention**: 30-90 days (user notification history)  
**Indexes**: 5 (user, created, type, unread, reference)  
**Pattern**: Mark-as-read workflow  

**Recommended Strategy**:
```sql
-- Delete dismissed notifications older than 90 days
DELETE FROM notifications 
WHERE dismissed_at IS NOT NULL 
  AND dismissed_at < datetime('now', '-90 days');
```

---

### Category 8: Terminal History

```sql
CREATE TABLE terminal_history (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    command TEXT NOT NULL,
    timestamp TEXT NOT NULL
);
```

**Growth Rate**: Medium (~100-1,000/day)  
**Retention**: User preference (90 days - 1 year)  
**Indexes**: 2 (session_id, timestamp)  
**Data Sensitivity**: **HIGH** (may contain secrets)  

---

### Category 9: Friend Requests & Relationships

```sql
CREATE TABLE friend_requests (
    id TEXT PRIMARY KEY,
    from_node_id TEXT NOT NULL,
    to_node_id TEXT NOT NULL,
    message TEXT,
    status TEXT NOT NULL,
    direction TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL,
    responded_at TIMESTAMP,
    l402_invoice TEXT,
    l402_macaroon TEXT,
    l402_paid_at TIMESTAMP,
    -- ... error tracking fields
);
```

**Growth Rate**: Low-Medium (~10-100/day)  
**Retention**: 90 days - 1 year (completed/rejected)  
**Indexes**: 5 (from_node, to_node, status, direction, created)  
**Pattern**: State machine (pending → accepted/rejected)  

**Recommended Strategy**:
```sql
-- Archive old completed requests
DELETE FROM friend_requests 
WHERE status IN ('accepted', 'rejected') 
  AND responded_at < datetime('now', '-6 months');
```

---

## 2. Storage Growth Projections

### Worst-Case Scenario (No Retention Policy)

| Table | Daily Growth | 1 Year | 3 Years | 5 Years |
|-------|--------------|--------|---------|---------|
| `transport_metrics` | 864K rows | **315M** | 945M | 1.6B |
| `system_metrics` | 86.4K rows | **31.5M** | 94.5M | 158M |
| `agent_execution_steps` | 50K rows | **18M** | 54M | 90M |
| `messages` | 5K rows | **1.8M** | 5.4M | 9M |
| `events` | 5K rows | **1.8M** | 5.4M | 9M |
| `api_store_credit_transactions` | 2K rows | **730K** | 2.2M | 3.6M |
| `conversational_ui_messages` | 2K rows | **730K** | 2.2M | 3.6M |
| `post_interactions` | 2K rows | **730K** | 2.2M | 3.6M |

**Total Rows (5 years, no retention)**: ~2.3 BILLION rows  
**Estimated Size**: ~100+ GB

**⚠️ CRITICAL**: Without retention policies, database will become unusable.

---

### With Recommended Retention Policies

| Table | Retention | Max Rows | Max Size |
|-------|-----------|----------|----------|
| `transport_metrics` | 24 hours | 864K | 200MB |
| `transport_metrics_hourly` | 1 year | 26K | 10MB |
| `system_metrics` | 7 days | 605K | 150MB |
| `agent_execution_steps` | 90 days | 4.5M | 1GB |
| `messages` | User-controlled | Variable | Variable |
| `events` | 90 days | 450K | 100MB |
| `l402_invoices` | Permanent | Cumulative | 500MB/year |
| `api_store_credit_transactions` | Permanent | Cumulative | 200MB/year |

**Total Size (with retention)**: ~5-10 GB (steady state)

---

## 3. Critical Recommendations

### Priority 1: Implement Retention Policies (URGENT)

**Tables Requiring Immediate Attention**:

1. **`transport_metrics`** - Delete after 24h
2. **`system_metrics`** - Delete after 7 days
3. **`agent_execution_steps`** - Archive after 90 days
4. **`event_bus_jobs`** - Delete completed after 7 days
5. **`message_queue`** - Delete delivered after 7 days

**Implementation**:
```rust
// Rust scheduled cleanup job
pub async fn cleanup_old_metrics(pool: &DbPool) -> Result<()> {
    let cutoff_24h = Utc::now() - Duration::hours(24);
    let cutoff_7d = Utc::now() - Duration::days(7);
    
    // 1. Aggregate transport metrics to hourly
    aggregate_transport_metrics_hourly(pool).await?;
    
    // 2. Delete old raw metrics
    diesel::delete(transport_metrics::table)
        .filter(transport_metrics::timestamp.lt(cutoff_24h.timestamp()))
        .execute(&mut pool.get()?)?;
    
    // 3. Delete old system metrics
    diesel::delete(system_metrics::table)
        .filter(system_metrics::timestamp.lt(cutoff_7d))
        .execute(&mut pool.get()?)?;
    
    // 4. Delete completed jobs
    diesel::delete(event_bus_jobs::table)
        .filter(event_bus_jobs::status.eq_any(vec!["done", "failed"]))
        .filter(event_bus_jobs::processed_at.lt(cutoff_7d))
        .execute(&mut pool.get()?)?;
    
    Ok(())
}

// Run daily at 3am
#[tokio::main]
async fn main() {
    let mut interval = tokio::time::interval(Duration::from_secs(86400));
    loop {
        interval.tick().await;
        cleanup_old_metrics(&pool).await?;
    }
}
```

---

### Priority 2: Add Partitioning/Archival Strategy

**For Critical Transaction Tables**:
```sql
-- Create archive tables
CREATE TABLE api_store_credit_transactions_archive (
    LIKE api_store_credit_transactions
);

-- Monthly archival job
INSERT INTO api_store_credit_transactions_archive 
SELECT * FROM api_store_credit_transactions 
WHERE created_at < date('now', '-2 years');

DELETE FROM api_store_credit_transactions 
WHERE created_at < date('now', '-2 years');

VACUUM;
```

---

### Priority 3: Monitor Storage Growth

```sql
-- Database size monitoring query
SELECT 
    name as table_name,
    SUM(pgsize) / 1024 / 1024 as size_mb
FROM dbstat
GROUP BY name
ORDER BY size_mb DESC
LIMIT 20;

-- Row count monitoring
SELECT 
    m.name as table_name,
    COUNT(*) as row_count
FROM sqlite_master m
JOIN pragma_table_info(m.name) p
WHERE m.type = 'table'
  AND m.name IN (
      'transport_metrics', 'system_metrics', 
      'agent_execution_steps', 'messages', 'events'
  )
GROUP BY m.name
ORDER BY row_count DESC;
```

---

### Priority 4: Optimize VACUUM Strategy

```bash
# Weekly VACUUM (during low-traffic hours)
0 3 * * 0 sqlite3 /path/to/db.db "VACUUM;"

# Or incremental VACUUM (SQLite 3.37+)
PRAGMA auto_vacuum = INCREMENTAL;
PRAGMA incremental_vacuum(1000);  -- Release 1000 pages
```

---

## 4. Summary Table: All Growing Data Tables

| # | Table Name | Category | Growth Rate | Retention Policy | Action Required |
|---|------------|----------|-------------|------------------|-----------------|
| 1 | `transport_metrics` | Metrics | **VERY HIGH** | 24 hours | ✅ YES - Immediate |
| 2 | `system_metrics` | Metrics | **VERY HIGH** | 7 days | ✅ YES - Immediate |
| 3 | `agent_execution_steps` | AI Logs | **VERY HIGH** | 90 days | ✅ YES - Urgent |
| 4 | `messages` | Communication | HIGH | User-controlled | ⚠️ Monitor |
| 5 | `events` | Audit Log | HIGH | 90 days | ✅ YES |
| 6 | `event_bus_jobs` | Queue | HIGH | 7 days (completed) | ✅ YES - Immediate |
| 7 | `message_queue` | Queue | HIGH | 7 days (delivered) | ✅ YES - Immediate |
| 8 | `conversational_ui_messages` | AI Chat | HIGH | User-controlled | ⚠️ Monitor |
| 9 | `post_interactions` | Social | HIGH | Permanent | ⚠️ Monitor |
| 10 | `api_store_credit_transactions` | **Transaction** | HIGH | **Permanent** | 🔒 Archive only |
| 11 | `notifications` | User | MEDIUM | 90 days | ✅ YES |
| 12 | `agent_executions` | AI Logs | MEDIUM | 90 days | ✅ YES |
| 13 | `social_feeds` | Cache | MEDIUM | 30 days | ✅ YES |
| 14 | `post_verifications` | Audit | MEDIUM | 1 year | ⚠️ Monitor |
| 15 | `auto_discovery_events` | Network | MEDIUM | 30 days | ✅ YES |
| 16 | `terminal_history` | User | MEDIUM | 1 year | ⚠️ Monitor |
| 17 | `ai_posts` | Social | MEDIUM | Permanent | ⚠️ Monitor |
| 18 | `l402_invoices` | **Transaction** | MEDIUM | **Permanent** | 🔒 Archive only |
| 19 | `l402_outbound_payments` | **Transaction** | MEDIUM | **Permanent** | 🔒 Archive only |
| 20 | `friend_requests` | Social | LOW | 6 months | ⚠️ Optional |
| 21 | `transport_metrics_hourly` | Metrics | LOW | 1 year | ⚠️ Monitor |
| 22 | `l402_analytics_daily` | Analytics | LOW | 2 years | ⚠️ Monitor |
| 23 | `update_health_checks` | Monitoring | LOW | 90 days | ⚠️ Optional |
| 24 | `rollback_events` | Audit | LOW | Permanent | ⚠️ Monitor |
| 25 | `rollback_checkpoints` | Audit | LOW | Permanent | ⚠️ Monitor |
| 26 | `backups` | Metadata | LOW | Permanent | ⚠️ Monitor |

**Legend**:
- ✅ **Action Required**: Implement retention policy
- ⚠️ **Monitor**: Track growth, implement if needed
- 🔒 **Archive Only**: Financial/regulatory data, permanent storage required

---

## 5. Recommended Cleanup Schedule

```sql
-- Daily cleanup (3:00 AM)
DELETE FROM transport_metrics WHERE timestamp < unixepoch('now', '-1 day');
DELETE FROM event_bus_jobs WHERE status IN ('done','failed') AND processed_at < datetime('now','-7 days');
DELETE FROM message_queue WHERE status='Delivered' AND delivered_at < datetime('now','-7 days');

-- Weekly cleanup (Sunday 3:00 AM)
DELETE FROM system_metrics WHERE timestamp < datetime('now', '-7 days');
DELETE FROM events WHERE created_at < datetime('now', '-90 days');
DELETE FROM notifications WHERE dismissed_at < datetime('now', '-90 days');
DELETE FROM social_feeds WHERE created_at < datetime('now', '-30 days');

-- Monthly cleanup (1st of month, 3:00 AM)
DELETE FROM agent_execution_steps WHERE started_at < datetime('now', '-90 days');
DELETE FROM agent_executions WHERE started_at < datetime('now', '-90 days');
DELETE FROM post_verifications WHERE created_at < datetime('now', '-1 year');
DELETE FROM auto_discovery_events WHERE created_at < datetime('now', '-30 days');

-- Quarterly cleanup (1st of quarter, 3:00 AM)
DELETE FROM friend_requests WHERE status IN ('accepted','rejected') AND responded_at < datetime('now','-6 months');

-- Annual archival (January 1st, 3:00 AM)
-- Archive old transaction data to separate tables/files
INSERT INTO api_store_credit_transactions_archive 
SELECT * FROM api_store_credit_transactions WHERE created_at < datetime('now','-3 years');

-- Vacuum after major deletions
VACUUM;
```

---

## 6. Monitoring Queries

```sql
-- Table growth rate (run weekly, compare results)
SELECT 
    name as table_name,
    (SELECT COUNT(*) FROM main.name) as current_rows,
    date('now') as measured_date
FROM sqlite_master 
WHERE type='table' 
  AND name IN (
      'transport_metrics', 'system_metrics', 'agent_execution_steps',
      'messages', 'events', 'api_store_credit_transactions'
  );

-- Storage breakdown
SELECT 
    name,
    SUM(pgsize) / 1024.0 / 1024.0 as size_mb,
    COUNT(*) as pages
FROM dbstat
GROUP BY name
HAVING size_mb > 1
ORDER BY size_mb DESC;

-- Oldest records per table (check retention compliance)
SELECT 
    'transport_metrics' as table_name, 
    MIN(timestamp) as oldest_record,
    (unixepoch('now') - MIN(timestamp)) / 86400 as days_old
FROM transport_metrics
UNION ALL
SELECT 'system_metrics', MIN(timestamp), 
    (julianday('now') - julianday(MIN(timestamp))) 
FROM system_metrics;
```

---

**Document Version**: 1.0  
**Analysis Date**: December 18, 2025  
**Tables Analyzed**: 26 growing data tables  
**Critical Actions**: 8 tables require immediate retention policies  
**Estimated Impact**: Prevent 100+ GB growth over 5 years

